"""Einstellung "Videos auswaehlen ...": alle Videos des Ordners als Mehrfachauswahl, abgewaehlte merken.

Der Knopf speichert und schliesst den Einstellungsdialog (<close>true</close>), sonst saehe dieses Skript einen gerade
geaenderten Ordner noch nicht. Danach oeffnen sich die Einstellungen wieder.
"""
import xbmc
import xbmcaddon
import xbmcgui

import videos

ADDON = xbmcaddon.Addon(videos.ADDON_ID)


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def main():
    folder = ADDON.getSettingString('folder')
    dialog = xbmcgui.Dialog()
    if folder:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        try:
            paths = videos.find(folder, ADDON.getSettingBool('recursive'), ADDON.getSettingString('include'),
                                ADDON.getSettingString('exclude'))
        except Exception as e:
            xbmc.log('[%s] Ordner nicht lesbar: %s' % (videos.ADDON_ID, e), xbmc.LOGWARNING)
            paths = []
        finally:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        names = [videos.relative(folder, p) for p in paths]
        if not names:
            dialog.ok(text(32005), text(32016))
        else:
            old = videos.skipped(folder)
            chosen = dialog.multiselect(text(32005), names,
                                        preselect=[i for i, n in enumerate(names) if n not in old])
            if chosen is not None:      # Abbrechen laesst alles, wie es war
                keep = {names[i] for i in chosen}
                # Abgewaehlte, die gerade nicht in der Liste stehen (Namensfilter), bleiben abgewaehlt
                new = (old - set(names)) | (set(names) - keep)
                videos.save_skipped(folder, new)
                xbmc.log('[%s] Auswahl: %d von %d Videos' % (videos.ADDON_ID, len(keep), len(names)), xbmc.LOGINFO)
                if not keep:
                    dialog.notification(text(32005), text(32017), xbmcgui.NOTIFICATION_WARNING, 4000, False)
    xbmc.executebuiltin('Addon.OpenSettings(%s)' % videos.ADDON_ID)

