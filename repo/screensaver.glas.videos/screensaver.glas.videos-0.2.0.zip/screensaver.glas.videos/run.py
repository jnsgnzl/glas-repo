"""Video-Bildschirmschoner: Fenster und Wiedergabe. Gestartet vom Einstieg saver.py per RunPlugin (Grund steht dort).

Ablauf (ein Faden fuer Fenster und Wiedergabe, Kodi ruft die Rueckmeldungen von Fenster, Player und Monitor in ihm auf,
waehrend er in waitForAbort wartet):
  scan     Ordner lesen (eigener Faden, ein haengendes Netzlaufwerk blockiert die Tasten nicht), schwarz mit Anzeige
  next     naechste Datei pruefen (ebenfalls im Faden), fehlt sie: Fehlschlag, sonst abspielen
  starting genau EIN Abspielauftrag ist unterwegs; ein zweiter kommt erst, wenn der erste laeuft, endet oder scheitert.
           Kodi liest "im Fenster abspielen" aus einem gemeinsamen Merkmal erst beim Start (Player.cpp, Application.cpp
           PlayFile); ein zweiter Auftrag in dieser Zeit wuerde im Vollbild starten und das Fenster verdraengen.
  playing  Video laeuft im Fenster; am Ende kommt das naechste
  black    nichts mehr abspielen (kein Ordner, keine Videos, zu viele Fehlschlaege in Folge, Bildschirm-aus-Zeit)

Ende bei jeder Bedienung (Taste im Fenster, Kodis Leerlaufzeit springt zurueck, Kodi weckt den Bildschirmschoner ohne
unser Video), wenn das Fenster von aussen verdraengt wird, wenn jemand anderes unser Video stoppt und beim Kodi-Ende.
Beim Ende wird nur unser eigenes Video gestoppt und das Fenster nur geschlossen, wenn es vorne ist (Window.close()
geht sonst im fremden Fenster einen Schritt zurueck).

Abfragen im Takt laufen ueber JSON-RPC (info, label) statt ueber getCondVisibility/getInfoLabel: die warten auf Kodis
Oberflaechensperre, JSON-RPC geht durch Kodis Nachrichtenschleife und kehrt zurueck, sobald Kodi beim Beenden die
Schleife anhaelt. Einen haengenden Abspielauftrag stoppt das Skript nie (Kodi wartete dann im Hauptfaden auf das Netz
und die Oberflaeche stuende still); es wartet, bis er laeuft oder scheitert.
"""
import json
import random
import sys
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import videos

ADDON_ID = videos.ADDON_ID
ADDON = xbmcaddon.Addon(ADDON_ID)
XML = 'screensaver-glas-videos.xml'
TICK = 0.25
SPINNER_DELAY = 1.0     # zwischen zwei Videos die Aktivitaetsanzeige erst nach 1 s (sonst blitzt sie bei jedem Wechsel)
SLOW_START = 30.0       # laeuft ein Video so lange nicht an, steht das im Log (gestoppt wird ein haengender Auftrag nie)
PENDING_WAIT = 180.0    # so lange wartet das Skript nach dem Ende auf einen noch haengenden Auftrag, um ihn zu beenden
MAX_FAILS = 5           # so viele Fehlschlaege in Folge, dann schwarz
GONE_CHECKS = 4         # Fenster 4 Pruefungen (1 s) in Folge nicht vorne: von aussen verdraengt
ERROR_DIALOG = 6.0      # so lange nach einem Abspielfehler wird Kodis Meldung "Wiedergabe nicht moeglich" geschlossen
STOP_QUIET = 2.5        # nach einem fremden Stopp so lange auf Kodis Ende warten (Kodi stoppt beim Beenden zuerst den Player)
ACTION_NOOP = 999


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def rpc(method, **params):
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method,
                                                          'params': params}))).get('result')
    except Exception:
        return None


def info(*conditions):
    """Kodi-Bedingungen ueber JSON-RPC; None, wenn Kodi nicht antwortet (beim Beenden)."""
    result = rpc('XBMC.GetInfoBooleans', booleans=list(conditions))
    if not result:
        return None
    return [bool(result.get(c)) for c in conditions]


def label(name):
    return (rpc('XBMC.GetInfoLabels', labels=[name]) or {}).get(name) or ''


def same_file(a, b):
    if not a or not b:
        return False
    a, b = a.replace('\\', '/').rstrip('/'), b.replace('\\', '/').rstrip('/')
    return a == b or a.rsplit('/', 1)[-1] == b.rsplit('/', 1)[-1]


class Library(threading.Thread):
    """Alle Dateizugriffe: Ordner lesen, vor jedem Video pruefen, ob die Datei noch da ist (fehlt sie, kommt kein
    Abspielauftrag und damit keine Fehlermeldung von Kodi)."""

    def __init__(self, folder, recursive, include, exclude):
        super().__init__(name='glas-videos-library', daemon=True)
        self.folder, self.recursive = folder, recursive
        self.include, self.exclude = include, exclude
        self.skipped = 0
        self.files = None           # None, solange gelesen wird
        self.quit = threading.Event()
        self.wanted = threading.Event()
        self.lock = threading.Lock()
        self.result = None
        self.order = []
        self.last = None

    def run(self):
        try:
            files = self.scan()
        except Exception as e:
            log('Ordner nicht lesbar: %s' % e, xbmc.LOGWARNING)
            files = []
        self.files = files
        while not self.quit.is_set():
            if not self.wanted.wait(0.5):
                continue
            self.wanted.clear()
            if self.quit.is_set():
                break
            path = self.pick()
            try:
                ok = bool(xbmcvfs.exists(path))
            except Exception:
                ok = False
            with self.lock:
                self.result = (path, ok)

    def scan(self):
        found = videos.find(self.folder, self.recursive, self.include, self.exclude, self.quit)
        off = videos.skipped(self.folder)       # in den Einstellungen abgewaehlt
        chosen = [p for p in found if videos.relative(self.folder, p) not in off]
        self.skipped = len(found) - len(chosen)
        return chosen

    def pick(self):
        """Zufaellige Reihenfolge, jedes Video einmal je Runde; keins zweimal hintereinander."""
        if not self.order:
            self.order = list(self.files)
            random.shuffle(self.order)
            if len(self.order) > 1 and self.order[-1] == self.last:
                self.order[0], self.order[-1] = self.order[-1], self.order[0]
        self.last = self.order.pop()
        return self.last

    def request(self):
        with self.lock:
            self.result = None
        self.wanted.set()

    def take(self):
        with self.lock:
            result, self.result = self.result, None
        return result


class Window(xbmcgui.WindowXML):
    saver = None

    def onAction(self, action):
        if self.saver:
            if action.getId() == ACTION_NOOP and time.time() - self.saver.woke_at < 1.0:
                return      # das eigene Wecken (falls Kodis Bildschirmschoner schon wach war)
            self.saver.end('Taste (Aktion %d)' % action.getId())


class Player(xbmc.Player):
    def __init__(self, saver):
        super().__init__()
        self.saver = saver

    def onAVStarted(self):
        self.saver.event('started')

    def onPlayBackEnded(self):
        self.saver.event('ended')

    def onPlayBackStopped(self):
        self.saver.event('stopped')

    def onPlayBackError(self):
        self.saver.event('error')


class Monitor(xbmc.Monitor):
    def __init__(self, saver):
        super().__init__()
        self.saver = saver

    def onScreensaverDeactivated(self):
        self.saver.screensaver_off()


class Saver:
    def __init__(self):
        self.state, self.since = 'scan', time.time()
        self.reason = ''
        self.path = None            # angefordertes bzw. laufendes Video
        self.asked = False          # Library hat eine Datei zu pruefen
        self.fails = 0
        self.error_at = 0.0
        self.woke_at = 0.0
        self.slow_logged = False
        self.stopping = False       # eigener Stopp: das folgende onPlayBackStopped ist erwartet
        self.played = False
        self.seen_idle = False
        self.gone = 0
        self.loading = None
        self.loading_since = time.time()
        self.started = time.time()
        self.library = None
        self.win = None
        minutes = rpc('Settings.GetSettingValue', setting='powermanagement.displaysoff') or {}
        # Kodi schaltet den Bildschirm nie ab, solange ein Video laeuft: nach dieser Zeit nur noch schwarz
        self.limit = max(0, int(minutes.get('value') or 0)) * 60
        self.monitor = Monitor(self)
        self.player = Player(self)

    # --- Zustaende --------------------------------------------------------------------------------------------------

    def set_state(self, state):
        if state != 'playing' and self.state == 'playing':
            self.loading_since = time.time()
        self.state, self.since = state, time.time()

    def end(self, reason):
        if not self.reason:
            self.reason = reason
            log('Ende: %s' % reason)

    def fail(self, why):
        self.fails += 1
        self.error_at = time.time()
        log('Fehlschlag %d/%d: %s' % (self.fails, MAX_FAILS, why), xbmc.LOGWARNING)
        self.set_state('next')

    def ours_playing(self):
        # Infolabel statt getPlayingFile(): das wirft im Wettlauf mit dem Ende des Videos und Kodi protokolliert es
        return self.player.isPlayingVideo() and same_file(label('Player.Filenameandpath'), self.path)

    def stop_video(self):
        self.stopping = True
        self.player.stop()

    # --- Rueckmeldungen von Kodi --------------------------------------------------------------------------------------

    def event(self, kind):
        if self.reason:
            if self.state == 'starting':      # Ende laeuft, Auftrag war noch unterwegs (shutdown wartet darauf)
                self.state = 'playing' if kind == 'started' else 'resolved'
            return
        if kind == 'started':
            if self.state == 'starting':
                self.fails = 0
                self.played = True
                self.set_state('playing')
                log('laeuft: %s' % self.path)
        elif kind == 'ended':
            if self.state == 'starting':
                self.fail('endete, bevor es lief: %s' % self.path)
            elif self.state == 'playing':
                self.set_state('next')
        elif kind == 'error':
            if self.state in ('starting', 'playing'):
                self.error_at = time.time()
                self.fail('Abspielfehler: %s' % self.path)
        elif kind == 'stopped':
            # Kodi 21 meldet Abspielfehler an Python nur als "gestoppt" (VideoPlayer -> OnPlayBackError ->
            # OnPlayBackStopped, onPlayBackError kommt nie an) und zeigt dazu "Wiedergabe nicht moeglich"
            if self.stopping:
                self.stopping = False
            elif self.state == 'starting':
                self.fail('Abspielfehler: %s' % self.path)
            elif self.state == 'playing':
                self.set_state('stopcheck')     # Fehler (Meldung erscheint) oder von aussen gestoppt

    def screensaver_off(self):
        """Kodi weckt den Bildschirmschoner auch selbst: sobald unser Video laeuft und wenn ein Abspielversuch
        scheitert (Fehlermeldung). Sonst war es eine Taste, die Kodi verschluckt hat - das Fenster bekommt sie nicht.
        Echte Tasten, Maus und EventServer setzen vor dem Aufwecken Kodis Leerlaufzeit zurueck; Tasten ueber JSON-RPC
        (Input.*) nicht, die zaehlen nur, solange kein Abspielversuch laeuft."""
        if self.reason or time.time() - self.woke_at < 1.0:     # das eigene Wecken (run)
            return
        idle = info('System.IdleTime(1)')
        key = self.seen_idle and idle is not None and not idle[0]
        busy = self.state in ('starting', 'playing', 'stopcheck') or time.time() - self.error_at < ERROR_DIALOG
        if key or not busy:
            self.end('Bildschirmschoner beendet (Bedienung)')

    # --- Ablauf -------------------------------------------------------------------------------------------------------

    def run(self):
        folder = ADDON.getSettingString('folder')
        if folder:
            self.library = Library(folder, ADDON.getSettingBool('recursive'), ADDON.getSettingString('include'),
                                   ADDON.getSettingString('exclude'))
            self.library.start()
        else:
            log('Kein Ordner eingestellt, nur schwarz')
            self.set_state('black')
        self.win = Window(XML, ADDON.getAddonInfo('path'), 'default', '1080i')
        self.win.saver = self
        self.spinner(time.time())
        self.win.show()
        if xbmc.getCondVisibility('System.ScreenSaverActive'):
            # Kodis Bildschirmschoner gleich selbst wecken: Input.ExecuteAction weckt ihn nur und sendet dabei keine
            # Aktion. Solange er aktiv ist, verschluckt Kodi jede Taste (Tasten von Fernbedienungs-Apps ueber JSON-RPC
            # spurlos); danach erreichen alle das Fenster. Ein laufendes Video wuerde ihn ohnehin gleich wecken.
            self.woke_at = time.time()
            rpc('Input.ExecuteAction', action='noop')
        try:
            while not self.reason:
                if self.monitor.waitForAbort(TICK):
                    self.end('Kodi wird beendet')
                    break
                state = info('Window.IsActive(%s)' % XML, 'System.IdleTime(1)', 'Window.IsActive(okdialog)')
                if state is None:
                    continue
                self.watch(*state)
                if not self.reason:
                    self.step(state[2])
        except Exception as e:
            self.end('Fehler: %s' % e)
            raise
        finally:
            self.shutdown()

    def watch(self, active, idle, okdialog):
        now = time.time()
        if active:
            self.gone = 0
        else:
            self.gone += 1
            if self.gone >= GONE_CHECKS:
                self.end('Fenster von aussen verdraengt')
                return
        # jede Bedienung setzt Kodis Leerlaufzeit zurueck, auch Tasten fuer andere Fenster oder Tastenbelegungen
        if idle:
            self.seen_idle = True
        elif self.seen_idle:
            self.end('Bedienung')
            return
        if okdialog and now - self.error_at < ERROR_DIALOG:
            xbmc.executebuiltin('Dialog.Close(okdialog,true)')
            log('Kodis Fehlermeldung geschlossen')
        if self.limit and self.state in ('next', 'playing') and now - self.started > self.limit:
            log('Bildschirm-aus-Zeit erreicht, nur noch schwarz')
            if self.state == 'playing':
                self.stop_video()
            self.set_state('black')

    def step(self, okdialog):
        now = time.time()
        if self.state == 'scan':
            if self.library.files is not None:
                if self.library.files:
                    log('%d Videos (%d abgewaehlt)' % (len(self.library.files), self.library.skipped))
                    self.set_state('next')
                else:
                    log('Keine Videos gefunden, nur schwarz')
                    self.set_state('black')
        elif self.state == 'next':
            if self.fails >= MAX_FAILS:
                log('%d Fehlschlaege in Folge, nur noch schwarz' % self.fails, xbmc.LOGWARNING)
                self.set_state('black')
            elif not self.asked:
                self.library.request()
                self.asked = True
            else:
                result = self.library.take()
                if result:
                    self.asked = False
                    path, ok = result
                    if ok:
                        self.play(path)
                    else:
                        self.fail('Datei nicht erreichbar: %s' % path)
        elif self.state == 'stopcheck':
            if okdialog:
                self.fail('Abspielfehler waehrend der Wiedergabe: %s' % self.path)
            elif now - self.since > STOP_QUIET:
                self.end('Wiedergabe von aussen gestoppt')
        elif self.state == 'starting' and now - self.since > SLOW_START and not self.slow_logged:
            # nicht stoppen: Kodi wartete dann im Hauptfaden auf das Netz, die Oberflaeche stuende still. Kodi bricht
            # das Oeffnen selbst ab (dann kommt "gestoppt" = Fehlschlag); bis dahin schwarz mit Anzeige
            self.slow_logged = True
            log('startet seit %d s nicht: %s' % (SLOW_START, self.path), xbmc.LOGWARNING)
        self.spinner(now)

    def play(self, path):
        self.path = path
        self.stopping = False
        log('starte: %s' % path)
        self.slow_logged = False
        self.player.play(path, windowed=True)
        self.set_state('starting')

    def spinner(self, now):
        want = self.state in ('scan', 'next', 'starting') and (not self.played or
                                                              now - self.loading_since >= SPINNER_DELAY)
        if want != self.loading:
            self.loading = want
            self.win.setProperty('loading', 'true' if want else '')

    def shutdown(self):
        if self.library:
            self.library.quit.set()
            self.library.wanted.set()
        if not self.monitor.abortRequested():
            pending = self.state == 'starting'
            if not pending and self.ours_playing():
                self.stop_video()
            active = info('Window.IsActive(%s)' % XML)
            if active and active[0]:
                self.win.close()
            if pending:
                # Auftrag noch unterwegs: nicht stoppen (Kodi wartete dann im Hauptfaden auf das Netz, die Oberflaeche
                # stuende still), sondern abwarten, bis er laeuft oder scheitert, und ein anlaufendes Video gleich
                # beenden. Startet jemand inzwischen etwas anderes, ersetzt das den Auftrag (= "gestoppt").
                log('warte auf den laufenden Abspielauftrag')
                end = time.time() + PENDING_WAIT
                while self.state == 'starting' and time.time() < end:
                    if self.monitor.waitForAbort(TICK) or self.ours_playing():
                        break
                if self.ours_playing():
                    log('Video lief nach dem Ende an, gestoppt')
                    self.stop_video()
            for _ in range(8):      # falls unser Video in einem Wettlauf doch noch anlief
                if self.monitor.waitForAbort(TICK):
                    break
                if self.ours_playing():
                    log('Video lief noch nach, gestoppt')
                    self.stop_video()
        if self.library:
            self.library.join(3)
            if self.library.is_alive():
                log('Dateizugriff haengt noch (Netzwerk?), Faden endet von selbst', xbmc.LOGWARNING)
        self.win.saver = None
        if not self.monitor.abortRequested():
            del self.win    # beim Kodi-Ende nicht: das wartet auf die Oberflaechensperre (raeumt Kodi selbst auf)
        log('beendet')


if 'action=pick' in (sys.argv[2] if len(sys.argv) > 2 else ''):
    import pick         # Einstellung "Videos auswaehlen ..." (gleiche Plugin-Erweiterung, eigener Aufruf)
    pick.main()
else:
    Saver().run()
