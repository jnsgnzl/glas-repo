"""Gemeinsam fuer Bildschirmschoner (run.py) und Auswahl (pick.py): Videos eines Ordners finden und die abgewaehlten
Videos merken.

Abgewaehlte stehen je Ordner in addon_data/.../selection.json (Pfade relativ zum Ordner), nicht in den Einstellungen:
der offene Einstellungsdialog schreibt beim Schliessen seine eigene Kopie zurueck und wuerde sie ueberschreiben. Gemerkt
werden die abgewaehlten, damit neu hinzugekommene Videos von selbst dabei sind.
"""
import json
import os

import xbmcvfs

ADDON_ID = 'screensaver.glas.videos'
EXTS = ('.mov', '.mp4', '.m4v', '.mkv', '.ts', '.m2ts', '.webm', '.avi', '.mpg', '.mpeg', '.wmv')
MAX_FILES = 5000
MAX_DEPTH = 4
SELECTION = 'special://profile/addon_data/%s/selection.json' % ADDON_ID


def terms(text):
    return [t.strip().lower() for t in (text or '').replace(';', ',').split(',') if t.strip()]


def separator(folder):
    return '/' if '/' in folder else os.sep


def root(folder):
    return folder if folder.endswith(('/', '\\')) else folder + separator(folder)


def key(folder):
    return folder.replace('\\', '/').rstrip('/')


def find(folder, recursive, include, exclude, quit=None):
    """Alle Videos des Ordners (volle Pfade, sortiert), die zu den Namensfiltern passen."""
    include, exclude = terms(include), terms(exclude)

    def matches(name):
        low = name.lower()
        if not low.endswith(EXTS):
            return False
        if include and not any(t in low for t in include):
            return False
        return not any(t in low for t in exclude)

    sep = separator(folder)
    found, queue = [], [(root(folder), 0)]
    while queue and not (quit and quit.is_set()) and len(found) < MAX_FILES:
        path, depth = queue.pop(0)
        dirs, files = xbmcvfs.listdir(path)
        found.extend(path + name for name in sorted(files) if matches(name))
        if recursive and depth < MAX_DEPTH:
            queue.extend((path + d + sep, depth + 1) for d in sorted(dirs) if not d.startswith('.'))
    return found[:MAX_FILES]


def relative(folder, path):
    return path[len(root(folder)):].replace('\\', '/')


def _load():
    try:
        with xbmcvfs.File(SELECTION) as f:
            data = json.loads(f.read() or '{}')
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def skipped(folder):
    """Abgewaehlte Videos dieses Ordners (relative Pfade)."""
    return set(_load().get('folders', {}).get(key(folder), []))


def save_skipped(folder, names):
    data = _load()
    folders = data.setdefault('folders', {})
    if names:
        folders[key(folder)] = sorted(names)
    else:
        folders.pop(key(folder), None)
    xbmcvfs.mkdirs('special://profile/addon_data/%s/' % ADDON_ID)
    with xbmcvfs.File(SELECTION, 'w') as f:
        f.write(json.dumps(data, ensure_ascii=False, indent=1))
