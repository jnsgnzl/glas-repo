"""Einstieg des Bildschirmschoners (xbmc.ui.screensaver). Startet nur das eigentliche Fenster (run.py) und endet sofort.

Warum zwei Skripte: Sobald ein Video laeuft, weckt Kodi den Bildschirmschoner selbst auf und beendet 15 s spaeter das
Skript, das als Bildschirmschoner gestartet wurde (StopScript auf diese Datei, ApplicationPowerHandling.cpp). Startet
Kodi den Bildschirmschoner, waehrend dieses Skript noch laeuft, stoppt es das Skript, statt es neu zu starten. Deshalb
laufen Fenster und Wiedergabe unter einem anderen Pfad (run.py), und dieser Einstieg ist nach Sekundenbruchteilen fertig.
run.py startet als Plugin (RunPlugin): RunScript mit einem Dateipfad liefe ohne Add-on-Bezug, und solchen Skripten meldet
Kodi beim Beenden kein abortRequested - es wuergte sie nach 5 s ab.
"""
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')


def main():
    if xbmc.getCondVisibility('Window.IsActive(screensaver-glas-videos.xml)'):
        # Fenster ist schon da (z. B. schwarz nach mehreren Fehlschlaegen, Kodi startet den Bildschirmschoner erneut)
        xbmc.log('[%s] Fenster laeuft schon, kein zweites' % ADDON_ID, xbmc.LOGINFO)
        return
    if xbmc.getCondVisibility('Player.HasMedia'):
        # z. B. ein pausierter Film (ohne "Bei Pause abdunkeln"): nichts abspielen, sonst waere der Film weg
        xbmc.log('[%s] Wiedergabe aktiv, Bildschirmschoner zeigt nichts' % ADDON_ID, xbmc.LOGINFO)
        return
    xbmc.executebuiltin('RunPlugin(plugin://%s/)' % ADDON_ID)


main()
