"""Glas Helper: Daten fuer die ausfuehrliche Detailseite (Skin-Einstellung glas_info_plus, DialogVideoInfo).

plugin://script.glas.helper/?action=infoplus&id=<movieid>
    Liest den Film aus der Bibliothek und legt aufbereitete Werte als Window(Home)-Properties glas.ip.* ab, die der Skin
    nur zeigt, solange glas.ip.id zur Detailseite passt (ListItem.DBID):
      Technik    res, dyn, codec, aspect, audio (beste Spur), audiocount, audio.N.lang/.codec/.ch (N = 1..6),
                 subs, subslangs, sub.N.lang/.count (je Sprache, N = 1..6), size, container, bitrate
      Inhalt     genre.N (1..5), tag.N (1..10)
      Wertung    rating, ratingsrc, votes
      Infos      runtime, premiered, added, lastplayed, fsk, versions
      Bilder     fanart, poster, clearlogo: von einer anderen Fassung desselben Films (gleiche IMDb-Nummer), wenn diese
                 mehr Bildarten hat (z. B. 1080p-Fassung mit Key-Art, 2160p-Fassung nur mit Standbild)
    Kodi liefert im Skin je Spur nur Kuerzel (ListItem.Property(AudioCodec.N) ...) und keine Dateigroesse.
"""
import xbmc
import xbmcgui

from nextup import rpc

PREFIX = 'glas.ip.'
CACHE = 'glas.ipgroesse.'  # Dateigroesse je Film (nicht in home_keys, bleibt die Sitzung ueber)
ZEICHEN_JE_ZEILE = 74  # Inhaltsangabe, font_body (Inter) in 1028 Breite; die eigene Fassung (SF Pro) setzt 77
MONATE = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober',
          'November', 'Dezember']
SPRACHE = {'deu': 'Deutsch', 'ger': 'Deutsch', 'eng': 'Englisch', 'fra': 'Französisch', 'fre': 'Französisch',
           'spa': 'Spanisch', 'ita': 'Italienisch', 'jpn': 'Japanisch', 'kor': 'Koreanisch', 'chi': 'Chinesisch',
           'zho': 'Chinesisch', 'rus': 'Russisch', 'pol': 'Polnisch', 'nld': 'Niederländisch', 'dut': 'Niederländisch',
           'swe': 'Schwedisch', 'dan': 'Dänisch', 'nor': 'Norwegisch', 'fin': 'Finnisch', 'por': 'Portugiesisch',
           'tur': 'Türkisch', 'ces': 'Tschechisch', 'cze': 'Tschechisch', 'hun': 'Ungarisch', 'gre': 'Griechisch',
           'ell': 'Griechisch', 'heb': 'Hebräisch', 'ara': 'Arabisch', 'hin': 'Hindi', 'tha': 'Thailändisch',
           'ukr': 'Ukrainisch', 'ron': 'Rumänisch', 'rum': 'Rumänisch', 'hrv': 'Kroatisch', 'srp': 'Serbisch',
           'bul': 'Bulgarisch', 'isl': 'Isländisch', 'ice': 'Isländisch', 'est': 'Estnisch', 'lav': 'Lettisch',
           'lit': 'Litauisch', 'slk': 'Slowakisch', 'slo': 'Slowakisch', 'slv': 'Slowenisch', 'ind': 'Indonesisch',
           'vie': 'Vietnamesisch', 'cat': 'Katalanisch', 'und': 'Unbekannt', '': 'Unbekannt'}
TON = {'truehd_atmos': 'Dolby Atmos', 'eac3_ddp_atmos': 'Dolby Atmos', 'eac3atmos': 'Dolby Atmos',
       'truehd': 'Dolby TrueHD', 'eac3': 'Dolby Digital Plus', 'ac3': 'Dolby Digital',
       'dtshd_ma_x': 'DTS:X', 'dtshd_ma_x_imax': 'IMAX Enhanced DTS:X', 'dtshd_ma': 'DTS-HD Master Audio',
       'dtshd_hra': 'DTS-HD High Resolution', 'dca': 'DTS', 'dts': 'DTS', 'aac': 'AAC', 'flac': 'FLAC', 'opus': 'Opus',
       'mp3': 'MP3', 'pcm_s16le': 'PCM', 'pcm_s24le': 'PCM', 'lpcm': 'PCM', 'vorbis': 'Vorbis'}
# je hoeher, desto besser (Auswahl der Spur fuer die Kapsel)
TON_RANG = ['dtshd_ma_x_imax', 'truehd_atmos', 'eac3_ddp_atmos', 'dtshd_ma_x', 'truehd', 'dtshd_ma', 'dtshd_hra',
            'flac', 'pcm_s24le', 'lpcm', 'eac3', 'dca', 'dts', 'ac3', 'aac', 'opus', 'mp3']
KURZ = {'truehd_atmos': 'Atmos', 'eac3_ddp_atmos': 'Atmos', 'truehd': 'TrueHD', 'eac3': 'DD+', 'ac3': 'DD',
        'dtshd_ma_x': 'DTS:X', 'dtshd_ma_x_imax': 'DTS:X', 'dtshd_ma': 'DTS-HD MA', 'dtshd_hra': 'DTS-HD HR', 'dca': 'DTS',
        'dts': 'DTS', 'aac': 'AAC', 'flac': 'FLAC', 'opus': 'Opus', 'mp3': 'MP3', 'lpcm': 'PCM'}
KANAL = {1: 'Mono', 2: 'Stereo', 3: '2.1', 6: '5.1', 7: '6.1', 8: '7.1'}
VIDEO = {'hevc': 'HEVC', 'h265': 'HEVC', 'h264': 'H.264', 'avc1': 'H.264', 'av1': 'AV1', 'vp9': 'VP9',
         'vc1': 'VC-1', 'wvc1': 'VC-1', 'mpeg2video': 'MPEG-2', 'mpeg4': 'MPEG-4', 'xvid': 'Xvid'}
DYNAMIK = {'dolbyvision': 'Dolby Vision', 'hdr10': 'HDR10', 'hdr10plus': 'HDR10+', 'hlg': 'HLG'}
CONTAINER = {'mkv': 'Matroska (MKV)', 'mp4': 'MPEG-4 (MP4)', 'm4v': 'MPEG-4 (M4V)', 'iso': 'Disc-Abbild (ISO)',
             'ts': 'MPEG-TS', 'm2ts': 'Blu-ray (M2TS)', 'avi': 'AVI', 'webm': 'WebM', 'mov': 'QuickTime (MOV)'}
QUELLE = {'themoviedb': 'TMDb', 'tmdb': 'TMDb', 'imdb': 'IMDb', 'trakt': 'Trakt', 'tomatometerallcritics': 'Rotten Tomatoes',
          'metacritic': 'Metacritic', 'letterboxd': 'Letterboxd'}
PROPS = ['title', 'originaltitle', 'genre', 'tag', 'runtime', 'streamdetails', 'file', 'ratings', 'rating', 'votes',
         'premiered', 'dateadded', 'lastplayed', 'mpaa', 'uniqueid', 'art', 'imdbnumber', 'plot', 'tagline',
         'userrating']


def de(x, nk=1):
    return ('{:,.%df}' % nk).format(x).replace(',', 'X').replace('.', ',').replace('X', '.')


def datum(text):
    try:
        y, m, d = text[:10].split('-')
        return '%d. %s %s' % (int(d), MONATE[int(m) - 1], y)
    except (ValueError, IndexError):
        return ''


def aufloesung(w, h):
    if w >= 3200 or h >= 1800:
        return '4K'
    if w >= 1800 or h >= 1000:
        return '1080p'
    if w >= 1200 or h >= 700:
        return '720p'
    return 'SD' if w else ''


def fsk(mpaa):
    for teil in (mpaa or '').split('/'):
        teil = teil.strip()
        for vor in ('DE:FSK-', 'DE:FSK ', 'DE:FSK', 'DE:', 'FSK-', 'FSK ', 'FSK'):
            if teil.startswith(vor):
                rest = teil[len(vor):].strip().rstrip('+')
                if rest.isdigit():
                    return 'FSK %s' % rest
    return (mpaa or '').split('/')[0].strip()


def run(query):
    dbid = query.get('id', '')
    home = xbmcgui.Window(10000)
    if not dbid.isdigit():
        return
    film = rpc('VideoLibrary.GetMovieDetails', movieid=int(dbid), properties=PROPS).get('moviedetails') or {}
    if not film:
        return
    werte = {}
    sd = film.get('streamdetails') or {}
    v = (sd.get('video') or [{}])[0]
    werte['res'] = aufloesung(v.get('width', 0), v.get('height', 0))
    if v.get('width'):
        werte['dims'] = '%d × %d' % (v['width'], v['height'])
    werte['stereo'] = 'Ja' if v.get('stereomode') else 'Nein'
    werte['dyn'] = DYNAMIK.get(v.get('hdrtype', ''), 'SDR' if v else '')
    werte['bild'] = ' '.join(x for x in (werte['res'], werte['dyn'] if werte['dyn'] != 'SDR' else '') if x)
    werte['codec'] = VIDEO.get(v.get('codec', ''), (v.get('codec') or '').upper())
    if v.get('aspect'):
        werte['aspect'] = '%s : 1' % de(v['aspect'], 2)
    ton = sd.get('audio') or []
    for i, a in enumerate(ton[:6], 1):
        werte['audio.%d.lang' % i] = SPRACHE.get(a.get('language', ''), a.get('language', '').upper())
        werte['audio.%d.codec' % i] = TON.get(a.get('codec', ''), a.get('codec', '').upper())
        werte['audio.%d.ch' % i] = KANAL.get(a.get('channels', 0), str(a.get('channels', '')))
        werte['audio.%d.short' % i] = KURZ.get(a.get('codec', ''), a.get('codec', '').upper())
    if ton:
        rang = lambda a: (TON_RANG[::-1].index(a.get('codec')) if a.get('codec') in TON_RANG else -1, a.get('channels', 0))
        beste = max(ton, key=rang)
        werte['audio'] = ' '.join(x for x in (TON.get(beste.get('codec', ''), beste.get('codec', '').upper()),
                                              KANAL.get(beste.get('channels', 0), '')) if x)
        werte['audioname'] = TON.get(beste.get('codec', ''), beste.get('codec', '').upper())
        werte['audiocount'] = '%d %s' % (len(ton), 'Tonspur' if len(ton) == 1 else 'Tonspuren')
        # Kapsel auf Bildschirm 1: lange Namen (DTS-HD Master Audio 7.1) in Kurzform
        if len(werte['audio']) > 16:
            werte['audio'] = ' '.join(x for x in (KURZ.get(beste.get('codec', ''), werte['audioname']),
                                                  KANAL.get(beste.get('channels', 0), '')) if x)
        if len(werte['audioname']) > 14:
            werte['audioname'] = KURZ.get(beste.get('codec', ''), werte['audioname'])
        kanal = KANAL.get(beste.get('channels', 0), '')
        werte['audiosub'] = '%s  ·  %s' % (kanal, werte['audiocount']) if kanal else werte['audiocount']
    subs = sd.get('subtitle') or []
    if subs:
        zahl = {}
        for s in subs:
            name = SPRACHE.get(s.get('language', ''), s.get('language', '').upper())
            zahl[name] = zahl.get(name, 0) + 1
        werte['subs'] = '%d %s' % (len(subs), 'Spur' if len(subs) == 1 else 'Spuren')
        werte['subslangs'] = '%d %s' % (len(zahl), 'Sprache' if len(zahl) == 1 else 'Sprachen')
        for i, (name, n) in enumerate(sorted(zahl.items(), key=lambda x: -x[1])[:6], 1):
            werte['sub.%d.lang' % i] = name
            werte['sub.%d.count' % i] = '%d %s' % (n, 'Spur' if n == 1 else 'Spuren')
    datei = film.get('file', '')
    endung = datei.rsplit('.', 1)[-1].lower() if '.' in datei else ''
    werte['container'] = CONTAINER.get(endung, endung.upper())
    for i, g in enumerate((film.get('genre') or [])[:5], 1):
        werte['genre.%d' % i] = g
    for i, t in enumerate([t for t in film.get('tag') or [] if t != 'Merkliste'][:10], 1):
        werte['tag.%d' % i] = t
    # Kapseln der Detailseite zeilenweise packen (Kodis grouplist bricht nicht um): geschaetzte Breite je Zeichen
    for (r, c), text in packen(film.get('genre') or [], 1, 13, 20).items():
        werte['gr%d.%d' % (r, c)] = text
    for (r, c), text in packen([t for t in film.get('tag') or [] if t != 'Merkliste'], 4, 11.5, 16).items():
        werte['tr%d.%d' % (r, c)] = text
    # lange Inhaltsangabe: groessere Karte (gen_infoplus.py, IH_LANG). Zeilen geschaetzt mit 74 Zeichen je Zeile (font_body
    # in 1028 Breite), Platz 9 Zeilen mit Werbespruch, 10 ohne
    if zeilen(film.get('plot') or '', ZEICHEN_JE_ZEILE) > (9 if film.get('tagline') else 10):
        werte['lang'] = '1'
    if film.get('userrating'):
        werte['userrating'] = str(film['userrating'])
    ratings = film.get('ratings') or {}
    quelle = next((k for k, r in ratings.items() if r.get('default')), next(iter(ratings), ''))
    if quelle:
        r = ratings[quelle]
        werte['rating'] = de(r.get('rating', 0))
        werte['ratingsrc'] = QUELLE.get(quelle, quelle.capitalize())
        if r.get('votes'):
            werte['votes'] = '%s Stimmen' % de(r['votes'], 0)
    if film.get('runtime'):
        m = film['runtime'] // 60
        werte['runtime'] = ('%d Std. %d Min.' % (m // 60, m % 60)) if m >= 60 else '%d Min.' % m
    werte['premiered'] = datum(film.get('premiered', ''))
    werte['added'] = datum(film.get('dateadded', ''))
    werte['lastplayed'] = datum(film.get('lastplayed', '')) or 'Noch nicht gesehen'
    werte['fsk'] = fsk(film.get('mpaa', ''))
    # andere Fassungen desselben Films (gleiche IMDb-Nummer)
    imdb = (film.get('uniqueid') or {}).get('imdb') or film.get('imdbnumber', '')
    fassungen = []
    if imdb:
        alle = rpc('VideoLibrary.GetMovies', properties=['uniqueid', 'streamdetails', 'art'],
                   filter={'field': 'title', 'operator': 'is', 'value': film.get('title', '')}).get('movies') or []
        alle = [m for m in alle if (m.get('uniqueid') or {}).get('imdb') == imdb]
        for m in alle:
            mv = ((m.get('streamdetails') or {}).get('video') or [{}])[0]
            text = aufloesung(mv.get('width', 0), mv.get('height', 0))
            if mv.get('hdrtype'):
                text += ' ' + DYNAMIK.get(mv['hdrtype'], mv['hdrtype'].upper())
            fassungen.append((m.get('movieid') == film.get('movieid'), text))
        if len(alle) > 1:
            fassungen.sort(key=lambda f: not f[0])
            werte['versions'] = ' und '.join(t for _, t in fassungen if t)
            werte['versions.kurz'] = '  ·  '.join(t.split(' ')[0] for _, t in fassungen if t)
            reichste = max(alle, key=lambda m: len(m.get('art') or {}))
            eigene = film.get('art') or {}
            if reichste.get('movieid') != film.get('movieid') and len(reichste.get('art') or {}) > len(eigene):
                for art in ('fanart', 'clearlogo', 'poster'):
                    if (reichste.get('art') or {}).get(art):
                        werte[art] = reichste['art'][art]
    dauer = v.get('duration') or film.get('runtime') or 0
    try:
        groesse = int(home.getProperty(CACHE + dbid) or 0)
    except ValueError:
        groesse = 0
    werte.update(groesse_werte(groesse, dauer))
    for k in [k for k in home_keys(home)]:
        home.clearProperty(k)
    for k, w in werte.items():
        if w:
            home.setProperty(PREFIX + k, w)
    home.setProperty(PREFIX + 'id', dbid)
    if groesse:
        return
    # Dateigroesse zuletzt: die erste SMB-Abfrage nach einer Pause dauert bis zu 12 s, der Rest der Seite steht dann
    # schon. Kodis Dateiliste statt xbmcvfs.Stat (Stat oeffnet die Datei). Ergebnis je Film merken (Sitzung).
    try:
        groesse = int((rpc('Files.GetFileDetails', file=datei, media='video', properties=['size'])
                       .get('filedetails') or {}).get('size') or 0) if datei and not datei.startswith('stack://') else 0
    except Exception:  # noqa: BLE001 - Freigabe nicht erreichbar
        groesse = 0
    if groesse:
        home.setProperty(CACHE + dbid, str(groesse))
        if home.getProperty(PREFIX + 'id') == dbid:
            for k, w in groesse_werte(groesse, dauer).items():
                home.setProperty(PREFIX + k, w)
    xbmc.log('[glas] infoplus %s: %d Werte' % (dbid, len(werte)), xbmc.LOGDEBUG)


def bewerten(query):
    """Stern auf der Detailseite gewaehlt: Kontextmenue mit den Wertungen (Glas-Menue des Skins), Wert in Kodis
    Bibliothek (userrating 0-10, Sterne x 2) und in glas.ip.userrating fuer die Anzeige"""
    dbid = query.get('id', '')
    if not dbid.isdigit():
        return
    home = xbmcgui.Window(10000)
    loc = lambda i: xbmc.getInfoLabel('$LOCALIZE[%d]' % i)
    aktuell = int(home.getProperty(PREFIX + 'userrating') or 0)
    werte = [10, 8, 6, 4, 2]
    namen = []
    for w in werte:
        n = w // 2
        name = '%d %s' % (n, loc(32056) if n == 1 else loc(32057))
        namen.append(name + ('  ✓' if w == aktuell else ''))
    if aktuell:
        namen.append(loc(32055))
    wahl = xbmcgui.Dialog().contextmenu(namen)
    if wahl < 0:
        return
    wert = werte[wahl] if wahl < len(werte) else 0
    rpc('VideoLibrary.SetMovieDetails', movieid=int(dbid), userrating=wert)
    if home.getProperty(PREFIX + 'id') == dbid:
        if wert:
            home.setProperty(PREFIX + 'userrating', str(wert))
        else:
            home.clearProperty(PREFIX + 'userrating')


def zeilen(text, breite):
    """Zeilenzahl bei Umbruch an Wortgrenzen (Absaetze einzeln)"""
    n = 0
    for absatz in text.replace('[CR]', '\n').split('\n'):
        laenge = 0
        n += 1
        for wort in absatz.split():
            if laenge and laenge + 1 + len(wort) > breite:
                n += 1
                laenge = len(wort)
            else:
                laenge += (1 if laenge else 0) + len(wort)
    return n


def groesse_werte(groesse, dauer):
    if not groesse:
        return {}
    aus = {'size': '%s GB' % de(groesse / 1e9) if groesse >= 1e9 else '%s MB' % de(groesse / 1e6, 0)}
    if dauer:
        aus['bitrate'] = '%s Mbit/s' % de(groesse * 8 / dauer / 1e6, 0)
    return aus


def packen(texte, zeilen, zeichen, abstand, breite=558, polster=40):
    """Texte der Reihe nach auf Zeilen verteilen; was nicht mehr passt, faellt weg. Ergebnis {(zeile, spalte): text}"""
    aus, r, c, frei = {}, 1, 0, breite
    for text in texte:
        w = len(text) * zeichen + polster
        if w > breite:
            continue
        if w > frei and c:
            r, c, frei = r + 1, 0, breite
        if r > zeilen:
            break
        c += 1
        aus[(r, c)] = text
        frei -= w + abstand
    return aus


def home_keys(home):
    """Alle Properties dieser Seite (Kodi kann Window-Properties nicht auflisten): feste Namen"""
    namen = ['dims', 'stereo', 'bild', 'res', 'dyn', 'codec', 'aspect', 'audio', 'audiocount', 'subs', 'subslangs', 'size', 'container',
             'bitrate', 'rating', 'ratingsrc', 'votes', 'runtime', 'premiered', 'added', 'lastplayed', 'fsk',
             'versions', 'versions.kurz', 'audioname', 'audiosub', 'fanart', 'clearlogo', 'poster', 'id', 'lang',
             'userrating']
    namen += ['gr1.%d' % c for c in range(1, 7)] + ['tr%d.%d' % (r, c) for r in range(1, 5) for c in range(1, 7)]
    namen += ['audio.%d.%s' % (i, x) for i in range(1, 7) for x in ('lang', 'codec', 'ch', 'short')]
    namen += ['sub.%d.%s' % (i, x) for i in range(1, 7) for x in ('lang', 'count')]
    namen += ['genre.%d' % i for i in range(1, 6)] + ['tag.%d' % i for i in range(1, 11)]
    return [PREFIX + n for n in namen]
