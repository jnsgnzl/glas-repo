<#
  Glas Helper (core.py, Windows): eigenen Kodi-Build einsetzen bzw. die originale kodi.exe wiederherstellen.
  Gegenstueck zu glas-core.sh der Vero. Zwei Rollen:

  -Mode runner  (von core.py gestartet, normale Rechte, unsichtbar, unabhaengig von Kodi)
      Braucht der Kodi-Ordner Administratorrechte (Programme), startet er sich selbst als -Mode apply ueber die
      Windows-Abfrage (UAC); lehnt der Nutzer ab: Ergebnis "denied", Kodi laeuft unveraendert weiter. Sonst (Ordner
      beschreibbar, z. B. Testkopie) laeuft apply direkt. Danach startet er Kodi wieder - mit normalen Rechten, nicht
      aus dem erhoehten Prozess.
  -Mode apply   (erhoeht bzw. direkt)
      Meldet "started" (core.py beendet daraufhin Kodi), wartet auf das Ende von Kodi (PID), tauscht die Dateien und
      schreibt das Ergebnis.

  Aktionen:
    install  <Source> = gepruefte neue kodi.exe; die laufende kodi.exe muss das offizielle Kodi sein (BaseSha aus dem
             Manifest) oder es liegt schon eine passende Sicherung kodi.exe.orig vor (Update des Kerns)
    remove   kodi.exe.orig zurueck an ihren Platz

  Ergebnisse in <WorkDir>\result: ok | 3 (kein Original, nichts geaendert) | denied | timeout | failed: <Text>
#>
param(
    [ValidateSet('runner', 'apply')][string]$Mode,
    [ValidateSet('install', 'remove')][string]$Action,
    [string]$KodiDir,
    [int]$KodiPid,
    [string]$WorkDir,
    [string]$Source = '',
    [string]$BaseSha = '',
    [string]$BuildSha = ''
)
$ErrorActionPreference = 'Stop'
$exe = Join-Path $KodiDir 'kodi.exe'
$orig = Join-Path $KodiDir 'kodi.exe.orig'
$result = Join-Path $WorkDir 'result'
$started = Join-Path $WorkDir 'started'
$logFile = Join-Path $WorkDir 'glas-core.log'

function Log([string]$text) { Add-Content -LiteralPath $logFile -Value ("{0:yyyy-MM-dd HH:mm:ss} {1} {2}" -f (Get-Date), $Mode, $text) -Encoding UTF8 }
function Sha([string]$path) { if (Test-Path -LiteralPath $path) { (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower() } else { '' } }
function Done([string]$text) { Set-Content -LiteralPath $result -Value $text -Encoding ASCII; Log "Ergebnis: $text" }

function Writable([string]$dir) {
    $probe = Join-Path $dir ('.glas-probe-' + [guid]::NewGuid().ToString('N'))
    try { [IO.File]::WriteAllText($probe, ''); Remove-Item -LiteralPath $probe -Force; return $true } catch { return $false }
}

if ($Mode -eq 'runner') {
    Log "$Action in $KodiDir (Kodi PID $KodiPid)"
    $self = $MyInvocation.MyCommand.Path
    $common = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$self`"", '-Mode', 'apply',
        '-Action', $Action, '-KodiDir', "`"$KodiDir`"", '-KodiPid', $KodiPid, '-WorkDir', "`"$WorkDir`"")
    if ($Source) { $common += @('-Source', "`"$Source`"") }
    if ($BaseSha) { $common += @('-BaseSha', $BaseSha) }
    if ($BuildSha) { $common += @('-BuildSha', $BuildSha) }
    try {
        if (Writable $KodiDir) {
            $p = Start-Process powershell.exe -ArgumentList $common -WindowStyle Hidden -PassThru
        } else {
            $p = Start-Process powershell.exe -ArgumentList $common -Verb RunAs -WindowStyle Hidden -PassThru
        }
    } catch {
        Done 'denied'   # Windows-Abfrage abgelehnt: Kodi laeuft weiter, nichts geaendert
        exit 0
    }
    $p.WaitForExit()
    # Kodi wieder starten, sobald es beendet wurde (auch nach einem Fehler: die alte kodi.exe ist dann unveraendert)
    if (Test-Path -LiteralPath $started) {
        for ($i = 0; $i -lt 240 -and (Get-Process -Id $KodiPid -ErrorAction SilentlyContinue); $i++) { Start-Sleep -Milliseconds 500 }
        Start-Sleep -Seconds 1
        Log 'starte Kodi'
        Start-Process -FilePath $exe -WorkingDirectory $KodiDir
    }
    exit 0
}

# ---- apply
try {
    Set-Content -LiteralPath $started -Value '1' -Encoding ASCII
    for ($i = 0; $i -lt 240 -and (Get-Process -Id $KodiPid -ErrorAction SilentlyContinue); $i++) { Start-Sleep -Milliseconds 500 }
    if (Get-Process -Id $KodiPid -ErrorAction SilentlyContinue) { Done 'timeout'; exit 0 }
    Start-Sleep -Seconds 1   # Windows gibt die Datei kurz nach dem Prozessende frei

    if ($Action -eq 'install') {
        $cur = Sha $exe
        if ((Sha $orig) -ne $BaseSha) {
            # Original erst sichern; es muss das offizielle Kodi sein, zu dem der Build passt
            if ($cur -ne $BaseSha) { Done '3'; exit 0 }
            Copy-Item -LiteralPath $exe -Destination "$orig.tmp" -Force
            Move-Item -LiteralPath "$orig.tmp" -Destination $orig -Force
        }
        Copy-Item -LiteralPath $Source -Destination "$exe.tmp" -Force
        if ((Sha "$exe.tmp") -ne $BuildSha) { Remove-Item -LiteralPath "$exe.tmp" -Force; Done 'failed: Pruefsumme'; exit 0 }
        Move-Item -LiteralPath "$exe.tmp" -Destination $exe -Force
        Done 'ok'
    } else {
        if (-not (Test-Path -LiteralPath $orig)) {
            # keine Sicherung: ist die laufende kodi.exe schon das Original, gibt es nichts zu tun
            if ($BaseSha -and (Sha $exe) -eq $BaseSha) { Done 'ok' } else { Done '3' }
            exit 0
        }
        Copy-Item -LiteralPath $orig -Destination "$exe.tmp" -Force
        Move-Item -LiteralPath "$exe.tmp" -Destination $exe -Force
        Remove-Item -LiteralPath $orig -Force
        Done 'ok'
    }
} catch {
    Done ('failed: ' + $_.Exception.Message)
}
