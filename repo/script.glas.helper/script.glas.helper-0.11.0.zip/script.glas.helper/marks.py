"""Glas Helper (Dienst): Abzeichen "Neu" auf Kacheln.

tvOS markiert neue Titel mit einer Kapsel "Neu" oben links. Kodi-Bedingungen koennen nicht mit Datumswerten rechnen
(ListItem.DateAdded ist nur Text), daher setzt der Dienst eine eigene Art-Sorte "glasnew" in Kodis Datenbank: der Skin
fragt !String.IsEmpty(ListItem.Art(glasnew)) ab (wie glasstereo in stereo.py; Art-Sorten sieht der Nutzer nirgends).

Neu ist, was in den letzten DAYS Tagen hinzukam und noch nicht gesehen ist: Filme, Folgen, und eine Serie mit
mindestens einer solchen Folge. Geschrieben wird nur bei einer Aenderung. Ausloeser: Start des Dienstes, jeder
Bibliotheks-Scan, das Ende einer Wiedergabe (gesehen) und alle 6 Stunden (Ablauf der Frist). Nicht bei
VideoLibrary.OnUpdate: das loest jedes eigene Set*Details selbst aus.
"""
import json
import threading
import time

import xbmc

ART = 'glasnew'
VALUE = 'special://skin/media/glas/badge-new.png'  # beliebiger Wert; der Skin prueft nur "nicht leer"
DAYS = 14
EVERY = 6 * 3600

_lock = threading.Lock()
_timer = None


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.glas.helper] %s' % msg, level)


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def is_new(item, cutoff):
    return (item.get('playcount') or 0) == 0 and (item.get('dateadded') or '') >= cutoff


def update(kind, key, item, want):
    have = bool((item.get('art') or {}).get(ART))
    if have == want:
        return 0
    rpc('VideoLibrary.Set%sDetails' % kind, **{key: item[key], 'art': {ART: VALUE if want else None}})
    return 1


def sync():
    cutoff = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() - DAYS * 86400))
    changed = 0
    with _lock:
        props = ['dateadded', 'playcount', 'art']
        for movie in rpc('VideoLibrary.GetMovies', properties=props).get('movies', []):
            changed += update('Movie', 'movieid', movie, is_new(movie, cutoff))
        shows = set()
        for ep in rpc('VideoLibrary.GetEpisodes', properties=props + ['tvshowid']).get('episodes', []):
            want = is_new(ep, cutoff)
            if want:
                shows.add(ep.get('tvshowid'))
            changed += update('Episode', 'episodeid', ep, want)
        for show in rpc('VideoLibrary.GetTVShows', properties=['art']).get('tvshows', []):
            changed += update('TVShow', 'tvshowid', show, show['tvshowid'] in shows)
    if changed:
        log('Abzeichen "Neu": %d Eintraege geaendert' % changed)


def schedule(delay=20.0):
    """Gebuendelt nach einer kurzen Pause; danach wieder nach EVERY Sekunden (Frist laeuft ab)."""
    global _timer
    if xbmc.Monitor().abortRequested():  # Kodi beendet: keinen neuen Faden mehr (service.py, stop_threads)
        return
    if _timer:
        _timer.cancel()
    _timer = threading.Timer(delay, _run)
    _timer.daemon = True
    _timer.start()


def _run():
    try:
        sync()
    except Exception as e:  # nur Komfort
        log('Abzeichen "Neu": %s' % e, xbmc.LOGWARNING)
    if not xbmc.Monitor().abortRequested():
        schedule(EVERY)
