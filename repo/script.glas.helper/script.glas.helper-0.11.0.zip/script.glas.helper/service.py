"""Glas Helper, Dienst: weichgezeichneter Hintergrund fuer die Glas-Flaechen des Skins Glas (Liquid Glass).

Kodi kann im Skin nicht live weichzeichnen. Der Hintergrund ist ohne Video aber ein bekanntes Bild (Fanart): Der Skin
nennt es in drei Labels (39990 Bildpfad, 39991 Farbmultiplikation wie colordiffuse, 39992 Satz der Verlaeufe darueber).
Der Dienst rechnet die Verlaeufe ein, zeichnet einmal weich und schneidet fuer jede Flaeche aus
special://skin/extras/glass.json den passenden Ausschnitt zu.
Ergebnis: Window(Home).Property(glas.glass.<name>) = Bildpfad, Window(Home).Property(glas.glass) = 1,
Window(Home).Property(glas.glass.<name>.luma) = mittlere Helligkeit (0-255) des Ausschnitts vor dem Abdunkeln (der Skin
schaltet damit z. B. die Ziffern der Uhr ueber hellem Hintergrund auf dunkel, wie Liquid Glass in tvOS).
Ueber laufendem Video (VideoGlass) dasselbe aus kleinen Videobildern: glas.vglass.<name>, glas.vglass.
"""
import io
import json
import os
import re
import threading
import time
from urllib.parse import unquote

import xbmc
import xbmcgui
import xbmcvfs

import appearance  # Darstellung Automatisch: Hell bei Tag, Dunkel bei Nacht (appearance.py)
import avr  # was am AV-Receiver ankommt (avr.py)
import core  # Live-Glas-Kern: Zustand, neuer Build, Notfall-Rueckweg (core.py)
import display3d  # 3D-Kreis im Kontrollzentrum (display3d.py)
import cine  # Logo-Poster (cine.py)
import marks  # Abzeichen "Neu" auf Kacheln (marks.py)
import seekthumbs  # Vorschaubilder der Spulvorschau aus dem Bild-Cache (seekthumbs.py)
import stereo  # Stereo-Poster aus den Kodex-Tiefenkarten (stereo.py)
import subpos  # Untertitel im Scope-Modus ueber dem unteren Balken (subpos.py)
import tags3d  # Schlagwort 3D fuer den Mediathek-Eintrag (tags3d.py)
import wake  # Profilwahl nach dem Ruhezustand, Avatar-Farbe (wake.py)

try:
    import fcntl  # nur Linux (Vero); unter Windows gibt es keine Amlogic-Aufnahme
except ImportError:
    fcntl = None
try:
    from PIL import Image, ImageEnhance, ImageFilter, ImageOps, ImageStat
except ImportError:  # ohne Pillow bleibt der Skin beim deckenden Material
    Image = None

HOME = xbmcgui.Window(10000)
# Glasbilder im Arbeitsspeicher, wo moeglich (Linux /dev/shm): schnell und schont den Flash-Speicher der Vero
TEMP = '/dev/shm/glas_glass/' if os.path.isdir('/dev/shm') else xbmcvfs.translatePath('special://temp/glas_glass/')
SCALE = 4               # Arbeitsaufloesung: ein Viertel der Skin-Koordinaten (1920 x 1080 -> 480 x 270)


def skin_size():
    """Skin-Koordinaten (Breite, Hoehe) wie die Fassungen in der addon.xml des Skins (Kodi waehlt sie nach dem
    Seitenverhaeltnis): ab 16:9 1080 hoch (21:9: 2560 x 1080), schmalere Formate 1920 breit (16:10: 1920 x 1200).
    Vorher rechnete der Dienst immer mit 1080 Zeilen, auf 16:10 also mit 1728 x 1080 - das Glas fehlte dort
    ("box can't exceed original image size", 01.11.2026)."""
    try:
        a, b = xbmc.getInfoLabel('Skin.AspectRatio').split(':')
        ratio = float(a) / float(b)
    except ValueError:
        return 1920, 1080
    if ratio >= 16 / 9 - 0.01:
        return round(1080 * ratio), 1080
    return 1920, round(1920 / ratio)


def skin_width():
    """Breite der Skin-Koordinaten: 1920 bei 16:9 und 16:10, 2560 bei 21:9."""
    return skin_size()[0]


def tall_shift():
    """16:10-Fassung (Skin: $EXP[glas_tall]): was unten haengt, steht dort 120 tiefer (Abschnitt "tall" in glass.json).
    3:2 und 4:3 behalten wie im Skin die 1080er-Lage."""
    return 120 if xbmc.getInfoLabel('Skin.AspectRatio') == '16:10' else 0


def work_size():
    w, h = skin_size()
    return (round(w / SCALE), round(h / SCALE))


def resolve(x, w, width, margin=80):
    """Anker aus glass.json: negatives x zaehlt von rechts, Breite 0 reicht bis margin vor den rechten Rand."""
    if x < 0:
        x = width + x - w
    if w == 0:
        w = width - margin - x
    return x, w
BLUR = 10               # Radius in Arbeitspixeln, etwa 40 px am Bildschirm (Apple: Blur 50)
SATURATION = 1.5        # Apples Materialien heben die Saettigung an (etwas kraeftiger als vorher 1.35)
BASE = (20, 20, 22)     # Grundfarbe hinter halbtransparentem Fanart
SETTLE = 0.15           # Sekunden ohne Wechsel, bevor neu gerechnet wird (Blaettern)
STEP = 0.25             # Takt des Dienstes in Sekunden
MAX_LUMA = 112          # hellere Ausschnitte abdunkeln (wie Liquid Glass ueber hellem Inhalt), Text bleibt lesbar


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.glas.helper] ' + msg, level)


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def read_file(path):
    f = xbmcvfs.File(path, 'rb')
    try:
        return bytes(f.readBytes())
    finally:
        f.close()


def load_config():
    try:
        return json.loads(read_file('special://skin/extras/glass.json').decode('utf-8'))
    except Exception as e:  # Skin ohne Glas-Flaechen
        log('glass.json nicht lesbar: %s' % e, xbmc.LOGDEBUG)
        return {}


# Scope-Modus (Skin.String(glas_screen), docs/plan-scope.md): Rand oben und unten je Format in Skin-Pixeln (Formate wie
# die OSMC Skin, Scope edition); "custom" = eigene Raender aus der Kalibrierung (screencal.py)
SCOPE_MARGIN = {'2.40': 140, '2.35': 131, '2.33': 128, '2.00': 60}


def scope_margins():
    """(oben, unten) des Scope-Modus; (0, 0) ohne Leinwand-Format und mit der 21:9-Fassung des Skins (dort passt alles
    ohnehin)."""
    if skin_size() != (1920, 1080):
        return 0, 0
    screen = xbmc.getInfoLabel('Skin.String(glas_screen)')
    if screen == 'custom':
        def edge(name):
            value = xbmc.getInfoLabel('Skin.String(glas_screen_%s)' % name)
            return int(value) if value.isdigit() else 0
        return edge('top'), edge('bottom')
    margin = SCOPE_MARGIN.get(screen, 0)
    return margin, margin


def load_regions():
    """Flaechen aus glass.json; im Scope-Modus dort, wohin der Skin sie verschiebt bzw. verkleinert ("scope")."""
    config = load_config()
    regions = config.get('regions', {})
    shift = tall_shift()
    if shift:
        # 16:10 (Skin: glas_tall): "down" = um 120 an den unteren Rand, Liste = feste Lage (volle Hoehe 1200)
        return moved_regions(regions, config.get('tall', {}), shift, 0)
    top, bottom = scope_margins()
    if not top and not bottom:
        return regions
    return moved_regions(regions, config.get('scope', {}), top, bottom)


def moved_regions(regions, anchors, down, up):
    moved = {}
    for name, (x, y, w, h) in regions.items():
        anchor = anchors.get(name)
        if anchor == 'down':
            y += down
        elif anchor == 'up':
            y -= up
        elif isinstance(anchor, list):
            x, y, w, h = anchor
        moved[name] = [x, y, w, h]
    return moved


def source_bytes(path):
    """Bild bevorzugt aus Kodis Bild-Cache lesen (kein Netzwerkzugriff), sonst ueber das VFS."""
    if path.startswith('image://'):
        path = unquote(path[len('image://'):].rstrip('/'))
    textures = rpc('Textures.GetTextures', filter={'field': 'url', 'operator': 'is', 'value': path},
                   properties=['cachedurl']).get('textures') or []
    for texture in textures:
        if texture.get('cachedurl'):
            data = read_file('special://thumbnails/' + texture['cachedurl'])
            if data:
                return data
    return read_file(path)


def tinted(img, tint):
    """Farbmultiplikation wie Kodis colordiffuse (AARRGGBB); Alpha mischt mit der dunklen Grundfarbe."""
    if len(tint) != 8:
        return img
    try:
        a, r, g, b = (int(tint[i:i + 2], 16) for i in range(0, 8, 2))
    except ValueError:
        return img
    if (r, g, b) != (255, 255, 255):
        img = Image.merge('RGB', [band.point(lambda v, f=f: v * f // 255) for band, f in zip(img.split(), (r, g, b))])
    if a < 255:
        img = Image.blend(Image.new('RGB', img.size, BASE), img, a / 255)
    return img


def with_overlays(img, overlays, cache):
    """Verlaeufe des Skins wie gezeichnet darueberlegen (Textur auf die Flaeche gestreckt). Angaben fuer 1080 Zeilen;
    hoehere Fassungen (16:10) strecken die Verlaeufe wie der Skin ueber die volle Hoehe."""
    img = img.convert('RGBA')
    width = img.size[0] * SCALE
    stretch = img.size[1] * SCALE / 1080
    for texture, x, y, w, h in overlays:
        x, w = resolve(x, w, width, margin=0)
        y, h = y * stretch, h * stretch
        if texture not in cache:
            cache[texture] = Image.open(io.BytesIO(read_file('special://skin/media/' + texture))).convert('RGBA')
        size = (max(1, round(w / SCALE)), max(1, round(h / SCALE)))
        layer = Image.new('RGBA', img.size, (0, 0, 0, 0))
        layer.paste(cache[texture].resize(size, Image.BILINEAR), (round(x / SCALE), round(y / SCALE)))
        img = Image.alpha_composite(img, layer)
    return img.convert('RGB')


def publish(img, regions, kind, counter, files, quality=88):
    """Weichzeichnen, je Flaeche zuschneiden, zu helle Ausschnitte abdunkeln und als Datei ablegen.
    kind: "glass" (Hintergrundbild) oder "vglass" (laufendes Video); Pfade in Window(Home).Property(glas.<kind>.<name>).
    Gibt die geschriebenen Dateien zurueck; die vorletzte Fassung bleibt (Kodi blendet noch ueber), aeltere werden geloescht."""
    img = ImageEnhance.Color(img).enhance(SATURATION)
    img = img.filter(ImageFilter.GaussianBlur(BLUR))
    written = []
    width = img.size[0] * SCALE
    # verschobene Flaechen (Scope-Modus) koennen ueber den Bildrand ragen: dort Grundfarbe (liegt unter den Balken)
    over_top = max([0] + [-y for _x, y, _w, _h in regions.values()])
    over_bottom = max([0] + [y + h - img.size[1] * SCALE for _x, y, _w, h in regions.values()])
    pad_top = -(-over_top // SCALE)
    if over_top or over_bottom:
        img = ImageOps.expand(img, border=(0, pad_top, 0, -(-over_bottom // SCALE)), fill=BASE)
    for name, (x, y, w, h) in regions.items():
        x, w = resolve(x, w, width)
        box = (x / SCALE, y / SCALE + pad_top, (x + w) / SCALE, (y + h) / SCALE + pad_top)
        crop = img.resize((max(1, round(w / 2)), max(1, round(h / 2))), Image.BILINEAR, box=box)
        luma = ImageStat.Stat(crop.convert('L')).mean[0]
        HOME.setProperty('glas.%s.%s.luma' % (kind, name), str(int(luma)))
        if luma > MAX_LUMA:
            crop = ImageEnhance.Brightness(crop).enhance(MAX_LUMA / luma)
        path = os.path.join(TEMP, '%s_%s_%d.jpg' % (kind, name, counter))
        crop.save(path, 'JPEG', quality=quality)
        written.append(path)
        HOME.setProperty('glas.%s.%s' % (kind, name), path)
    HOME.setProperty('glas.' + kind, '1')
    for old in files[:-len(written)] if files else []:
        try:
            os.remove(old)
        except OSError:
            pass
    return files[-len(written):] + written


AMVIDEOCAP = '/dev/amvideocap0'
# Amlogic-Videoaufnahme (Vero): ioctl wie Hyperions Amlogic-Grabber (Amvideocap.h), Bild BGR, Groesse Vielfache von 32
AML_SET_WIDTH = 0x40045602      # _IOW('V', 0x02, int)
AML_SET_HEIGHT = 0x40045603     # _IOW('V', 0x03, int)
AML_SET_WAIT_MAX_MS = 0x40085605  # _IOW('V', 0x05, unsigned long long)
AML_SET_AT_FLAGS = 0x40045606   # _IOW('V', 0x06, int)
AML_AT_CURRENT = 0
# Diese Decoder legen auf der Vero standardmaessig nur komprimierte Bilder ab (double_write_mode 0), die Aufnahme waere
# Farbrauschen. Mit double_write_mode 3 schreiben sie zusaetzlich ein unkomprimiertes Viertelbild, das sich aufnehmen laesst.
AML_DOUBLE_WRITE = {'hevc': 'amvdec_h265', 'h265': 'amvdec_h265', 'av1': 'amvdec_av1', 'vp9': 'amvdec_vp9'}


class DoubleWrite:
    """Skin-Schalter glas_aml_doublewrite: setzt auf Amlogic-Geraeten double_write_mode der HEVC-/AV1-/VP9-Decoder auf 3
    (zusaetzliches unkomprimiertes Viertelbild, das sich aufnehmen laesst). Braucht Root: sudo ohne Passwort (OSMC).
    Gilt bis zum Neustart; der Dienst setzt den Wert deshalb bei jedem Start. Beim Ausschalten zurueck auf 0."""
    MODULES = sorted(set(AML_DOUBLE_WRITE.values()))

    def __init__(self):
        self.available = fcntl is not None and os.path.exists(AMVIDEOCAP)
        self.wanted = None

    @staticmethod
    def write(value):
        import subprocess
        for module in DoubleWrite.MODULES:
            path = '/sys/module/%s/parameters/double_write_mode' % module
            if not os.path.exists(path):
                continue
            try:
                with open(path) as f:
                    if f.read().strip() == value:
                        continue
                subprocess.run(['sudo', '-n', 'tee', path], input=value.encode(), stdout=subprocess.DEVNULL,
                               stderr=subprocess.PIPE, timeout=5, check=True)
            except Exception as e:
                log('double_write_mode fuer %s nicht gesetzt: %s' % (module, e), xbmc.LOGWARNING)
                return
        log('double_write_mode = %s' % value)

    def tick(self):
        if not self.available:
            return
        wanted = xbmc.getCondVisibility('Skin.HasSetting(glas_aml_doublewrite)')
        if wanted == self.wanted:
            return
        if wanted:
            self.write('3')
        elif self.wanted:  # nur zuruecksetzen, wenn der Schalter in dieser Sitzung ausgeschaltet wurde
            self.write('0')
        self.wanted = wanted


def aml_capturable(codec):
    module = AML_DOUBLE_WRITE.get(codec)
    if not module:
        return True
    try:
        with open('/sys/module/%s/parameters/double_write_mode' % module) as f:
            return f.read().strip() not in ('', '0')
    except OSError:
        return False


class VideoGlass:
    """Glas ueber laufendem Video: solange eine Glasflaeche ueber dem Video offen ist, wird ein kleines Videobild geholt
    (etwa 4 je Sekunde, pausiert 1 je Sekunde), an die Stelle des Videos im Bild gesetzt (mit Balken) und daraus werden
    dieselben Ausschnitte wie beim Hintergrundbild gerechnet.
    Quelle: auf Amlogic-Geraeten (Vero) /dev/amvideocap0, weil Kodis RenderCapture dort nichts liefert; sonst RenderCapture.
    Bei HEVC, AV1 und VP9 nur mit double_write_mode != 0 (siehe AML_DOUBLE_WRITE), sonst bleiben die Flaechen deckend."""
    PANELS = 'Window.IsVisible(1120) | Window.IsVisible(1123) | Window.IsVisible(volumebar)'
    # je offener Flaeche nur deren Ausschnitte rechnen (vorher alle zehn bei jedem Bild)
    VISIBLE = (('Window.IsVisible(1120)', ('ccbar', 'ccbar24', 'ccpanel', 'ccprofiles')),
               ('Window.IsVisible(1123)', ('playerpanel',)),
               ('Window.IsVisible(volumebar)', ('volume',)))
    FPS = 8                 # Bilder je Sekunde bei laufendem Video, pausiert 2
    WIDTH = 256

    def __init__(self):
        self.capture = None
        self.aml = fcntl is not None and os.path.exists(AMVIDEOCAP)
        self.last = -10.0
        self.active = False
        self.counter = 0
        self.files = []
        self.failures = 0       # Aufnahmen ohne Bild in Folge; ab 8 fuer diese Sitzung aus
        self.disabled = False

    def clear(self):
        HOME.clearProperty('glas.vglass')
        for name in load_regions():
            HOME.clearProperty('glas.vglass.' + name)
            HOME.clearProperty('glas.vglass.%s.luma' % name)
        self.active = False

    def failed(self, reason):
        self.failures += 1
        if self.failures >= 8:
            # nicht weiter versuchen: Kodi schreibt je Fehlversuch einen Fehler ins Log, die Flaechen bleiben deckend
            log('Videoaufnahme liefert kein Bild (%s): Glas ueber Video fuer diese Sitzung aus' % reason, xbmc.LOGWARNING)
            self.disabled = True

    @staticmethod
    def video_aspect():
        try:
            return float(xbmc.getInfoLabel('VideoPlayer.VideoAspect')) or 16 / 9
        except ValueError:
            return 16 / 9

    def grab_aml(self):
        codec = xbmc.getInfoLabel('VideoPlayer.VideoCodec').lower()
        if not codec or not aml_capturable(codec):
            return None, None  # bewusst nicht aufnehmen (Codec noch unbekannt oder komprimierte Bilder), kein Fehler
        w, h = self.WIDTH, 160  # Hardware skaliert das ganze Bild auf w x h, das Seitenverhaeltnis stellt paste() wieder her
        fd = os.open(AMVIDEOCAP, os.O_RDWR)
        try:
            fcntl.ioctl(fd, AML_SET_WIDTH, w)
            fcntl.ioctl(fd, AML_SET_HEIGHT, h)
            fcntl.ioctl(fd, AML_SET_AT_FLAGS, AML_AT_CURRENT)
            fcntl.ioctl(fd, AML_SET_WAIT_MAX_MS, 100)
            data = os.pread(fd, w * h * 3, 0)
        except BlockingIOError:
            return None, None  # gerade kein Bild bereit (Start, Spulen): beim naechsten Mal wieder
        finally:
            os.close(fd)
        if len(data) != w * h * 3:
            self.failed('%d Bytes statt %d' % (len(data), w * h * 3))
            return None, None
        self.failures = 0
        img = Image.frombytes('RGB', (w, h), data, 'raw', 'BGR')
        if xbmc.getInfoLabel('VideoPlayer.HdrType'):
            # HDR kommt ohne Umrechnung nach SDR an (flau, blass): Kontrast und Farbe fuer das Glas anheben
            img = ImageEnhance.Color(ImageOps.autocontrast(img, cutoff=1)).enhance(1.4)
        return img, self.video_aspect()

    def grab(self):
        if self.aml:
            return self.grab_aml()
        if self.capture is None:
            self.capture = xbmc.RenderCapture()
        aspect = self.capture.getAspectRatio() or 16 / 9
        w = self.WIDTH
        h = max(1, int(round(w / aspect)))
        self.capture.capture(w, h)
        data = self.capture.getImage(500)
        if not data or len(data) < w * h * 4:
            self.failed('RenderCapture, %d Bytes statt %d' % (len(data or b''), w * h * 4))
            return None, aspect
        self.failures = 0
        return Image.frombuffer('RGBA', (w, h), bytes(data), 'raw', 'BGRA', 0, 1).convert('RGB'), aspect

    def tick(self, now):
        if self.disabled:
            return
        want = xbmc.getCondVisibility('Player.HasVideo + !Skin.HasSetting(glas_no_glass) + [%s]' % self.PANELS)
        if not want:
            if self.active:
                self.clear()
            return
        interval = 0.5 if xbmc.getCondVisibility('Player.Paused') else 1.0 / self.FPS
        if now - self.last < interval:
            return
        self.last = now
        try:
            frame, aspect = self.grab()
            if frame is None:
                return
            # Video wie im Bild einpassen (Balken oben/unten bzw. links/rechts schwarz)
            work = work_size()
            if aspect >= work[0] / work[1]:
                size = (work[0], max(1, round(work[0] / aspect)))
            else:
                size = (max(1, round(work[1] * aspect)), work[1])
            img = Image.new('RGB', work, (0, 0, 0))
            img.paste(frame.resize(size, Image.BILINEAR), ((work[0] - size[0]) // 2, (work[1] - size[1]) // 2))
            self.counter += 1
            regions = load_regions()
            names = [n for cond, group in self.VISIBLE if xbmc.getCondVisibility(cond) for n in group]
            regions = {n: r for n, r in regions.items() if n in names} or regions
            self.files = publish(img, regions, 'vglass', self.counter, self.files, quality=80)
            self.active = True
        except Exception as e:
            log('Videoglas nicht berechnet: %s' % e, xbmc.LOGWARNING)
            self.last = now + 5  # bei Fehlern (z. B. Aufnahme nicht unterstuetzt) seltener versuchen


class Glass:
    def __init__(self):
        self.textures = {}
        self.rendered = None    # (Pfad, Faerbung) des aktuellen Glases
        self.pending = None
        self.pending_since = 0
        self.counter = 0
        self.files = []
        self.regions = None     # Flaechen der letzten Berechnung (neu rechnen, wenn glass.json sich aendert)
        self.width = 1920
        self.checked = 0
        os.makedirs(TEMP, exist_ok=True)
        for name in os.listdir(TEMP):
            try:
                os.remove(os.path.join(TEMP, name))
            except OSError:
                pass

    def current_source(self):
        if xbmc.getCondVisibility('Player.HasVideo | Skin.HasSetting(glas_no_glass)'):
            return ('', '', '')
        if not xbmc.getCondVisibility('Control.IsVisible(39990)'):
            # Control.GetLabel liest im obersten Fenster; ein Dialog ohne die Glas-Felder (Kontrollzentrum, Auswahl ...)
            # liefert sonst "kein Bild" und das Glas verschwaende. Dann gilt das Glas des Fensters darunter weiter.
            return None
        src = xbmc.getInfoLabel('Control.GetLabel(39990)')
        tint = xbmc.getInfoLabel('Control.GetLabel(39991)')
        overlay = xbmc.getInfoLabel('Control.GetLabel(39992)')
        return (src, tint, overlay)  # ohne Bild (z. B. Suche, Einstellungen): Glas weg, sonst bliebe das alte stehen

    def clear(self):
        HOME.clearProperty('glas.glass')
        for name in load_regions():
            HOME.clearProperty('glas.glass.' + name)
            HOME.clearProperty('glas.glass.%s.luma' % name)
        self.rendered = ('', '', '')

    def render(self, src, tint, overlay):
        config = load_config()
        regions = load_regions()
        self.regions = regions
        self.width = skin_width()
        if not regions:
            return
        img = Image.open(io.BytesIO(source_bytes(src)))
        work = work_size()
        img.draft('RGB', (work[0] * 2, work[1] * 2))
        img = ImageOps.fit(img.convert('RGB'), work, Image.BILINEAR)
        img = tinted(img, tint)
        img = with_overlays(img, config.get('overlays', {}).get(overlay, []), self.textures)
        self.counter += 1
        self.files = publish(img, regions, 'glass', self.counter, self.files)

    def tick(self, now):
        if self.rendered and self.rendered[0] and now - self.checked >= 5:
            self.checked = now
            if load_regions() != self.regions or skin_width() != self.width:
                self.rendered = None  # Flaechen, Seitenverhaeltnis (16:9 / 21:9) oder Leinwand geaendert: neu rechnen
        source = self.current_source()
        if source is None or source == self.rendered:
            self.pending = None
            return
        if source != self.pending:
            self.pending, self.pending_since = source, now
            return
        if now - self.pending_since < SETTLE:
            return
        self.pending = None
        src, tint, overlay = source
        if not src:
            self.clear()
            return
        try:
            self.render(src, tint, overlay)
            self.rendered = source
        except Exception as e:
            log('Glas fuer %s nicht berechnet: %s' % (src, e), xbmc.LOGWARNING)
            self.clear()
            self.rendered = source


class ThemeMusic:
    """Titelmelodie einer Serie (theme.mp3 im Serienordner, z. B. von tinyMediaManager) leise abspielen, solange ihre
    Detailseite oder ihre Staffeln/Folgen offen sind - wie Plex oder Infuse; beim Verlassen ausblenden.
    Nie ueber laufender Wiedergabe; die Lautstaerke wird fuer die Melodie gesenkt und danach wiederhergestellt
    (auch nach einem Absturz beim naechsten Start, Skin.String(glas_theme_volume)). Aus mit Skin.HasSetting(glas_no_themes).
    Lautstaerke per Builtin SetVolume: Application.SetVolume (JSON-RPC) blendet jedes Mal die Lautstaerkeleiste ein."""
    LEVEL = 0.6             # Anteil der aktuellen Lautstaerke
    SETTLE = 0.8            # Sekunden in derselben Serie, bevor die Melodie startet (Durchblaettern)
    NAMES = ('theme.mp3', 'theme.flac', 'theme.ogg', 'theme.m4a')

    def __init__(self):
        self.player = xbmc.Player()
        self.playing = None     # Pfad der laufenden Melodie
        self.volume = None      # Lautstaerke vor der Melodie
        self.wanted = None
        self.since = 0
        self.started = 0
        self.paths = {}         # tvshowid -> Pfad der Melodie oder ''
        left = xbmc.getInfoLabel('Skin.String(glas_theme_volume)')
        if left.isdigit():      # vom letzten Lauf liegen geblieben: Lautstaerke zuruecksetzen
            xbmc.executebuiltin('SetVolume(%d)' % int(left))
        xbmc.executebuiltin('Skin.Reset(glas_theme_volume)')

    def show_id(self):
        if xbmc.getCondVisibility('Skin.HasSetting(glas_no_themes) | Player.HasVideo | [Player.HasAudio + String.IsEmpty(Window(Videos).Property(PlayingBackgroundMedia))]'):
            return None
        if xbmc.getCondVisibility('Window.IsActive(movieinformation)'):
            kind = xbmc.getInfoLabel('ListItem.DBType')
            if kind == 'tvshow':
                return xbmc.getInfoLabel('ListItem.DBID') or None
            if kind in ('season', 'episode'):
                return xbmc.getInfoLabel('ListItem.TvShowDBID') or None
            return None
        if xbmc.getCondVisibility('Window.IsActive(videos) + [Container.Content(seasons) | Container.Content(episodes)]'):
            return xbmc.getInfoLabel('ListItem.TvShowDBID') or None
        return None

    def theme_path(self, show):
        """Pfad der Melodie, '' ohne Melodie, None solange die Suche laeuft. Ein schlafendes NAS braucht beim ersten
        Zugriff mehrere Sekunden: eigener Thread, damit Glas und Dienst weiterlaufen."""
        if show not in self.paths:
            self.paths[show] = None
            threading.Thread(target=self.find, args=(show,), daemon=True).start()
        return self.paths[show]

    def find(self, show):
        folder = rpc('VideoLibrary.GetTVShowDetails', tvshowid=int(show), properties=['file']).get('tvshowdetails', {}).get('file', '')
        sep = '\\' if '\\' in folder and '/' not in folder else '/'
        folder = folder if not folder or folder.endswith(('/', '\\')) else folder + sep
        try:
            files = xbmcvfs.listdir(folder)[1] if folder else []   # ein Ordnerzugriff statt je Name einer
        except Exception:
            files = []
        names = {f.lower(): f for f in files}
        self.paths[show] = next((folder + names[n] for n in self.NAMES if n in names), '')

    def start(self, path):
        self.stop(fade=False)
        volume = rpc('Application.GetProperties', properties=['volume']).get('volume')
        if isinstance(volume, int):
            self.volume = volume
            xbmc.executebuiltin('Skin.SetString(glas_theme_volume,%d)' % volume)
            xbmc.executebuiltin('SetVolume(%d)' % max(1, round(volume * self.LEVEL)))
        xbmcgui.Window(10025).setProperty('PlayingBackgroundMedia', '1')
        item = xbmcgui.ListItem(path=path)
        self.player.play(path, item, True)
        self.playing = path
        self.started = time.monotonic()

    def restore(self):
        if self.volume is not None:
            xbmc.executebuiltin('SetVolume(%d)' % self.volume)
            self.volume = None
        xbmc.executebuiltin('Skin.Reset(glas_theme_volume)')
        xbmcgui.Window(10025).clearProperty('PlayingBackgroundMedia')
        self.playing = None

    def stop(self, fade=True):
        if not self.playing:
            return
        try:
            mine = self.player.isPlayingAudio() and self.player.getPlayingFile() == self.playing
        except RuntimeError:
            mine = False
        if mine:
            if fade and self.volume:
                start = max(1, round(self.volume * self.LEVEL))
                for k in range(1, 6):   # etwa eine halbe Sekunde ausblenden
                    xbmc.executebuiltin('SetVolume(%d)' % max(0, round(start * (1 - k / 6))))
                    xbmc.sleep(90)
            self.player.stop()
        self.restore()

    def tick(self, now):
        # eine andere Wiedergabe hat uebernommen (z. B. Folge gestartet): nur Lautstaerke zuruecksetzen
        if self.playing and xbmc.getCondVisibility('Player.HasVideo'):
            self.restore()
        show = self.show_id()
        if show != self.wanted:
            self.wanted, self.since = show, now
        path = self.theme_path(show) if show and now - self.since >= self.SETTLE else (self.playing if show else None)
        if path == self.playing:
            # (Start abwarten: Player.HasAudio wird erst nach dem Oeffnen der Datei wahr)
            if self.playing and time.monotonic() - self.started > 3 and not xbmc.getCondVisibility('Player.HasAudio'):
                self.restore()          # Melodie zu Ende: Lautstaerke zurueck, nicht wiederholen
                self.paths[show] = ''   # in dieser Sitzung nicht erneut fuer diese Serie
            return
        if path:
            self.start(path)
        elif self.playing and not show:
            self.stop()


class FolderNames:
    """Dateimanager: Kodi schreibt den Pfad in die Kopfzeilen 101/102 und kennt dort keinen Ordnernamen. Wie Apples Listen
    zeigt der Skin nur den Namen; er steht in Window(Home).Property(glas_fm_101 / glas_fm_102)."""
    HEADERS = (101, 102)
    SPECIAL = {'special://profile': 20070}  # Profilverzeichnis

    def __init__(self):
        self.last = {}

    @staticmethod
    def name(path):
        path = (path or '').strip()
        if '://' not in path and '\\' not in path and '/' not in path:
            return path  # oberste Ebene: Kodis Text ("Hauptordner")
        trimmed = path.rstrip('/\\')
        if trimmed in FolderNames.SPECIAL:
            return xbmc.getLocalizedString(FolderNames.SPECIAL[trimmed])
        if trimmed.endswith(':'):  # Laufwerk ("C:") oder nur ein Protokoll ("smb:")
            return trimmed
        segment = trimmed.replace('\\', '/').rsplit('/', 1)[-1]
        return unquote(segment) or trimmed

    def tick(self):
        home = xbmcgui.Window(10000)
        if not xbmc.getCondVisibility('Window.IsVisible(filemanager)'):  # auch unter Dialogen
            if self.last:
                for control in self.HEADERS:
                    home.clearProperty('glas_fm_%d' % control)
                self.last = {}
            return
        for control in self.HEADERS:
            # unter einem Dialog liest Control.GetLabel dessen Bedienelemente (leer): letzten Namen behalten
            value = self.name(xbmc.getInfoLabel('Control.GetLabel(%d)' % control)) or self.last.get(control, '')
            # mit dem Fenster vergleichen, nicht nur mit dem letzten Wert: ReloadSkin leert die Eigenschaften
            if home.getProperty('glas_fm_%d' % control) != value:
                home.setProperty('glas_fm_%d' % control, value)
            self.last[control] = value


class CmsRows:
    """Zeilen im Farbverwaltungs-Menue des Players (osdcmssettings) fuer die Hoehe seines Popovers (GlasPlayerMenu in
    Includes_Glas_Settings.xml): Kodi zeigt im Modus 3D-LUT 3 Zeilen, mit ICC-Profil 6, mit Gammawert (Gammamodus nicht
    BT.1886) 7. Zahlen-Einstellungen kann der Skin nicht lesen -> Window(Home).Property(glas.cmsrows), nur solange das
    Menue offen ist (eine Abfrage je halbe Sekunde; ein Moduswechsel im Menue aendert die Hoehe gleich mit)."""

    def __init__(self):
        self.last = 0.0

    def tick(self, now):
        if now - self.last < 0.5 or not xbmc.getCondVisibility('Window.IsActive(osdcmssettings)'):
            return
        self.last = now
        rows = 3
        if self.setting('videoscreen.cmsmode') == 1:
            rows = 6 if self.setting('videoscreen.cmsgammamode') == 0 else 7
        if HOME.getProperty('glas.cmsrows') != str(rows):
            HOME.setProperty('glas.cmsrows', str(rows))

    @staticmethod
    def setting(name):
        """Wert ueber JSON-RPC; bei ausgeschalteter Farbverwaltung lehnt Kodi das ab (die abhaengigen Einstellungen gelten
        dann als unsichtbar, das Menue zeigt sie trotzdem ausgegraut) - dann der gespeicherte Wert aus guisettings.xml
        (fehlt er dort, gilt Kodis Vorgabe 0)."""
        value = rpc('Settings.GetSettingValue', setting=name).get('value')
        if value is not None:
            return value
        text = read_file('special://profile/guisettings.xml').decode('utf-8', 'replace')
        found = re.search(r'<setting id="%s"[^>]*>(\d+)</setting>' % re.escape(name), text)
        return int(found.group(1)) if found else 0


def core_build():
    """Eigener Kodi-Build mit Live-Glas (tools/kodi-build)? Erkennbar an der Markierung im Startlog. Setzt
    Window(Home).Property(glas.corebuild), damit die Skin-Einstellung "Live-Glas" erscheint."""
    try:
        with open(os.path.join(xbmcvfs.translatePath('special://logpath'), 'kodi.log'), encoding='utf-8',
                  errors='replace') as f:
            head = f.read(65536)
    except OSError:
        head = ''
    found = 'Glas: eigener Kodi-Build' in head
    if found:
        HOME.setProperty('glas.corebuild', '1')
        # Live-Glas beim ersten Kern einmal einschalten: wer den Kern installiert, erwartet es; aus blieben die zarten
        # vorab gerechneten Glasbilder (Testerbericht 05.11.2026: "Glas-Effekt zu wenig ausgepraegt"). Der Merker
        # glas_coreblur_auto verhindert, dass ein spaeteres bewusstes Ausschalten wieder ueberstimmt wird.
        if not xbmc.getInfoLabel('Skin.String(glas_coreblur_auto)'):
            if not xbmc.getCondVisibility('Skin.HasSetting(glas_coreblur)'):
                xbmc.executebuiltin('Skin.SetBool(glas_coreblur)')
                log('Live-Glas eingeschaltet (erster Glas-Kern)')
            xbmc.executebuiltin('Skin.SetString(glas_coreblur_auto,1)')
    else:
        HOME.clearProperty('glas.corebuild')
    # Video-Glas: der Build holt das Videobild selbst (Live-Glas auch ueber laufendem Video)
    if found and 'Video-Glas' in head:
        HOME.setProperty('glas.corevideo', '1')
    else:
        HOME.clearProperty('glas.corevideo')
    # Stereo-Texturen: <texture stereo="sbs"> zeigt je Auge eine Haelfte (Stereo-Poster des Dienstes, stereo.py)
    if found and 'Stereo-Texturen' in head:
        HOME.setProperty('glas.corestereo', '1')
    else:
        HOME.clearProperty('glas.corestereo')
    # Glas-Knoepfe: <glass> legt Live-Glas unter Knoepfe (Einstellungszeilen, die Kodi selbst baut)
    if found and 'Glas-Knoepfe' in head:
        HOME.setProperty('glas.corebutton', '1')
    else:
        HOME.clearProperty('glas.corebutton')
    # Glas-Breite: <fitgrouplist> passt Live-Glas an eine Grouplist an (Logo-Pille mit wechselnden Stuecken)
    if found and 'Glas-Breite' in head:
        HOME.setProperty('glas.corefit', '1')
    else:
        HOME.clearProperty('glas.corefit')
    # Glas-Ebenen: Live-Glas ueber Live-Glas bekommt einen eigenen Griff (Kreis "Hinzufuegen" auf der Glaskarte des
    # Kontrollzentrums flackerte ohne)
    if found and 'Glas-Ebenen' in head:
        HOME.setProperty('glas.corelayers', '1')
    else:
        HOME.clearProperty('glas.corelayers')
    # Kontextmenue-Lage: der Kern setzt das Kontextmenue neben die fokussierte Kachel (GlasFocusItem.h)
    if found and 'Kontextmenue-Lage' in head:
        HOME.setProperty('glas.corectx', '1')
    else:
        HOME.clearProperty('glas.corectx')
    # Buchstaben-Sprung: Container.JumpLetter(id,buchstabe) fuer die Buchstabenleiste der Mediathek
    if found and 'Buchstaben-Sprung' in head:
        HOME.setProperty('glas.coreletter', '1')
    else:
        HOME.clearProperty('glas.coreletter')
    # Gummiband: der Kern federt Listen und Grouplists am Ende selbst (GlasBand.h); der Skin laesst dann sein eigenes
    # Federn an der Mediathek-Leiste (5700) weg
    if found and 'Gummiband' in head:
        HOME.setProperty('glas.coreband', '1')
    else:
        HOME.clearProperty('glas.coreband')
    # Spulvorschau: Bildadresse glasseek://<Datei>/<Zeit> (Vorschaubild beim Spulen, DialogSeekBar)
    if found and 'Spulvorschau' in head:
        HOME.setProperty('glas.coreseek', '1')
    else:
        HOME.clearProperty('glas.coreseek')
    return found


def main():
    # Der OSMC-Update-Dienst platziert sein Symbol erst, wenn diese Werte (sonst vom OSMC-Skin) gesetzt sind, und
    # versucht es bis dahin immer wieder; ein ReloadSkin in dieser Zeit liess Kodi abstuerzen (setPosition auf ein
    # freigegebenes Control)
    HOME.setProperty('SkinHeight', '1080')
    HOME.setProperty('SkinWidth', '1920')
    core_build()
    core.schedule(20)  # Live-Glas-Kern (eigener Faden, fragt das Manifest im Netz ab)
    display3d.update()  # 3D-Kreis nur, wenn die Ausgabe 1080p Frame Packing kennt
    # ohne Pillow kein Glas, Titelmelodien und Double-Write laufen trotzdem
    if Image is None:
        log('Pillow fehlt, Glas-Hintergrund aus', xbmc.LOGWARNING)
    monitor = wake.WakeMonitor()  # xbmc.Monitor mit Aufwach-Erkennung
    glass = Glass() if Image else None
    video = VideoGlass() if Image else None
    double_write = DoubleWrite()
    receiver = avr.Poller()  # AV-Receiver finden, waehrend der Wiedergabe abfragen (avr.py)
    watch3d = display3d.Watch()  # 3D: GPU-Warten nur mit Video, Stereomodus nach der Wiedergabe (display3d.py)
    theme = ThemeMusic()
    folders = FolderNames()
    cms_rows = CmsRows()
    auto_theme = appearance.Auto()
    sub_margin = subpos.SubtitleMargin()
    start = time.monotonic()
    cards_done = False
    last_double_write = 0.0
    # 4 Durchlaeufe je Sekunde: jede Abfrage (getInfoLabel, getCondVisibility) sperrt kurz die Oberflaeche; mit 10 je
    # Sekunde (etwa 60 Abfragen) wurde Kodi auf Dauer hakelig. Das Glas folgt ohnehin erst nach SETTLE.
    while not monitor.waitForAbort(STEP / 2 if video and video.active else STEP):
        clock = time.monotonic() - start
        if not cards_done and clock > 30:  # Add-on-Kacheln (eigener Prozess, blockiert den Dienst nicht)
            cards_done = True
            xbmc.executebuiltin('RunPlugin(plugin://script.glas.helper/?action=cards)')
            tags3d.schedule(0)  # 3D-Schlagwort fuer die Mediathek (tags3d.py, eigener Faden)
            stereo.schedule(30)  # danach die Stereo-Poster (stereo.py, eigener Faden; 3D-Filme zuerst)
            marks.schedule(10)  # Abzeichen "Neu" (marks.py, eigener Faden, danach alle 6 Std.)
            cine.schedule(90)  # Logo-Poster (cine.py, eigener Faden, nach den Stereo-Postern)
            seekthumbs.schedule(0)  # Vorschaubilder einer Wiedergabe vor dem Neustart (seekthumbs.py)
        if glass:
            # Live-Glas im Kodi-Kern ersetzt die vorab berechneten Glasbilder (nicht ueber Video) - nur, wenn der
            # laufende Kern es kann (glas.corebuild); im normalen Kodi bleibt die Einstellung sonst wirkungslos an
            if not xbmc.getCondVisibility('Skin.HasSetting(glas_coreblur) + !Player.HasVideo + '
                                          '!String.IsEmpty(Window(Home).Property(glas.corebuild))'):
                glass.tick(clock)
            # Video-Glas im Kodi-Kern ersetzt die Videobild-Ausschnitte des Dienstes
            if xbmc.getCondVisibility('Skin.HasSetting(glas_coreblur) + '
                                      '!String.IsEmpty(Window(Home).Property(glas.corevideo))'):
                if video.active:
                    video.clear()
            else:
                video.tick(clock)
        watch3d.tick()
        receiver.tick()
        theme.tick(clock)
        folders.tick()
        cms_rows.tick(clock)
        auto_theme.tick(clock)
        sub_margin.tick(clock, scope_margins)
        monitor.tick()
        if clock - last_double_write >= 2:
            last_double_write = clock
            double_write.tick()
    if glass:
        glass.clear()
        video.clear()
    theme.stop(fade=False)
    stop_threads()


def stop_threads(limit=3.0):
    """Kodi wartet beim Beenden auf jeden Python-Faden des Dienstes, auch auf Hintergrundfaeden (daemon). Liefen noch
    Zeitgeber (Logo-Poster, Stereo-Poster, "Neu", 3D-Schlagwort, Kern-Pruefung ...), blieb Kodi nach "script didn't stop
    in 5 seconds" haengen und liess sich nicht beenden (Testerbericht 06.11.2026, Windows). Zeitgeber abbrechen, auf
    laufende Arbeit kurz warten (sie prueft abortRequested bzw. waitForAbort)."""
    for t in threading.enumerate():
        if isinstance(t, threading.Timer):
            t.cancel()
    deadline = time.monotonic() + limit
    for t in threading.enumerate():
        if t is threading.current_thread() or not t.is_alive():
            continue
        left = deadline - time.monotonic()
        if left <= 0:
            break
        t.join(left)
    rest = [t.name for t in threading.enumerate() if t is not threading.current_thread() and t.is_alive()]
    if rest:
        xbmc.log('[script.glas.helper] beim Beenden noch aktiv: %s' % ', '.join(rest), xbmc.LOGWARNING)


if __name__ == '__main__':
    main()
