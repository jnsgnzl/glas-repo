"""Glas Helper: Vorschaubilder der Spulvorschau aus Kodis Bild-Cache entfernen.

Der Skin zeigt beim Spulen glasseek://<Datei>/<Zeit> (DialogSeekBar, Kern: tools/kodi-build/glas-patches.txt). Kodi legt
jedes dieser Bilder wie ein Poster dauerhaft in den Bild-Cache (Textures13.db, userdata/Thumbnails); ohne Aufraeumen
wuechse er mit jedem Spulen. Nach dem Stopp der Wiedergabe und beim Start des Dienstes werden sie entfernt (im
Hintergrund, Kodis eigene Funktion Textures.RemoveTexture loescht Eintrag und Datei).
"""
import json
import threading

import xbmc

PREFIX = 'glasseek://'


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def purge():
    textures = rpc('Textures.GetTextures', properties=['url'],
                   filter={'field': 'url', 'operator': 'startswith', 'value': PREFIX}).get('textures', [])
    removed = 0
    for texture in textures:
        if texture.get('url', '').startswith(PREFIX):
            rpc('Textures.RemoveTexture', textureid=texture['textureid'])
            removed += 1
    if removed:
        xbmc.log('[script.glas.helper] Spulvorschau: %d Bilder aus dem Bild-Cache entfernt' % removed, xbmc.LOGINFO)


def schedule(delay=5):
    """nach dem Stopp: kurz warten (das letzte Bild kann noch geladen werden), dann im Hintergrund aufraeumen"""
    if xbmc.Monitor().abortRequested():  # Kodi beendet: keinen neuen Faden mehr (service.py, stop_threads)
        return
    timer = threading.Timer(delay, purge)
    timer.daemon = True
    timer.start()
