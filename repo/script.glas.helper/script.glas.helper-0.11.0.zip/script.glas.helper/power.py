"""Glas Helper: Energie und Untermenues des Kontrollzentrums.

plugin://script.glas.helper/?info=ccmenu&menu=sleep|audio  Zeilen des Untermenues im Kontrollzentrum (Liste 1180):
                                                          Label, Label2 (Unterzeile), Icon, Property "selected"
plugin://script.glas.helper/?action=sleep&set=<stufe>     Sleep-Timer setzen: off, 120, 60, 30, 15 (Minuten) oder
                                                          end (Ende der laufenden Folge bzw. des Films); merkt die Stufe in
                                                          Skin.String(glas_sleep) und kehrt zur Kachel 1131 zurueck
plugin://script.glas.helper/?action=power&do=suspend    Ruhezustand (Suspend(), sonst CECStandby), ohne Rueckfrage
plugin://script.glas.helper/?action=power&do=reboot|powerdown
                                                          Neustart, Ausschalten mit Rueckfrage (Glas-Alert)
plugin://script.glas.helper/?action=power&do=quit       Kodi beenden, standardmaessig ohne Rueckfrage (Testerbericht
                                                          05.11.2026: "Wirklich beenden?" stoert); mit der Skin-Einstellung
                                                          glas_quit_confirm ("Sofort beenden" aus) mit Rueckfrage
plugin://script.glas.helper/?action=audio&...             siehe audio.py

Das Kontrollzentrum laedt die Liste neu, sobald sich Window(Home).Property(glas_ccmenu_v) aendert (steht im Pfad).
"""
import time

import xbmc
import xbmcgui
import xbmcplugin

BASE = 'plugin://script.glas.helper/'
ALARM = 'shutdowntimer'
# Stufen wie tvOS 27.2 (Simulator n2-kz-profil-timer, Ruhezustandstimer): absteigend "2 Stunden / 1 Stunde /
# 30 Minuten / 15 Minuten", Fokus oben; vorher aufsteigend mit 45 Minuten und "Aus" (mit Haken) davor
STEPS = ('120', '60', '30', '15')
# Puffer nach dem Ende einer Folge, damit Abspann und naechster Start nicht abgeschnitten werden
END_MARGIN = 60


def loc(string_id):
    """Skin-String (Glas ist aktiv, der Helper laeuft nur mit diesem Skin)."""
    return xbmc.getInfoLabel('$LOCALIZE[%d]' % string_id)


def bump():
    """Pfad der Untermenue-Liste aendern, damit Kodi sie neu laedt."""
    xbmc.executebuiltin('SetProperty(glas_ccmenu_v,%d,home)' % int(time.time() * 1000 % 100000000))


def item(label, path, label2='', icon='', selected=False):
    li = xbmcgui.ListItem(label, label2, offscreen=True)
    if icon:
        li.setArt({'icon': icon, 'thumb': icon})
    li.setProperty('selected', 'true' if selected else '')
    return (path, li, False)


def remaining_seconds():
    """Restzeit der laufenden Videowiedergabe in Sekunden, sonst 0."""
    player = xbmc.Player()
    try:
        if player.isPlayingVideo():
            return max(0, int(player.getTotalTime() - player.getTime()))
    except RuntimeError:
        pass
    return 0


def end_label():
    if xbmc.getCondVisibility('VideoPlayer.Content(episodes)'):
        return loc(31423)
    if xbmc.getCondVisibility('VideoPlayer.Content(movies)'):
        return loc(31424)
    return loc(31425)


def list_sleep():
    """Zeilen des Ruhezustandstimers. Ohne laufenden Timer nur die Stufen (kein "Aus", kein Haken -> das Kontrollzentrum
    fokussiert die erste Zeile wie tvOS); laeuft einer, steht "Aus" oben und die laufende Stufe traegt den Haken
    (Fokus springt dorthin, GlasCCTile Param pick)."""
    active = xbmc.getCondVisibility('System.HasAlarm(%s)' % ALARM)
    stage = xbmc.getInfoLabel('Skin.String(glas_sleep)') if active else 'off'
    items = [item(loc(31419), BASE + '?action=sleep&set=off')] if active else []
    for step in STEPS:
        minutes = int(step)
        if minutes == 60:
            label = loc(31421)
        elif minutes % 60 == 0:
            label = loc(31422) % (minutes // 60)
        else:
            label = loc(31420) % minutes
        items.append(item(label, BASE + '?action=sleep&set=' + step, selected=stage == step))
    rest = remaining_seconds()
    if rest > 0 or stage == 'end':
        caption = loc(31426) % max(1, (rest + 59) // 60) if rest > 0 else ''
        items.append(item(end_label(), BASE + '?action=sleep&set=end', caption, selected=stage == 'end'))
    return items


def list_menu(handle, menu):
    if menu == 'sleep':
        items = list_sleep()
    elif menu == 'audio':
        import audio
        items = audio.list_audio()
    else:
        items = []
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def set_sleep(stage):
    xbmc.executebuiltin('CancelAlarm(%s,true)' % ALARM)
    seconds = 0
    if stage in STEPS:
        seconds = int(stage) * 60
    elif stage == 'end':
        rest = remaining_seconds()
        seconds = rest + END_MARGIN if rest > 0 else 0
    if seconds > 0:
        stamp = '%02d:%02d:%02d' % (seconds // 3600, seconds // 60 % 60, seconds % 60)
        # Shutdown(): Aktion aus Kodis Energieeinstellungen (wie Kodis eigener Sleep-Timer)
        xbmc.executebuiltin('AlarmClock(%s,Shutdown(),%s,true)' % (ALARM, stamp))
        xbmc.executebuiltin('Skin.SetString(glas_sleep,%s)' % stage)
    else:
        xbmc.executebuiltin('Skin.Reset(glas_sleep)')
    bump()
    # zurueck zur Kachel; deren onfocus schliesst das Untermenue
    xbmc.executebuiltin('SetFocus(1131)')


CONFIRM = {
    # Aktion: (Titel, Text, Ja-Button, Builtin)
    'reboot': (31411, 31414, 31417, 'Reset()'),
    'powerdown': (31412, 31415, 13016, 'Powerdown()'),
    'quit': (31413, 31416, 31418, 'Quit()'),
}


def confirm(kind):
    # Beenden ohne Rueckfrage: Kodi neu zu starten kostet wenig, die Frage stoerte bei jedem Beenden; wer sie will,
    # schaltet "Sofort beenden" aus (SkinSettings 733)
    if kind == 'quit' and not xbmc.getCondVisibility('Skin.HasSetting(glas_quit_confirm)'):
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('Quit()')
        return
    if kind not in CONFIRM:
        return
    heading, text, yes, builtin = CONFIRM[kind]
    yes_label = xbmc.getLocalizedString(yes) if yes < 30000 else loc(yes)
    # Fokus auf "Abbrechen": ein versehentliches OK schaltet nichts aus
    kwargs = {'nolabel': xbmc.getLocalizedString(222), 'yeslabel': yes_label}
    if hasattr(xbmcgui, 'DLG_YESNO_NO_BTN'):
        kwargs['defaultbutton'] = xbmcgui.DLG_YESNO_NO_BTN
    if xbmcgui.Dialog().yesno(loc(heading), loc(text), **kwargs):
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin(builtin)


def suspend():
    """Ruhezustand wie Apple: Geraet schlafen legen, sonst wenigstens den Fernseher per CEC."""
    xbmc.executebuiltin('Dialog.Close(all,true)')
    if xbmc.getCondVisibility('System.CanSuspend'):
        xbmc.executebuiltin('Suspend()')
    else:
        # Kodi laeuft weiter: die erste Bedienung danach gilt als Aufwachen (Profilwahl, wake.py)
        xbmcgui.Window(10000).setProperty('glas.standby', '1')
        xbmc.executebuiltin('CECStandby')


def run(action, query):
    if action == 'sleep':
        set_sleep(query.get('set', 'off'))
    elif action == 'power' and query.get('do') == 'suspend':
        suspend()
    elif action == 'power':
        confirm(query.get('do', ''))
    elif action == 'audio':
        import audio
        audio.run(query)
