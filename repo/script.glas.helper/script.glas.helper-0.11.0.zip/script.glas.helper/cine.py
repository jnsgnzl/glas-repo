"""Glas Helper (Dienst): Logo-Poster wie tvOS ("Cinematic poster art").

tvOS zeigt statt des Kinoplakats ein textloses Bild (Key-Art), darauf unten mittig das Titel-Logo und das Genre; der
untere Teil ist weich verwischt und abgedunkelt. Der Dienst rechnet das je Film und Serie einmal vor:

  1. Key-Art (Art-Sorte keyart, liefern der TMDb-Scraper bzw. fanart.tv) mittig auf 480 x 720 zugeschnitten.
  2. Echter Unschaerfeverlauf: eine weichgezeichnete Fassung blendet ueber eine weiche Maske ein (oben scharf, ab
     BLUR_FROM voll verwischt), darueber eine Abdunklung nach unten.
  3. Clearlogo (transparente Raender abgeschnitten) unten mittig, darunter das erste Genre (Inter Medium).

Weil das Bild fest ist, ergibt das Vorrechnen denselben Verlauf wie ein Shader im Kern - ohne Kosten beim Zeichnen
und auch ohne Live-Glas-Kern. Ohne Key-Art oder Logo bleibt das normale Poster.

Ablage wie die Stereo-Poster (stereo.py): special://masterprofile/addon_data/script.glas.helper/cine/<art>.jpg, Pfad als
Art-Sorte "glascine" in Kodis Datenbank; der Skin nimmt sie in GlasPosterArtVar (Skin-Einstellung "Poster mit Logo").
index.json merkt Herkunft und Verfahren; neu gerechnet wird nur bei Aenderung. Nicht waehrend ein Film laeuft.
Ausloeser: Start des Dienstes (verzoegert) und jeder Bibliotheks-Scan.
"""
import io
import json
import os
import threading
import time

import xbmc
import xbmcvfs

from stereo import drop_cached, file_sig, poster_source, read_file, unwrap, wait_idle

try:
    from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps
except ImportError:  # ohne Pillow keine Logo-Poster (der Skin zeigt die normalen)
    Image = None

ART = 'glascine'
FOLDER = 'special://masterprofile/addon_data/script.glas.helper/cine/'
FONT = 'special://home/addons/skin.glas/fonts/Inter-Medium.ttf'
SIZE = (480, 720)               # passt ungeteilt in Kodis Bildcache (imageres 720), Poster im Skin 260 x 390
BLUR = 16                       # Weichzeichnen der unteren Fassung (Pixel bei 480 Breite)
BLUR_START, BLUR_FROM = 0.50, 0.76   # Maske: ab 50 % der Hoehe beginnt der Verlauf, ab 76 % ist er voll
SHADE_START, SHADE_MAX = 0.42, 165   # Abdunklung ab 42 % der Hoehe, unten Deckkraft 165/255
LOGO_BOX = (0.78, 0.17)         # Logo hoechstens 78 % der Breite und 17 % der Hoehe
LOGO_BOTTOM = 0.875             # Unterkante des Logos (Anteil der Hoehe)
GENRE_SIZE = 38                 # entspricht ~21 px am Poster 390 hoch (tvOS 22-24 px)
GENRE_TOP = 0.905               # Oberkante der Genrezeile
GENRE_ALPHA = 200               # zwischen Apples 60 % ruhend und Weiss im Fokus (eingebacken, ohne Fokuswechsel)
ALGO = 'cine-3-%s-%s-%s-%s-%s-%s' % (SIZE, BLUR, BLUR_FROM, SHADE_MAX, LOGO_BOX, GENRE_SIZE)
PAUSE = 0.3

_lock = threading.Lock()
_timer = None


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.glas.helper] ' + msg, level)


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


# ---------------------------------------------------------------- Bildrechnung (ohne Kodi pruefbar)

def ramp(height, start, full, peak=255):
    """Senkrechte Maske 1 x height: 0 bis start, weich (smoothstep) auf peak bei full, darunter peak."""
    values = []
    for y in range(height):
        t = (y / float(height) - start) / max(1e-6, full - start)
        t = min(1.0, max(0.0, t))
        values.append(int(round(peak * t * t * (3 - 2 * t))))
    mask = Image.new('L', (1, height))
    mask.putdata(values)
    return mask


def trim(logo):
    """Transparente Raender des Logos abschneiden (Clearlogos haben oft breite leere Raender)."""
    logo = logo.convert('RGBA')
    box = logo.getchannel('A').point(lambda a: 255 if a > 8 else 0).getbbox()
    return logo.crop(box) if box else logo


def render(keyart, logo, genre, font_path, size=SIZE):
    w, h = size
    base = ImageOps.fit(keyart.convert('RGB'), size, Image.BICUBIC, centering=(0.5, 0.5))
    soft = base.filter(ImageFilter.GaussianBlur(BLUR))
    img = Image.composite(soft, base, ramp(h, BLUR_START, BLUR_FROM).resize(size))
    shade = Image.new('RGB', size, (0, 0, 0))
    img = Image.composite(shade, img, ramp(h, SHADE_START, 1.0, SHADE_MAX).resize(size))
    logo = trim(logo)
    scale = min(LOGO_BOX[0] * w / logo.width, LOGO_BOX[1] * h / logo.height)
    logo = logo.resize((max(1, int(logo.width * scale)), max(1, int(logo.height * scale))), Image.LANCZOS)
    img.paste(logo, ((w - logo.width) // 2, int(LOGO_BOTTOM * h) - logo.height), logo)
    if genre and font_path:
        font = ImageFont.truetype(font_path, GENRE_SIZE)
        layer = Image.new('RGBA', size, (0, 0, 0, 0))
        draw = ImageDraw.Draw(layer)
        try:
            box = draw.textbbox((0, 0), genre, font=font)
        except AttributeError:  # aelteres Pillow (Kodi unter Windows): Groesse samt Versatz
            (ox, oy), (tw, th) = font.getoffset(genre), font.getsize(genre)
            box = (ox, oy, tw, th)
        draw.text(((w - (box[2] - box[0])) // 2 - box[0], int(GENRE_TOP * h) - box[1]), genre, font=font,
                  fill=(255, 255, 255, GENRE_ALPHA))
        img = Image.alpha_composite(img.convert('RGBA'), layer).convert('RGB')
    return img


# ---------------------------------------------------------------- Kodi

class Missing(Exception):
    """Bilddatei fehlt (alter Pfad in der Bibliothek, z. B. abgezogene Platte): still ueberspringen."""


def open_image(path):
    data = read_file(path)
    if not data:
        raise Missing(path)
    return Image.open(io.BytesIO(data))


def load(path):
    img = open_image(path)
    img.draft('RGB', (SIZE[0] * 2, SIZE[1] * 2))
    return img


def set_art(kind, item, value):
    if unwrap((item.get('art') or {}).get(ART) or '') != (value or ''):
        key = kind.lower() + 'id'
        rpc('VideoLibrary.Set%sDetails' % kind, **{key: item[key], 'art': {ART: value}})


def sync():
    if Image is None:
        return
    font_path = xbmcvfs.translatePath(FONT)
    if not os.path.exists(font_path):
        font_path = ''
    folder = xbmcvfs.translatePath(FOLDER)
    os.makedirs(folder, exist_ok=True)
    index_path = os.path.join(folder, 'index.json')
    try:
        with open(index_path, encoding='utf-8') as f:
            index = json.load(f)
    except (OSError, ValueError):
        index = {}
    monitor = xbmc.Monitor()
    done = made = 0
    started = time.monotonic()
    with _lock:
        lists = (('Movie', rpc('VideoLibrary.GetMovies', properties=['art', 'genre']).get('movies', [])),
                 ('TVShow', rpc('VideoLibrary.GetTVShows', properties=['art', 'genre']).get('tvshows', [])))
        for kind, items in lists:
            for item in items:
                if not wait_idle(monitor):
                    return
                art = item.get('art') or {}
                if not art.get('keyart') or not art.get('clearlogo'):
                    if art.get(ART):
                        set_art(kind, item, None)
                    continue
                key = '%s%d' % (kind.lower(), item[kind.lower() + 'id'])
                target = FOLDER + key + '.jpg'
                local = os.path.join(folder, key + '.jpg')
                before = made
                try:
                    key_path, key_stamp = poster_source(art['keyart'])
                    logo_path, logo_stamp = poster_source(art['clearlogo'])
                    genre = (item.get('genre') or [''])[0]
                    stamp = {'keyart': key_stamp, 'logo': logo_stamp, 'genre': genre, 'algo': ALGO}
                    if index.get(key) != stamp or not os.path.exists(local):
                        img = render(load(key_path), open_image(logo_path), genre, font_path)
                        img.save(local + '.tmp', 'JPEG', quality=88)
                        os.replace(local + '.tmp', local)
                        index[key] = stamp
                        drop_cached(target)
                        made += 1
                        if made % 20 == 0:
                            with open(index_path, 'w', encoding='utf-8') as f:
                                json.dump(index, f, indent=1, sort_keys=True)
                    set_art(kind, item, target)
                    done += 1
                except Missing as e:
                    log('Logo-Poster fuer %s: Bild fehlt (%s)' % (item.get('label'), e), xbmc.LOGDEBUG)
                except Exception as e:  # ein Titel darf die anderen nicht aufhalten
                    log('Logo-Poster fuer %s nicht gerechnet: %s' % (item.get('label'), e), xbmc.LOGWARNING)
                if monitor.waitForAbort(PAUSE if made > before else 0.01):
                    return
        with open(index_path, 'w', encoding='utf-8') as f:
            json.dump(index, f, indent=1, sort_keys=True)
    log('Logo-Poster: %d Titel mit Key-Art und Logo, %d neu gerechnet (%.0f s)' % (done, made, time.monotonic() - started))


def schedule(delay=60.0):
    global _timer
    if xbmc.Monitor().abortRequested():  # Kodi beendet: keinen neuen Faden mehr (service.py, stop_threads)
        return
    if _timer:
        _timer.cancel()
    _timer = threading.Timer(delay, _run)
    _timer.daemon = True
    _timer.start()


def _run():
    try:
        sync()
    except Exception as e:  # nur Komfort
        log('Logo-Poster: %s' % e, xbmc.LOGWARNING)
