"""Glas Helper: Merkliste wie tvOS (Knopf "+" bzw. Haken auf der Detailseite, Reihe auf der TV-Seite).

Gemerkt wird als Schlagwort TAG in Kodis Bibliothek (Filme und Serien), so bleibt die Liste in der Datenbank, gilt fuer
alle Profile mit gemeinsamer Bibliothek und ist auch in Kodis Schlagwort-Ansicht zu finden.

plugin://script.glas.helper/?action=watchlist&type=movie|tvshow&id=N
    Schlagwort setzen bzw. entfernen. Danach Window(movieinformation).Property(glas_wl) = 1 bzw. leer (Zustand des
    Knopfs, die Detailseite liest ihn beim Oeffnen aus ListItem.Tag) und Window(Home).Property(glas.wl.stamp) neu,
    damit die Reihe der TV-Seite (Inhalt mit &stamp=...) neu laedt.
plugin://script.glas.helper/?info=watchlist[&limit=30]
    Gemerkte Filme und Serien, zuletzt hinzugefuegte zuerst; Gesehenes faellt heraus (Filme gesehen, Serien ohne
    ungesehene Folge), das Schlagwort bleibt. Filme spielen ohne Rueckfrage (?action=play), Serien oeffnen die
    Serie in der Mediathek.
plugin://script.glas.helper/?action=info&type=movie|tvshow&id=N
    Detailseite eines Titels (Kreis "i" im Titelbild der TV-Seite): Daten frisch aus der Bibliothek, auch das
    Schlagwort, damit der Merkliste-Knopf der Detailseite stimmt.

Titelbild der TV-Seite: Eintraege tragen glas.wlkey (",movie12,") und glas.wl (1 = gemerkt beim Laden). Die Liste laedt
nach dem Umschalten nicht neu (sie stuende sonst wieder am Anfang); toggle() fuehrt deshalb Window(Home)-Properties
glas.wl.on und glas.wl.off mit den Schluesseln der in dieser Sitzung umgeschalteten Titel.
"""
import time

import xbmcgui
import xbmcplugin

from nextup import MOVIE_PROPS, rpc, video_item

TAG = 'Merkliste'
SHOW_PROPS = ['title', 'year', 'genre', 'plot', 'art', 'rating', 'mpaa', 'premiered', 'playcount', 'episode',
              'watchedepisodes', 'dateadded', 'tag']
KINDS = {'movie': ('Movie', 'movieid', 'moviedetails'), 'tvshow': ('TVShow', 'tvshowid', 'tvshowdetails')}


def key(kind, dbid):
    return ',%s%s,' % (kind, dbid)


def mark(item, kind, data):
    """Merkliste-Zustand fuer Listen, die nach dem Umschalten nicht neu laden (Titelbild der TV-Seite)"""
    item.setProperty('glas.wlkey', key(kind, data.get(kind + 'id', '')))
    item.setProperty('glas.wl', '1' if TAG in (data.get('tag') or []) else '')


def remember(kind, dbid, on):
    home = xbmcgui.Window(10000)
    k = key(kind, dbid)
    for prop, add in (('glas.wl.on', on), ('glas.wl.off', not on)):
        value = (home.getProperty(prop) or ',').replace(k, ',')
        home.setProperty(prop, value + k[1:] if add else value)


def toggle(kind, dbid):
    if kind not in KINDS or not str(dbid).isdigit():
        return
    name, key, result = KINDS[kind]
    details = rpc('VideoLibrary.Get%sDetails' % name, **{key: int(dbid), 'properties': ['tag']}).get(result) or {}
    tags = [t for t in details.get('tag') or [] if t != TAG]
    on = len(tags) == len(details.get('tag') or [])  # war nicht gemerkt -> jetzt merken
    if on:
        tags.append(TAG)
    rpc('VideoLibrary.Set%sDetails' % name, **{key: int(dbid), 'tag': tags})
    xbmcgui.Window(12003).setProperty('glas_wl', '1' if on else '')
    remember(kind, dbid, on)
    xbmcgui.Window(10000).setProperty('glas.wl.stamp', str(int(time.time())))


def entries(limit=30):
    rule = {'field': 'tag', 'operator': 'is', 'value': TAG}
    items = []
    for movie in rpc('VideoLibrary.GetMovies', properties=MOVIE_PROPS + ['dateadded'], filter=rule).get('movies', []):
        if not movie.get('playcount'):
            items.append((movie.get('dateadded', ''), 'movie', movie))
    for show in rpc('VideoLibrary.GetTVShows', properties=SHOW_PROPS, filter=rule).get('tvshows', []):
        if (show.get('episode') or 0) > (show.get('watchedepisodes') or 0) or not show.get('episode'):
            items.append((show.get('dateadded', ''), 'tvshow', show))
    items.sort(key=lambda e: e[0], reverse=True)
    return items[:limit]


def list_watchlist(handle, limit=30):
    out = []
    for _, kind, data in entries(limit):
        url, item, folder = video_item(kind, data)
        if kind == 'tvshow':
            url, folder = 'videodb://tvshows/titles/%d/' % data['tvshowid'], True
        out.append((url, item, folder))
    xbmcplugin.setContent(handle, 'movies')
    xbmcplugin.addDirectoryItems(handle, out, len(out))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def show_info(kind, dbid):
    if kind not in KINDS or not str(dbid).isdigit():
        return
    name, key_, result = KINDS[kind]
    props = MOVIE_PROPS + ['tag'] if kind == 'movie' else SHOW_PROPS + ['file']
    data = rpc('VideoLibrary.Get%sDetails' % name, **{key_: int(dbid), 'properties': props}).get(result)
    if not data:
        return
    _url, item, _folder = video_item(kind, data)
    # Pfad wie ein Eintrag der Mediathek: Kodi findet den Titel so in der Bibliothek und laedt alle Angaben
    item.setPath(data.get('file') or 'videodb://tvshows/titles/%s/' % dbid)
    xbmcgui.Dialog().info(item)
