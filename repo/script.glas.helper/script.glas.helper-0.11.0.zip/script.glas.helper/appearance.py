"""Glas Helper: Darstellung Dunkel / Hell / Automatisch und die Bedienungshilfen als Farbthema (skin.glas/colors).

Kodi kennt nur ein aktives Farbthema (lookandfeel.skincolors). Glas setzt es aus drei Zustaenden zusammen:
  Darstellung   Skin.String(glas_appearance): leer = Dunkel, hell, auto (wie tvOS 27.2: Automatisch = hell von
                Sonnenaufgang bis Sonnenuntergang)
  Kontrast      "Kontrast erhoehen" (im Namen des Themas)
  Deckend       "Transparenz reduzieren" (Skin.HasSetting(glas_no_glass), im Namen des Themas)
Themen: SKINDEFAULT, Kontrast, Deckend, KontrastDeckend und dieselben mit Vorsilbe Hell (tools/dev/gen_colors.py).
Kodi laedt den Skin beim Wechsel neu.

plugin://script.glas.helper/?action=theme&appearance=dunkel|hell|auto   Darstellung waehlen
plugin://script.glas.helper/?action=theme&contrast=toggle|on|off        Kontrast erhoehen
plugin://script.glas.helper/?action=theme&opaque=toggle|on|off          Transparenz reduzieren (Farben; den Schalter
                                                                        glas_no_glass setzt der Skin selbst)

Automatisch: der Dienst ruft tick() auf und wechselt hoechstens einmal je Minute, nie waehrend Video laeuft oder ein
Dialog offen ist (ReloadSkin bei offenem Dialog kann Kodi abstuerzen lassen). Ort fuer den Sonnenstand: Breite 51 N,
Laenge aus der Zeitzone (15 Grad je Stunde Abstand zu UTC, ohne Sommerzeit) - fuer Mitteleuropa auf etwa 20 Minuten genau.
"""
import json
import math
import time

import xbmc

LAT = 51.0


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result') or {}
    except ValueError:
        return {}


def current():
    """Aktuelles Thema als (hell, kontrast, deckend)."""
    name = xbmc.getInfoLabel('Skin.CurrentColourTheme')
    return name.startswith('Hell'), 'Kontrast' in name, 'Deckend' in name


def name_of(hell, contrast, opaque):
    name = ('Hell' if hell else '') + ('Kontrast' if contrast else '') + ('Deckend' if opaque else '')
    return name or 'SKINDEFAULT'


def apply(hell, contrast, opaque):
    """Thema setzen, wenn es sich aendert (sonst laedt Kodi den Skin unnoetig neu)."""
    want = name_of(hell, contrast, opaque)
    if name_of(*current()) != want:
        rpc('Settings.SetSettingValue', setting='lookandfeel.skincolors', value=want)


def _flag(value, now):
    if value == 'toggle':
        return not now
    return value in ('on', '1', 'true')


def sun_up(now=None):
    """Steht die Sonne ueber dem Horizont? NOAA-Naeherung (Sonnenauf- und -untergang bei -0,833 Grad)."""
    now = time.time() if now is None else now
    local = time.localtime(now)
    lon = -time.timezone / 3600.0 * 15.0
    day = local.tm_yday
    hour = local.tm_hour + local.tm_min / 60.0
    gamma = 2 * math.pi / 365 * (day - 1 + (hour - 12) / 24)
    decl = (0.006918 - 0.399912 * math.cos(gamma) + 0.070257 * math.sin(gamma) - 0.006758 * math.cos(2 * gamma)
            + 0.000907 * math.sin(2 * gamma) - 0.002697 * math.cos(3 * gamma) + 0.00148 * math.sin(3 * gamma))
    eqtime = 229.18 * (0.000075 + 0.001868 * math.cos(gamma) - 0.032077 * math.sin(gamma)
                       - 0.014615 * math.cos(2 * gamma) - 0.040849 * math.sin(2 * gamma))
    lat = math.radians(LAT)
    cos_ha = (math.cos(math.radians(90.833)) / (math.cos(lat) * math.cos(decl)) - math.tan(lat) * math.tan(decl))
    if cos_ha <= -1:
        return True
    if cos_ha >= 1:
        return False
    ha = math.degrees(math.acos(cos_ha))
    # Minuten UTC, dann in Ortszeit (mit Sommerzeit, wie die Uhr)
    utc_offset = -(time.altzone if local.tm_isdst > 0 else time.timezone) / 60.0
    rise = 720 - 4 * (lon + ha) - eqtime + utc_offset
    sett = 720 - 4 * (lon - ha) - eqtime + utc_offset
    minute = local.tm_hour * 60 + local.tm_min
    return rise <= minute < sett


def wanted_hell():
    mode = xbmc.getInfoLabel('Skin.String(glas_appearance)')
    if mode == 'hell':
        return True
    if mode == 'auto':
        return sun_up()
    return False


def run(query):
    hell, contrast, opaque = current()
    if 'appearance' in query:
        mode = query['appearance']
        if mode in ('hell', 'auto'):
            xbmc.executebuiltin('Skin.SetString(glas_appearance,%s)' % mode)
        else:
            xbmc.executebuiltin('Skin.Reset(glas_appearance)')
        # Skin.SetString wirkt erst im naechsten Bild: Darstellung hier direkt aus dem Wunsch
        hell = mode == 'hell' or (mode == 'auto' and sun_up())
    if 'contrast' in query:
        contrast = _flag(query['contrast'], contrast)
    if 'opaque' in query:
        opaque = _flag(query['opaque'], opaque)
    apply(hell, contrast, opaque)


class Auto:
    """Automatisch: hoechstens einmal je Minute pruefen, Thema bei Sonnenauf- und -untergang wechseln."""

    def __init__(self):
        self.last = -60.0

    def tick(self, clock):
        if clock - self.last < 60:
            return
        self.last = clock
        if xbmc.getInfoLabel('Skin.String(glas_appearance)') != 'auto':
            return
        hell, contrast, opaque = current()
        want = sun_up()
        if want == hell:
            return
        if xbmc.getCondVisibility('Player.HasVideo | System.HasActiveModalDialog | System.HasVisibleModalDialog | '
                                  'Window.IsActive(virtualkeyboard) | System.ScreenSaverActive'):
            return
        apply(want, contrast, opaque)
