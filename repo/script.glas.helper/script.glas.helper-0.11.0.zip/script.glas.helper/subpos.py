"""Glas Helper (Dienst): Untertitel im Scope-Modus in den sichtbaren Streifen der Leinwand legen (docs/plan-scope.md).

Kodi setzt Untertitel mit "Unterer Bildschirmrand" (subtitles.align = 2, Vorgabe) an den unteren Bildschirmrand, mit
einem Abstand von subtitles.marginvertical Prozent der Bildhoehe (Vorgabe 4,95). Im Scope-Modus deckt dort der untere
Balken ab (Custom_1131_ScopeMask.xml, auch ueber Filmen), die Untertitel waeren unsichtbar - bei Scope-Filmen mit
eingebrannten Balken wie ohne. Der Dienst erhoeht deshalb den Abstand um die Hoehe des Balkens (bei "Oberhalb des
Bildes" und "Oberer Bildschirmrand" um die des oberen), fuer die Formate wie fuer "Eigene". Ohne Scope-Modus (und mit
der 21:9-Fassung des Skins) nimmt er die Erhoehung wieder zurueck.

- Eigene Werte bleiben: Gespeichert werden die Erhoehung und die selbst gesetzten Werte
  (addon_data/script.glas.helper/subpos.json). Grundwert ist der aktuelle Wert in Kodi minus der Erhoehung, die darin
  steckt (base_of) - wer den Abstand selbst verstellt, behaelt seine Aenderung; laedt Kodi nach hartem Ende einen
  aelteren eigenen Wert, wird er erkannt und berichtigt.
- "Manuell" (subtitles.align = 0, Untertitel-Linie der Videokalibrierung): keine Erhoehung, die Lage stellt man dort
  selbst ein (in Kodi zaehlt der Abstand dort zusaetzlich zur Linie).
- Nur ohne laufendes Video: Kodi sperrt die Einstellung waehrend der Wiedergabe (Libass verschiebt sonst beim Spulen).
  Ein Wechsel waehrend eines Films greift deshalb danach.

Bild-Untertitel (PGS von Blu-ray/UHD, DVD, DVB) setzt Kodi dorthin, wo die Datei sie vorsieht; der Abstand wirkt auf
sie nicht. Fuer sie meldet der Dienst den Streifen an den Glas-Kern (publish_strip, GlasSubtitleStrip.h).
"""
import json
import os

import xbmc
import xbmcgui
import xbmcvfs

HOME = xbmcgui.Window(10000)
STRIP = 'glas.substrip'     # Streifen fuer Bild-Untertitel im Glas-Kern (publish_strip)
ALIGN = 'subtitles.align'
MARGIN = 'subtitles.marginvertical'
ALIGN_MANUAL = 0
ALIGN_TOP = (3, 4)          # Oberhalb des Bildes / Oberer Bildschirmrand
SKIN_HEIGHT = 1080          # Scope-Modus gibt es nur mit der 1920x1080-Fassung des Skins
STEP = 0.05                 # Raster der Einstellung in Kodi
# Kodi rechnet den Abstand fuer Libass mit 720 statt 1080 Zeilen um (DVDSubtitlesLibass.cpp: MarginV = Prozent * 10,8
# * PlayResY / 720): 1 % verschiebt um 1,5 % der Bildhoehe (auf der Vero gemessen: 16 px je Prozent bei 1080 Zeilen)
LIBASS_SCALE = 1.5
CHECK = 5                   # Sekunden zwischen zwei Abfragen
HISTORY = 12                # so viele eigene Schreibvorgaenge merken (base_of)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.glas.helper] ' + msg, level)


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def state_path():
    folder = xbmcvfs.translatePath('special://profile/addon_data/script.glas.helper/')
    xbmcvfs.mkdirs(folder)
    return os.path.join(folder, 'subpos.json')


def offset_for(align, top, bottom):
    """Erhoehung in Prozent der Bildhoehe (auf das Raster von Kodi gerundet) fuer die Ausrichtung und die Balken."""
    if align == ALIGN_MANUAL:
        return 0.0
    px = top if align in ALIGN_TOP else bottom
    return round(round(px * 100.0 / SKIN_HEIGHT / LIBASS_SCALE / STEP) * STEP, 2)


class SubtitleMargin:
    def __init__(self):
        self.last = -CHECK
        self.offset = 0.0       # Erhoehung im zuletzt gesetzten Wert
        self.history = []       # [[Wert, Erhoehung], ...] der eigenen Schreibvorgaenge, neueste zuletzt
        try:
            with open(state_path(), encoding='utf-8') as f:
                state = json.load(f)
            self.offset = float(state.get('offset', 0.0))
            self.history = [[float(v), float(o)] for v, o in state.get('history', [])][-HISTORY:]
        except (OSError, ValueError, TypeError, AttributeError):
            pass

    def base_of(self, current):
        """Grundwert (Abstand ohne Erhoehung) eines Werts in Kodi. Ist es ein Wert, den der Dienst selbst gesetzt hat, gilt
        dessen Erhoehung - auch einer aelteren: Kodi speichert Einstellungen erst beim Beenden, nach einem Absturz oder
        hartem Ende laedt es einen frueheren Wert (auf der Vero am 04.11.2026: 13,60 % mit Erhoehung, obwohl zuletzt
        4,95 % gesetzt waren). Sonst hat der Nutzer ihn verstellt: dann zaehlt er mit der aktuellen Erhoehung."""
        for value, offset in reversed(self.history):
            if abs(value - current) < 0.001:
                return max(0.0, current - offset)
        return max(0.0, current - self.offset)

    @staticmethod
    def publish_strip(top, bottom):
        """Bild-Untertitel (PGS, DVD): Window(Home).Property(glas.substrip) = "oben,unten" in Zeilen von 1080, leer ohne
        Scope-Modus. Der Glas-Kern (Startlog "Untertitel-Streifen", GlasSubtitleStrip.h) rueckt Bild-Untertitel, die aus
        dem Streifen ragen, hinein; ein Kodi ohne Glas-Kern liest die Eigenschaft nicht. Gilt sofort, auch waehrend eines
        Films."""
        value = '%d,%d' % (top, SKIN_HEIGHT - bottom) if top or bottom else ''
        if HOME.getProperty(STRIP) != value:
            if value:
                HOME.setProperty(STRIP, value)
            else:
                HOME.clearProperty(STRIP)

    def save(self):
        try:
            with open(state_path(), 'w', encoding='utf-8') as f:
                json.dump({'offset': self.offset, 'history': self.history}, f)
        except OSError as e:
            log('Untertitel-Abstand nicht gespeichert: %s' % e, xbmc.LOGWARNING)

    def tick(self, now, margins):
        """margins() = (oben, unten) des Scope-Modus in Skin-Pixeln (service.scope_margins); erst nach CHECK abgefragt."""
        if now - self.last < CHECK:
            return
        self.last = now
        top, bottom = margins()
        self.publish_strip(top, bottom)
        if xbmc.getCondVisibility('Player.HasVideo'):
            return
        align = rpc('Settings.GetSettingValue', setting=ALIGN).get('value')
        if not isinstance(align, int) or isinstance(align, bool):
            return
        wanted = offset_for(align, top, bottom)
        current = rpc('Settings.GetSettingValue', setting=MARGIN).get('value')
        if not isinstance(current, (int, float)) or isinstance(current, bool):
            return
        base = self.base_of(current)
        value = round(min(50.0, base + wanted), 2)
        if abs(value - current) < 0.001:
            if abs(wanted - self.offset) >= 0.001:    # stimmt schon (z. B. Grundwert 0): nur merken
                self.remember(value, wanted)
            return
        if rpc('Settings.SetSettingValue', setting=MARGIN, value=float(value)) is not True:
            log('Untertitel-Abstand %.2f %% nicht gesetzt' % value, xbmc.LOGWARNING)
            return
        log('Untertitel-Abstand %.2f -> %.2f %% (Scope-Rand %+.2f %%)' % (current, value, wanted))
        self.remember(value, wanted)

    def remember(self, value, offset):
        self.offset = offset
        self.history = [h for h in self.history if abs(h[0] - value) >= 0.001][-(HISTORY - 1):] + [[value, offset]]
        self.save()
