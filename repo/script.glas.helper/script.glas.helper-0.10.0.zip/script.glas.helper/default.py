"""Glas Helper: Listen und Aktionen fuer den Skin Glas, die Kodi Skins nicht direkt anbietet.

plugin://script.glas.helper/?info=profiles     Profile (aktuelles mit Property "current"), danach "Profil hinzufuegen" (Property "add")
plugin://script.glas.helper/?action=load&name= Profil laden (bei Sperre fragt Kodi nach dem Code)
plugin://script.glas.helper/?action=add        Profilverwaltung oeffnen
plugin://script.glas.helper/?action=font&set=  Kodis Schriftsatz wechseln (Gross, Fett, GrossFett, Default); Kodi laedt den Skin neu
plugin://script.glas.helper/?action=colors&set= Kodis Farbschema wechseln (Kontrast bzw. SKINDEFAULT); Kodi laedt den Skin neu
plugin://script.glas.helper/?info=apps         Video- und Programm-Add-ons ohne Doppelte; bekannte Marken als Kachel in Markenfarbe mit
                                               Logo aus Simple Icons (resources/brands), sonst freigestelltes Logo (Art "logo")
                                               bzw. weichgezeichneter Kachelhintergrund (Art "tile"), siehe applogo.py
                                               &store=0 ohne "Add-ons" am Ende (liegt dann im Dock des Homescreens),
                                               &extras=1 mit Kodi-Bereichen (Musik, Bilder, Favoriten) und dem Ordner
                                               "Dienstprogramme" (Art "tile" aus skin.glas/media/glas/apps)
                                               &extras=1 mit Skin.HasSetting(glas_home_sources): dazu je Videoquelle eine
                                               Kachel (sources.py, Schluessel source:<id>)
plugin://script.glas.helper/?info=folder&name= Inhalt eines Ordners (tools)
plugin://script.glas.helper/?action=open&key=  Kodi-Bereich oeffnen (siehe SYSTEM)
plugin://script.glas.helper/?action=folder&name= Ordner auf dem Homescreen oeffnen (Window(Home).Property(glas_folder))
plugin://script.glas.helper/?action=dock&slot= Dock-Platz (1-6) des Homescreens belegen (Auswahl aus Kodi-Bereichen und Apps);
                                               legt glas_dock_<n>_key/label/action/tile/logo/icon/shelf/shelfimage als Skin-Strings ab
plugin://script.glas.helper/?action=dockdefaults Dock mit der Standardbelegung fuellen (einmal, Skin.HasSetting(glas_dock_init))
plugin://script.glas.helper/?action=dockrefresh  Belegte Dock-Plaetze neu schreiben (einmal nach neuen Feldern, glas_dock_v3);
                                               ein unveraendertes altes Standard-Dock bekommt die neue Belegung (TV vorn)
plugin://script.glas.helper/?info=nextup|random  Weiter ansehen / Zufallsreihe, ?action=play|nextep: siehe nextup.py
plugin://script.glas.helper/?action=stereo     Staerke des 3D-Effekts (lookandfeel.stereostrength) waehlen, Anzeige in glas_3d_strength
plugin://script.glas.helper/?action=stereosync Wert nur nach glas_3d_strength spiegeln (beim Oeffnen der Skin-Einstellungen)
plugin://script.glas.helper/?action=gui3d      Oberflaeche zwischen 1080p 3D (Frame Packing) und 2D umschalten, siehe display3d.py
plugin://script.glas.helper/?action=cards      Fertige Kacheln je installiertem Add-on erzeugen (logos/tiles/<id>.jpg, fuer den
                                               Add-on-Browser); startet der Dienst einmal nach dem Kodi-Start
plugin://script.glas.helper/?action=run&id=    Add-on starten
plugin://script.glas.helper/?action=store      Add-on-Browser oeffnen (letzter Eintrag der Apps)
plugin://script.glas.helper/?action=setup      Ersteinrichtung (einmal beim ersten Start des Skins): Aerial als
                                               Bildschirmschoner, wenn noch Kodis Standard eingestellt ist
plugin://script.glas.helper/?action=setup2     Einrichtung Bedienung wie Apple (einmal je Stand, Skin.HasSetting(glas_setup_v6)):
                                               Home lang = Kontrollzentrum (ueberall), im Homescreen kurz = Zurueck (Keymap glas.xml), keine ".."-Eintraege,
                                               Apple-TV-Klaenge statt Kodis Standard
plugin://script.glas.helper/?action=setup3     Einmal (Skin.HasSetting(glas_setup_v7)): fragen, ob Kodi Add-on-Updates nur melden
                                               soll (general.addonupdates 1), solange es sie noch selbst installiert
plugin://script.glas.helper/?action=screen     Leinwand (Scope-Modus) waehlen: Skin.String(glas_screen) 2.40/2.35/2.00 oder leer, Skin neu laden
plugin://script.glas.helper/?action=core       Live-Glas-Kern installieren, aktualisieren, entfernen (nur Vero V, core.py)
"""
import json
import os
import re
import sys
from urllib.parse import parse_qsl, unquote, urlencode

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

BASE = 'plugin://script.glas.helper/'


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def list_profiles(handle):
    current = rpc('Profiles.GetCurrentProfile').get('label', '')
    items = []
    for profile in rpc('Profiles.GetProfiles', properties=['thumbnail', 'lockmode']).get('profiles', []):
        name = profile['label']
        item = xbmcgui.ListItem(name, offscreen=True)
        thumb = profile.get('thumbnail') or ''
        if thumb:
            item.setArt({'thumb': thumb, 'icon': thumb})
        item.setProperty('current', 'true' if name == current else '')
        item.setProperty('locked', 'true' if profile.get('lockmode') else '')
        items.append((BASE + '?' + urlencode({'action': 'load', 'name': name}), item, False))
    add = xbmcgui.ListItem(offscreen=True)
    add.setProperty('add', 'true')
    items.append((BASE + '?action=add', add, False))
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


LOGOS = xbmcvfs.translatePath('special://profile/addon_data/script.glas.helper/logos/')


def local_path(art):
    """image://<kodierter Pfad>/ -> Dateipfad"""
    if art.startswith('image://'):
        art = unquote(art[len('image://'):].rstrip('/'))
    return xbmcvfs.translatePath(art)


BRANDS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'brands')


def brand_art(addon_id):
    """Bekannte Marken (Simple Icons, resources/brands): Kachel in Markenfarbe mit weissem Logo."""
    try:
        with open(os.path.join(BRANDS, 'brands.json'), encoding='utf-8') as f:
            data = json.load(f)
    except (OSError, ValueError):
        return {}
    slug = data.get('addons', {}).get(addon_id)
    brand = data.get('brands', {}).get(slug)
    if not brand:
        return {}
    tile = os.path.join(LOGOS, 'brand-%s-%s-tile.png' % (slug, brand['hex']))
    logo = os.path.join(LOGOS, 'brand-%s-%s-logo.png' % (slug, brand['hex']))
    if not (os.path.isfile(tile) and os.path.isfile(logo)):
        try:
            from applogo import make_brand
            tile_img, logo_img = make_brand(os.path.join(BRANDS, slug + '.png'), brand['hex'])
        except Exception as e:
            xbmc.log('[script.glas.helper] Marken-Logo %s nicht erzeugt: %s' % (slug, e), xbmc.LOGWARNING)
            return {}
        os.makedirs(LOGOS, exist_ok=True)
        tile_img.save(tile)
        logo_img.save(logo)
    return {'tile': tile, 'logo': logo}


def app_art(addon_id, icon):
    """Marken-Logo, sonst Logo bzw. Kachelhintergrund aus dem Symbol (einmal berechnet, je Symbol-Stand gespeichert)."""
    brand = brand_art(addon_id)
    if brand:
        return brand
    path = local_path(icon)
    if not path or not os.path.isfile(path):
        return {}
    stamp = int(os.path.getmtime(path))
    for kind in ('logo', 'tile'):
        cached = os.path.join(LOGOS, '%s-%d-%s.png' % (addon_id, stamp, kind))
        if os.path.isfile(cached):
            return {kind: cached}
    try:
        from applogo import make_logo
        kind, img = make_logo(path)
    except Exception as e:  # ohne Pillow oder bei kaputtem Bild: Symbol wie gehabt
        xbmc.log('[script.glas.helper] Logo fuer %s nicht erzeugt: %s' % (addon_id, e), xbmc.LOGWARNING)
        return {}
    os.makedirs(LOGOS, exist_ok=True)
    for old in os.listdir(LOGOS):
        if old.startswith(addon_id + '-'):
            os.remove(os.path.join(LOGOS, old))
    cached = os.path.join(LOGOS, '%s-%d-%s.png' % (addon_id, stamp, kind))
    img.save(cached)
    return {kind: cached}


# Kodi-Bereiche als Apps: Schluessel -> (Kodi-String, Fenster-Aufruf, Kachel unter skin.glas/media/glas/apps,
# Top Shelf auf dem Homescreen). Der Homescreen ist Kodis Startfenster (Home.xml); "overview" ist die App "TV" mit
# Titelbild und Reihen (Custom_1130_TV.xml). Top Shelf "tv"/"movies"/"episodes": Weiter ansehen, sonst Neues.
SYSTEM = {
    'movies': (20342, 'ActivateWindow(Videos,videodb://movies/titles/,return)', 'movies', 'movies'),
    'tvshows': (20343, 'ActivateWindow(Videos,videodb://tvshows/titles/,return)', 'tvshows', 'episodes'),
    'search': (137, 'ActivateWindow(1122)', 'search', ''),
    'sources': (744, 'ActivateWindow(Videos,sources://video/,return)', 'sources', ''),
    'addons': (24001, 'ActivateWindow(addonbrowser,addons://user/,return)', 'addons', ''),
    'settings': (5, 'ActivateWindow(Settings)', 'settings', ''),
    'overview': ('$LOCALIZE[31200]', 'ActivateWindow(1130)', 'tv', 'tv'),
    'music': (2, 'ActivateWindow(Music,root,return)', 'music', 'music'),
    'pictures': (1, 'ActivateWindow(Pictures,root,return)', 'pictures', ''),
    'favourites': (1036, 'ActivateWindow(FavouritesBrowser)', 'favourites', 'favourites'),
    'filemanager': (7, 'ActivateWindow(FileManager)', 'filemanager', ''),
    'eventlog': (14111, 'ActivateWindow(EventLog)', 'eventlog', ''),
    'sysinfo': (130, 'ActivateWindow(SystemInfo)', 'sysinfo', ''),
    'profiles': (13200, 'ActivateWindow(Profiles)', 'profiles', ''),
    'controlcenter': ('$LOCALIZE[31950]', 'ActivateWindow(1120)', 'controlcenter', ''),
    # Live-TV (PVR, z. B. waipu.tv): Startseite mit Reihen (Custom_1132_LiveTV.xml); nur mit Sendern im Raster
    # (PVR-Clients sind keine Video-Add-ons)
    'livetv': ('$LOCALIZE[31206]', 'ActivateWindow(1132)', 'livetv', ''),
}
FOLDERS = {'tools': ('$LOCALIZE[31993]', ['filemanager', 'eventlog', 'sysinfo', 'profiles', 'controlcenter'])}
TILES = 'special://skin/media/glas/apps/%s.png'
# Top-Shelf-Standbild je Kodi-Bereich (wie Apples statisches Bild fuer Apps ohne eigene Inhalte)
SHELF_IMAGES = 'special://skin/media/glas/apps/shelf/%s.jpg'
DOCK_SLOTS = 8  # 7 und 8 nur mit "Dock mit 8 Plaetzen (21:9)" (dock_slots)
# wie Apple: die TV-App vorn, dann die Bibliotheken, Suche, Dateien und Einstellungen (Add-ons und Musik im Raster)
DOCK_DEFAULT = ['overview', 'movies', 'tvshows', 'search', 'sources', 'settings']
DOCK_DEFAULT_V2 = ['movies', 'tvshows', 'search', 'sources', 'addons', 'settings']  # bis Glas 0.4
# Skin-Strings je Dock-Platz: glas_dock_<n>_<feld>
DOCK_FIELDS = ('key', 'label', 'action', 'tile', 'logo', 'icon', 'shelf', 'shelfimage')


def label_of(ref):
    return xbmc.getLocalizedString(ref) if isinstance(ref, int) else xbmc.getInfoLabel(ref)


def system_item(key):
    ref, _, tile, _ = SYSTEM[key]
    item = xbmcgui.ListItem(label_of(ref), offscreen=True)
    item.setArt({'tile': TILES % tile})
    return BASE + '?' + urlencode({'action': 'open', 'key': key}), item, False


def folder_item(name):
    ref, keys = FOLDERS[name]
    item = xbmcgui.ListItem(label_of(ref), offscreen=True)
    item.setProperty('folder', name)
    for n, key in enumerate(keys[:6], 1):
        item.setProperty('icon%d' % n, TILES % SYSTEM[key][2])
    return BASE + '?' + urlencode({'action': 'folder', 'name': name}), item, False


def source_item(e):
    """Kachel einer Videoquelle (sources.py): (Schluessel, Name, Aktion, Kachel)"""
    key, label, _, tile = e
    item = xbmcgui.ListItem(label, offscreen=True)
    item.setArt({'tile': tile})
    return BASE + '?' + urlencode({'action': 'open', 'key': key}), item, False


def list_folder(handle, name):
    items = [system_item(key) for key in FOLDERS.get(name, ('', []))[1]]
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def installed_apps():
    """Video- und Programm-Add-ons ohne Doppelte: [(ID, Name, Art)] nach Name sortiert"""
    apps, seen = [], set()
    for source in ('addons://sources/video/', 'addons://sources/executable/'):
        for entry in rpc('Files.GetDirectory', directory=source, properties=['art']).get('files', []):
            m = re.match(r'\w+://([^/]+)', entry.get('file', ''))
            addon_id = m.group(1) if m else ''
            if not addon_id or addon_id in seen or addon_id == 'script.glas.helper':
                continue
            seen.add(addon_id)
            art = entry.get('art', {})
            icon = art.get('thumb') or art.get('icon', '')
            apps.append((addon_id, entry.get('label', addon_id),
                         dict({'icon': icon, 'thumb': icon, 'fanart': art.get('fanart', '')}, **app_art(addon_id, icon))))
    apps.sort(key=lambda a: a[1].lower())
    return apps


def dock_slots():
    """Sichtbare Dock-Plaetze: 8 auf 21:9 mit der Einstellung glas_dock8, sonst 6"""
    return DOCK_SLOTS if xbmc.getCondVisibility('Skin.HasSetting(glas_dock8) + String.IsEqual(Skin.AspectRatio,21:9)') else 6


def dock_keys():
    return {xbmc.getInfoLabel('Skin.String(glas_dock_%d_key)' % n) for n in range(1, dock_slots() + 1)} - {''}


def list_apps(handle, store=True, extras=False):
    """extras: Homescreen-Raster; was im Dock liegt, steht dort nicht noch einmal (wie bei Apple)"""
    items = []
    docked = dock_keys() if extras else set()
    for addon_id, label, art in installed_apps():
        if addon_id in docked:
            continue
        item = xbmcgui.ListItem(label, offscreen=True)
        item.setArt(art)
        items.append((BASE + '?' + urlencode({'action': 'run', 'id': addon_id}), item, False))
    if extras:
        keys = ['overview', 'music', 'pictures', 'favourites', 'addons']
        if xbmc.getCondVisibility('PVR.HasTVChannels'):
            keys.insert(1, 'livetv')
        hidden = home_hidden()
        items += [system_item(key) for key in keys if key not in docked and key not in hidden] + [folder_item('tools')]
        if xbmc.getCondVisibility('Skin.HasSetting(glas_home_sources)'):
            items += [source_item(e) for e in __import__('sources').entries() if e[0] not in docked]
    if store:
        # zuletzt "Add-ons" (Add-on-Browser) wie der App Store
        entry = xbmcgui.ListItem(xbmc.getLocalizedString(24001), offscreen=True)
        entry.setArt({'icon': 'DefaultAddonsSearch.png', 'thumb': 'DefaultAddonsSearch.png'})
        items.append((BASE + '?action=store', entry, False))
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def open_key(key):
    if xbmc.getInfoLabel('Window(Home).Property(glas_folder)'):
        # aus einem Ordner gestartet: Ordner schliessen und den Fokus zurueck auf die Ordner-Kachel, sonst bleibt er
        # nach dem Zurueckkehren auf der unsichtbaren Ordnerliste
        xbmc.executebuiltin('ClearProperty(glas_folder,home)')
        xbmc.executebuiltin('SetFocus(5200)')
        xbmc.sleep(100)
    xbmc.executebuiltin('ClearProperty(glas_folder,home)')
    xbmc.executebuiltin(SYSTEM[key][1])


def set_skin_string(name, value):
    if value:
        xbmc.executebuiltin('Skin.SetString(%s,"%s")' % (name, value.replace('"', "'")))
    else:
        xbmc.executebuiltin('Skin.Reset(%s)' % name)


def dock_entry(key):
    """Werte eines Dock-Platzes fuer einen Kodi-Bereich oder ein Add-on (key = Add-on-ID); None = leer"""
    if not key:
        return None
    if key.startswith('source:'):
        return __import__('sources').entry(key)
    if key in SYSTEM:
        ref, builtin, tile, shelf = SYSTEM[key]
        return {'key': key, 'label': label_of(ref), 'action': builtin, 'tile': TILES % tile, 'shelf': shelf,
                'shelfimage': SHELF_IMAGES % tile}
    for addon_id, label, art in installed_apps():
        if addon_id == key:
            # Apps ohne eigene Top Shelf: ihr Fanart als Standbild (wie Apples statisches Top-Shelf-Bild)
            return {'key': key, 'label': label, 'action': 'RunAddon(%s)' % key, 'tile': art.get('tile', ''),
                    'logo': art.get('logo', ''), 'icon': art.get('icon', ''), 'shelfimage': art.get('fanart', '')}
    return None


def set_dock(slot, key):
    entry = dock_entry(key) or {}
    for field in DOCK_FIELDS:
        set_skin_string('glas_dock_%d_%s' % (slot, field), entry.get(field, ''))


def dock_defaults():
    for slot, key in enumerate(DOCK_DEFAULT, 1):
        set_dock(slot, key)
    xbmc.executebuiltin('Skin.SetBool(glas_dock_init)')
    xbmc.executebuiltin('Skin.SetBool(glas_dock_v2)')
    xbmc.executebuiltin('Skin.SetBool(glas_dock_v3)')


def dock_refresh():
    """Belegte Plaetze mit allen Feldern neu schreiben (neue Felder wie das Top-Shelf-Bild), Auswahl bleibt.
    Ein unveraendertes altes Standard-Dock (ohne TV) bekommt die neue Standardbelegung."""
    keys = [xbmc.getInfoLabel('Skin.String(glas_dock_%d_key)' % slot) for slot in range(1, DOCK_SLOTS + 1)]
    if keys[:6] == DOCK_DEFAULT_V2 and not any(keys[6:]):
        keys = DOCK_DEFAULT
    for slot, key in enumerate(keys, 1):
        if key:
            set_dock(slot, key)
    xbmc.executebuiltin('Skin.SetBool(glas_dock_v2)')
    xbmc.executebuiltin('Skin.SetBool(glas_dock_v3)')


DOCK_CHOICES = ('overview', 'movies', 'tvshows', 'search', 'sources', 'addons', 'settings', 'music', 'pictures',
                'favourites', 'filemanager', 'controlcenter', 'livetv')


# Kodi-Bereiche, die man im Raster des Homescreens ausblenden kann (Testerwunsch 06.11.2026: "weder TV, Bilder noch
# Musik"); im Dock bleiben sie waehlbar. Skin.String(glas_home_hidden) = Schluessel mit "-" getrennt, steht auch im Pfad des
# Rasters (Home.xml) und laedt es so neu
HIDEABLE = ('overview', 'livetv', 'music', 'pictures', 'favourites', 'addons')


def home_hidden():
    return {key for key in xbmc.getInfoLabel('Skin.String(glas_home_hidden)').split('-') if key in HIDEABLE}


def home_hidden_label(hidden):
    xbmc.executebuiltin('Skin.SetString(glas_home_hidden_label,%s)' % (
        xbmc.getLocalizedString(593) if not hidden else xbmc.getInfoLabel('$LOCALIZE[32015]') % len(hidden)))


def choose_hidden():
    """Mehrfachauswahl: angehakt = im Hauptmenue sichtbar"""
    hidden = home_hidden()
    labels = [label_of(SYSTEM[key][0]) for key in HIDEABLE]
    shown = [i for i, key in enumerate(HIDEABLE) if key not in hidden]
    picked = xbmcgui.Dialog().multiselect(xbmc.getInfoLabel('$LOCALIZE[32014]'), labels, preselect=shown)
    if picked is None:
        return
    hidden = [key for i, key in enumerate(HIDEABLE) if i not in picked]
    xbmc.executebuiltin('Skin.SetString(glas_home_hidden,%s)' % '-'.join(hidden))
    home_hidden_label(hidden)


def choose_dock(slot):
    """Auswahl: Kodi-Bereiche, danach alle Apps, zuletzt "Keine" (Platz leer)"""
    choices = [(key, label_of(SYSTEM[key][0]), TILES % SYSTEM[key][2]) for key in DOCK_CHOICES]
    choices += [(key, label, tile) for key, label, _, tile in __import__('sources').entries()]
    choices += [(addon_id, label, art.get('tile') or art.get('icon', '')) for addon_id, label, art in installed_apps()]
    choices.append(('', xbmc.getLocalizedString(231), ''))
    items = []
    for _, label, image in choices:
        item = xbmcgui.ListItem(label, offscreen=True)
        item.setArt({'icon': image, 'thumb': image})
        items.append(item)
    keys = [c[0] for c in choices]
    current = xbmc.getInfoLabel('Skin.String(glas_dock_%d_key)' % slot)
    heading = '%s %d' % (xbmc.getInfoLabel('$LOCALIZE[31997]'), slot)
    pick = xbmcgui.Dialog().select(heading, items, useDetails=True,
                                   preselect=keys.index(current) if current in keys else -1)
    if pick >= 0:
        set_dock(slot, keys[pick])


def stereo_sync():
    """Kodis 3D-Staerke als Skin-String spiegeln (Anzeige in den Skin-Einstellungen)"""
    value = rpc('Settings.GetSettingValue', setting='lookandfeel.stereostrength').get('value', 5)
    xbmc.executebuiltin('Skin.SetString(glas_3d_strength,%s)' % (xbmc.getLocalizedString(351) if not value else value))
    return value


def stereo_choose():
    """Staerke 0 (aus) bis 10; Kodi skaliert damit alle Tiefenebenen des Skins"""
    current = stereo_sync()
    labels = [xbmc.getLocalizedString(351)] + [str(n) + (' (%s)' % xbmc.getLocalizedString(571) if n == 5 else '')
                                               for n in range(1, 11)]
    pick = xbmcgui.Dialog().select(xbmc.getInfoLabel('$LOCALIZE[31901]'), labels, preselect=current)
    if pick >= 0:
        rpc('Settings.SetSettingValue', setting='lookandfeel.stereostrength', value=pick)
        stereo_sync()


CARDS = os.path.join(LOGOS, 'tiles')  # Name wechseln, wenn sich die Erzeugung aendert (Kodi haelt Bilder zwischengespeichert)


def make_cards():
    """Fertige Kachel je installiertem Add-on (fuer den Add-on-Browser, Ansicht 52 im Skin):
    logos/tiles/<id>.jpg, neu nur wenn das Symbol neuer ist. Laeuft einmal nach dem Start (service.py)."""
    try:
        from applogo import make_card
    except Exception as e:  # ohne Pillow keine Kacheln, der Skin zeigt dann das Symbol
        xbmc.log('[script.glas.helper] Kacheln aus: %s' % e, xbmc.LOGWARNING)
        return
    os.makedirs(CARDS, exist_ok=True)
    made = 0
    for addon in rpc('Addons.GetAddons', installed=True, properties=['thumbnail']).get('addons', []):
        addon_id = addon.get('addonid', '')
        icon = local_path(addon.get('thumbnail', ''))
        if not addon_id or not icon or not os.path.isfile(icon):
            continue
        card = os.path.join(CARDS, addon_id + '.jpg')
        if os.path.isfile(card) and os.path.getmtime(card) >= os.path.getmtime(icon):
            continue
        try:
            art = app_art(addon_id, icon)
            img = make_card(art.get('tile'), art.get('logo'), icon if not art.get('logo') else None)
            img.save(card, 'JPEG', quality=90)
            made += 1
        except Exception as e:
            xbmc.log('[script.glas.helper] Kachel fuer %s nicht erzeugt: %s' % (addon_id, e), xbmc.LOGWARNING)
    xbmc.log('[script.glas.helper] %d Add-on-Kacheln erzeugt' % made, xbmc.LOGINFO)


def load_profile(name):
    xbmc.executebuiltin('Dialog.Close(all,true)')
    if name and name != rpc('Profiles.GetCurrentProfile').get('label', ''):
        xbmc.executebuiltin('LoadProfile("%s",prompt)' % name.replace('"', ''))


def first_setup():
    """Nur Kodis Standard ersetzen; eine eigene Wahl des Nutzers bleibt."""
    mode = rpc('Settings.GetSettingValue', setting='screensaver.mode').get('value', '')
    if xbmc.getCondVisibility('System.HasAddon(screensaver.atv4)') and mode in ('', 'screensaver.xbmc.builtin.dim',
                                                                                  'screensaver.xbmc.builtin.black'):
        rpc('Settings.SetSettingValue', setting='screensaver.mode', value='screensaver.atv4')


KEYMAP_HEAD = '''<?xml version="1.0" encoding="UTF-8"?>
<!-- angelegt von script.glas.helper (Skin Glas, Belegung 4): Home-Taste lange druecken oeffnet ueberall das
     Kontrollzentrum, wie die TV-Taste beim Apple TV. Bei einfachem Druck bleibt alles wie bisher, nur im Homescreen
     wirkt sie wie Zurueck: Kodi gibt "PreviousMenu" dort an kein Bedienelement weiter, Ordner und Raster blieben sonst
     offen. Kodi nimmt in einem Fensterbereich, der die Taste nur kurz belegt, auch beim langen Druck diese kurze
     Belegung; deshalb steht der lange Druck in jedem Bereich, den eine Systemtastenbelegung (z. B. OSMCs
     osmc_remote.xml) fuer escape oder home vorsieht. browser_search: OSMC-Taste anderer Fernbedienungen bzw. Harmony.
     Mausrad im Homescreen wie Hoch/Runter: das Dock ist eine waagerechte Liste und schluckte das Rad, nach unten ins
     App-Raster und zurueck zu Dock und Top Shelf ging es mit dem Rad sonst nicht.
     Loeschen stellt OSMCs Belegung her. -->
<keymap>
'''
KEYMAP_CC = 'ActivateWindow(1120)'


def home_key_sections():
    """Fensterbereiche aller Systemtastenbelegungen, die die Home-Taste (escape, home) selbst belegen."""
    import xml.etree.ElementTree as ET
    sections = {}  # Kleinschreibung -> erster Name (Kodi unterscheidet die Schreibweise nicht)
    root = xbmcvfs.translatePath('special://xbmc/system/keymaps')
    for folder, _dirs, files in os.walk(root):
        for name in files:
            if not name.endswith('.xml'):
                continue
            try:
                tree = ET.parse(os.path.join(folder, name)).getroot()
            except Exception:
                continue
            for section in tree:
                keyboard = section.find('keyboard')
                if keyboard is not None and any(key.tag in ('escape', 'home') for key in keyboard):
                    sections.setdefault(section.tag.lower(), section.tag)
    sections.pop('global', None)
    sections.pop('home', None)
    return sorted(sections.values(), key=str.lower)


def build_keymap():
    """Keymap: global und in jedem Bereich mit eigener Home-Belegung lang = Kontrollzentrum."""
    long_press = ('      <escape mod="longpress">%s</escape>\n'
                  '      <home mod="longpress">%s</home>\n') % (KEYMAP_CC, KEYMAP_CC)
    parts = [KEYMAP_HEAD,
             '  <global>\n    <keyboard>\n' + long_press +
             '      <browser_search>%s</browser_search>\n    </keyboard>\n  </global>\n' % KEYMAP_CC,
             '  <Home>\n    <mouse>\n      <wheelup>Up</wheelup>\n      <wheeldown>Down</wheeldown>\n    </mouse>\n'
             '    <keyboard>\n      <escape>Back</escape>\n' + long_press + '    </keyboard>\n  </Home>\n']
    for section in home_key_sections():
        parts.append('  <%s>\n    <keyboard>\n%s    </keyboard>\n  </%s>\n' % (section, long_press, section))
    parts.append('</keymap>\n')
    return ''.join(parts)


KEYMAP_MARK = 'angelegt von script.glas.helper'


def setup_v2():
    """Bedienung wie Apple: Taste fuer das Kontrollzentrum, keine ".."-Eintraege in Listen (Apple kennt keine) und
    Apple-TV-Klaenge, solange noch Kodis Standardklaenge gewaehlt sind (eine eigene Wahl bleibt)."""
    sounds = rpc('Settings.GetSettingValue', setting='lookandfeel.soundskin').get('value', '')
    if xbmc.getCondVisibility('System.HasAddon(resource.uisounds.appletv)') and sounds in ('', 'resource.uisounds.kodi'):
        rpc('Settings.SetSettingValue', setting='lookandfeel.soundskin', value='resource.uisounds.appletv')
    path = xbmcvfs.translatePath('special://profile/keymaps/glas.xml')
    old = ''
    if xbmcvfs.exists(path):
        with xbmcvfs.File(path) as f:
            old = f.read()
    # eigene Datei aktualisieren, fremde (ohne Kennung) nie ueberschreiben
    keymap = build_keymap()
    if old != keymap and (not old or KEYMAP_MARK in old):
        xbmcvfs.mkdirs(os.path.dirname(path))
        with xbmcvfs.File(path, 'w') as f:
            f.write(keymap)
        xbmc.executebuiltin('Action(reloadkeymaps)')
    rpc('Settings.SetSettingValue', setting='filelists.showparentdiritems', value=False)


# Skin.String(glas_screen): Seitenverhaeltnis der Leinwand wie die OSMC Skin (Scope edition), leer = wie das Bild
# (1.78), custom = eigene Raender aus der Kalibrierung (screencal.py)
SCREENS = ('', '2.40', '2.35', '2.33', '2.00', 'custom')
SCREEN_LABELS = (31575, 31577, 31578, 31580, 31579, 31581)


def choose_screen():
    """Skin-Einstellung Leinwand (Scope-Modus, docs/plan-scope.md). Die Fassungen fuer den Streifen waehlt Kodi beim
    Laden der Fenster, deshalb nach einem Wechsel den Skin neu laden. "Eigene" oeffnet die Kalibrierung (auch erneut)."""
    current = xbmc.getInfoLabel('Skin.String(glas_screen)')
    labels = [xbmc.getInfoLabel('$LOCALIZE[%d]' % s) for s in SCREEN_LABELS]
    pick = xbmcgui.Dialog().select(xbmc.getInfoLabel('$LOCALIZE[31574]'), labels,
                                   preselect=SCREENS.index(current) if current in SCREENS else 0)
    if pick >= 0 and SCREENS[pick] == 'custom':
        __import__('screencal').run()
        return
    if pick < 0 or SCREENS[pick] == current:
        return
    if SCREENS[pick]:
        xbmc.executebuiltin('Skin.SetString(glas_screen,%s)' % SCREENS[pick])
    else:
        xbmc.executebuiltin('Skin.Reset(glas_screen)')
    xbmc.sleep(300)  # Auswahldialog ganz schliessen lassen: ReloadSkin ueber einem Dialog kann Kodi abstuerzen lassen
    xbmc.executebuiltin('ReloadSkin()')


def setup_v3():
    """Add-on-Updates nur melden statt selbst installieren (0 = installieren, 1 = melden, 2 = nie suchen): Glas-Updates
    bestaetigt man dann unter Add-ons > Updates. Nur fragen, solange Kodi noch selbst installiert."""
    if rpc('Settings.GetSettingValue', setting='general.addonupdates').get('value', 0) != 0:
        return
    if xbmcgui.Dialog().yesno(xbmc.getInfoLabel('$LOCALIZE[31572]'), xbmc.getInfoLabel('$LOCALIZE[31569]')):
        rpc('Settings.SetSettingValue', setting='general.addonupdates', value=1)


def main():
    handle = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit() else -1
    query = dict(parse_qsl(sys.argv[2][1:] if len(sys.argv) > 2 else ''))
    if query.get('info') == 'profiles':
        list_profiles(handle)
        return
    if query.get('info') == 'apps':
        list_apps(handle, store=query.get('store') != '0', extras=query.get('extras') == '1')
        return
    if query.get('info') == 'folder':
        list_folder(handle, query.get('name', ''))
        return
    if query.get('info') in ('nextup', 'random'):  # Weiter ansehen, Zufallsreihe (nextup.py)
        __import__('nextup').list_info(handle, query)
        return
    if query.get('info') == 'watchlist':  # Merkliste (watchlist.py)
        __import__('watchlist').list_watchlist(handle, int(query.get('limit', '30') or 30))
        return
    if query.get('info') == 'ccmenu':  # Untermenues des Kontrollzentrums: Sleep-Timer, Audio (power.py)
        __import__('power').list_menu(handle, query.get('menu', ''))
        return
    if handle >= 0:
        # Aufruf als Listeneintrag: Kodi erwartet eine Antwort, sonst bleibt die Ladeanzeige stehen
        xbmcplugin.endOfDirectory(handle, succeeded=False, updateListing=False, cacheToDisc=False)
    action = query.get('action')
    if action == 'load':
        load_profile(query.get('name', ''))
    elif action == 'add':
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ActivateWindow(profiles)')
    elif action == 'store':
        xbmc.executebuiltin('ActivateWindow(addonbrowser,addons://user/,return)')
    elif action == 'open' and query.get('key') in SYSTEM:
        open_key(query['key'])
    elif action == 'open' and query.get('key', '').startswith('source:'):  # Videoquelle als Kachel (sources.py)
        xbmc.executebuiltin('ClearProperty(glas_folder,home)')
        __import__('sources').open_key(query['key'])
    elif action == 'dock' and query.get('slot', '').isdigit() and 1 <= int(query['slot']) <= DOCK_SLOTS:
        choose_dock(int(query['slot']))
    elif action == 'homehidden':  # Kodi-Bereiche im Raster des Homescreens aus-/einblenden
        choose_hidden()
    elif action == 'dockdefaults':
        dock_defaults()
    elif action == 'dockrefresh':
        dock_refresh()
    elif action == 'cards':
        make_cards()
    elif action == 'stereo':
        stereo_choose()
    elif action == 'stereosync':
        stereo_sync()
    elif action == 'folder' and query.get('name') in FOLDERS:
        xbmc.executebuiltin('SetProperty(glas_folder,%s,home)' % query['name'])
        xbmc.sleep(150)  # Ordnerflaeche erst sichtbar werden lassen, sonst nimmt Kodi den Fokus nicht an
        xbmc.executebuiltin('SetFocus(5300)')
    elif action == 'run':
        xbmc.executebuiltin('RunAddon(%s)' % query.get('id', ''))
    elif action == 'setup':
        first_setup()
    elif action == 'setup2':
        setup_v2()
    elif action == 'setup3':
        setup_v3()
    elif action == 'screen':  # Leinwand 21:9 bei 16:9-Ausgabe (Scope-Modus)
        choose_screen()
    elif action == 'core':  # Live-Glas-Kern (eigener Kodi-Build, Vero V und Windows x64)
        __import__('core').run()
    elif action in ('play', 'nextep'):  # Abspielen ohne Rueckfrage, naechste Folge einer Serie (nextup.py)
        __import__('nextup').run(action, query)
    elif action in ('tracks', 'settrack'):  # Spurmenue im Player (tracks.py)
        __import__('tracks').run(action, query)
    elif action in ('power', 'sleep', 'audio'):  # Rueckfrage Energie, Sleep-Timer, Audio (power.py, audio.py)
        __import__('power').run(action, query)
    elif action == 'gui3d':  # Oberflaeche in 3D bzw. zurueck in 2D (Kontrollzentrum, display3d.py)
        __import__('display3d').toggle()
    elif action == 'font':
        rpc('Settings.SetSettingValue', setting='lookandfeel.font', value=query.get('set', 'Default'))
    elif action == 'colors':  # aeltere Fassung (Farbschema direkt); Glas 0.8 nutzt action=theme
        rpc('Settings.SetSettingValue', setting='lookandfeel.skincolors', value=query.get('set', 'SKINDEFAULT'))
    elif action == 'theme':  # Darstellung Dunkel/Hell/Automatisch, Kontrast, Transparenz (appearance.py)
        __import__('appearance').run(query)
    elif action == 'watchlist':  # Merkliste: Schlagwort setzen/entfernen (watchlist.py)
        __import__('watchlist').toggle(query.get('type', ''), query.get('id', ''))
    elif action == 'info':  # Detailseite eines Titels (Kreis "i" im Titelbild der TV-Seite, watchlist.py)
        __import__('watchlist').show_info(query.get('type', ''), query.get('id', ''))
    elif action == 'marks':  # Abzeichen "Neu" sofort abgleichen (marks.py)
        __import__('marks').sync()
    elif action == 'cine':  # Logo-Poster sofort rechnen (cine.py)
        __import__('cine').sync()


if __name__ == '__main__':
    main()
