"""Glas Helper: Kodis Videoquellen als eigene Kacheln im Hauptmenue (Testerbericht 05.11.2026: "Richtige Filme",
"Schnulli-Pups" und "Kinderfilme" als eigene Eintraege).

Je Quelle (Files.GetSources) eine Kachel mit dem Namen der Quelle auf einem Farbverlauf (wie die App-Kacheln,
tools/dev/apptiles_render.mjs), Schluessel source:<id> (id aus dem Pfad, bleibt gleich). Die Kachel oeffnet die Quelle
in der Mediathek: eine intelligente Wiedergabeliste (special://profile/playlists/video/glas-quelle-<id>.xsp, Regel
"Pfad beginnt mit") vom Typ Filme bzw. Serien, je nachdem, was die Bibliothek in der Quelle kennt - mit Postern,
"Neu" und Merkliste. Kennt die Bibliothek darin nichts, oeffnet sie die Quelle als Ordner.

Im Raster des Homescreens mit der Skin-Einstellung "Quellen im Hauptmenue" (glas_home_sources), im Dock waehlbar.
"""
import hashlib
import json
import os
from xml.sax.saxutils import escape

import xbmc
import xbmcvfs

PREFIX = 'source:'
PLAYLISTS = 'special://profile/playlists/video/'
TILES = 'special://profile/addon_data/script.glas.helper/sourcetiles/'
FONT = 'special://home/addons/skin.glas/fonts/Inter-Bold.ttf'
SIZE = (500, 300)
# Verlaeufe wie die App-Kacheln (oben hell, unten dunkler), der Reihe nach je Quelle
COLORS = [('#5AC8FA', '#0A7AFF'), ('#FF7A45', '#E2361F'), ('#4CD964', '#1FA64A'), ('#7B7BFF', '#3B2FD9'),
          ('#FFB340', '#FF7A00'), ('#FF6278', '#EE2448'), ('#64D2FF', '#1E8BF0'), ('#A7A7AC', '#68686D')]
ALGO = 'quelle-1'


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def source_id(path):
    return hashlib.sha1(path.encode('utf-8')).hexdigest()[:10]


def video_sources():
    """[(id, Name, Pfad)] in Kodis Reihenfolge"""
    out = []
    for s in rpc('Files.GetSources', media='video').get('sources', []):
        path = s.get('file', '')
        if path and not path.startswith(('addons://', 'plugin://')):
            out.append((source_id(path), s.get('label', path), path))
    return out


def kind_of(path):
    """movies, tvshows oder '' (die Bibliothek kennt in der Quelle nichts)"""
    rule = {'field': 'path', 'operator': 'startswith', 'value': path}
    counts = {}
    for kind, method in (('movies', 'VideoLibrary.GetMovies'), ('tvshows', 'VideoLibrary.GetTVShows')):
        counts[kind] = rpc(method, filter=rule, limits={'start': 0, 'end': 1}).get('limits', {}).get('total', 0)
    best = max(counts, key=counts.get)
    return best if counts[best] else ''


def playlist(sid, label, path, kind):
    """Wiedergabeliste schreiben (nur bei Aenderung), Pfad fuer ActivateWindow"""
    xsp = PLAYLISTS + 'glas-quelle-%s.xsp' % sid
    text = ('<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
            '<smartplaylist type="%s">\n'
            '    <name>%s</name>\n'
            '    <match>all</match>\n'
            '    <rule field="path" operator="startswith">\n'
            '        <value>%s</value>\n'
            '    </rule>\n'
            '    <order direction="ascending">sorttitle</order>\n'
            '</smartplaylist>\n') % (kind, escape(label), escape(path))
    real = xbmcvfs.translatePath(xsp)
    try:
        with open(real, encoding='utf-8') as f:
            if f.read() == text:
                return xsp
    except OSError:
        pass
    os.makedirs(os.path.dirname(real), exist_ok=True)
    with open(real, 'w', encoding='utf-8') as f:
        f.write(text)
    return xsp


def tile(sid, label, index):
    """Kachel 500 x 300: Verlauf, Name in Inter Bold (bis zwei Zeilen); ohne Pillow die Kachel "Quellen" """
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        return 'special://skin/media/glas/apps/sources.png'
    name = 'special://profile/addon_data/script.glas.helper/sourcetiles/%s-%s.png' % (
        sid, hashlib.sha1(('%s|%s|%d' % (ALGO, label, index)).encode('utf-8')).hexdigest()[:8])
    real = xbmcvfs.translatePath(name)
    if os.path.exists(real):
        return name
    os.makedirs(os.path.dirname(real), exist_ok=True)
    top, bottom = COLORS[index % len(COLORS)]
    t = [int(top[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(bottom[i:i + 2], 16) for i in (1, 3, 5)]
    w, h = SIZE
    img = Image.new('RGB', SIZE)
    draw = ImageDraw.Draw(img)
    for y in range(h):
        f = y / (h - 1)
        draw.line([(0, y), (w, y)], fill=tuple(int(t[i] + (b[i] - t[i]) * f) for i in range(3)))
    font_path = xbmcvfs.translatePath(FONT)

    def width(text, font):
        if hasattr(draw, 'textlength'):
            return draw.textlength(text, font=font)
        return font.getsize(text)[0]

    # groesste Schrift, bei der der Name in eine Zeile (bzw. zwei, an Leerzeichen getrennt) passt
    lines, font = [label], None
    for size in range(64, 27, -4):
        font = ImageFont.truetype(font_path, size)
        if width(label, font) <= w - 70:
            lines = [label]
            break
        words = label.split()
        if len(words) > 1:
            best = None
            for cut in range(1, len(words)):
                a, c = ' '.join(words[:cut]), ' '.join(words[cut:])
                widest = max(width(a, font), width(c, font))
                if widest <= w - 70 and (best is None or widest < best[0]):
                    best = (widest, [a, c])
            if best:
                lines = best[1]
                break
    ascent, descent = font.getmetrics()
    line_h = ascent + descent
    y = (h - line_h * len(lines)) / 2
    for line in lines:
        draw.text(((w - width(line, font)) / 2, y), line, font=font, fill=(255, 255, 255))
        y += line_h
    img.save(real)
    return name


def entries():
    """[(Schluessel, Name, Aktion, Kachel)] fuer alle Videoquellen"""
    out = []
    for index, (sid, label, path) in enumerate(video_sources()):
        kind = kind_of(path)
        if kind:
            target = playlist(sid, label, path, kind)
        else:
            target = path
        # ohne Anfuehrungszeichen: das Dock legt die Aktion als Skin-String ab und macht aus " ein '
        action = 'ActivateWindow(Videos,%s,return)' % target
        out.append((PREFIX + sid, label, action, tile(sid, label, index)))
    return out


def entry(key):
    for k, label, action, tile_path in entries():
        if k == key:
            return {'key': k, 'label': label, 'action': action, 'tile': tile_path}
    return None


def open_key(key):
    e = entry(key)
    if e:
        xbmc.executebuiltin(e['action'])
