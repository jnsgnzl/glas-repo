"""Glas Helper: Listen und Aktionen fuer "Weiter ansehen" (Up Next), die naechste Folge einer Serie und die Zufallsreihe.

plugin://script.glas.helper/?info=nextup[&type=all|movies|episodes][&limit=20]
    Angefangene Filme und je laufender Serie die naechste Folge (angefangen oder ungesehen), sortiert nach "zuletzt
    gesehen". Gerechnet wird einmal fuer alle Reihen (shared_entries): Der Homescreen laedt drei Reihen gleichzeitig
    (all, movies, episodes), dazu die TV-Seite; je Reihe waren es bis zu 42 JSON-RPC-Aufrufe. Das Ergebnis liegt als
    JSON in Window(Home).Property(glas.nextup.cache) und gilt, solange sich die Bibliothek nicht geaendert hat
    (glas.nextup.gen, gesetzt vom Dienst bei jeder Meldung der Videobibliothek und bei Wiedergabe-Ende, wake.py), hoechstens
    MAX_AGE Sekunden. Eintraege mit vollem Artwork, Fortschritt (Resume), DBID/DBType; Property "glas.sub" = Unterzeile
    ("S2, F4 · Noch 20 Min."). Der Pfad spielt fortsetzend ab
    (?action=play...). Im Skin per <onclick> am Container abspielen, damit Kodi nicht nach dem Fortsetzen fragt.
    &source=source:<id>: nur Titel aus dieser Videoquelle (Dock-Platz mit einer Quelle, sources.py).
plugin://script.glas.helper/?info=new&type=movies|episodes&source=source:<id>
    Neu hinzugefuegte, ungesehene Titel einer Videoquelle (Top Shelf ohne "Weiter ansehen").
plugin://script.glas.helper/?info=random&start=0&count=20
    Ungesehene Filme in zufaelliger, aber je Kodi-Sitzung fester Reihenfolge (Window(Home).Property(glas.seed)).
    start/count schneiden einen Teil heraus (Titelbild 0-7, Reihe ab 8), damit nichts doppelt erscheint.
plugin://script.glas.helper/?action=play&type=movie|episode&id=N[&resume=0]
    Abspielen ueber Player.Open; fortsetzend ohne Rueckfrage (resume=0: von Anfang an).
plugin://script.glas.helper/?action=nextep&tvshowid=N
    Naechste Folge einer Serie in Window(Home)-Properties (ein JSON-RPC-Aufruf):
    glas.nextep.state (start|continue|rewatch, leer = keine Folgen), .label ("S2, F4"), .title, .season, .episode,
    .file, .episodeid, .percent (0-100), .remaining (Minuten), zuletzt .tvshowid (gilt, wenn = aktuelle Serie).
"""
import hashlib
import json
import random
import time
from urllib.parse import urlencode

import xbmc
import xbmcgui
import xbmcplugin

BASE = 'plugin://script.glas.helper/'
HOME = xbmcgui.Window(10000)
MOVIE_PROPS = ['title', 'year', 'genre', 'plot', 'runtime', 'resume', 'lastplayed', 'playcount', 'art', 'file',
               'rating', 'mpaa', 'tagline', 'premiered']
EPISODE_PROPS = ['title', 'season', 'episode', 'showtitle', 'tvshowid', 'plot', 'runtime', 'resume', 'lastplayed',
                 'playcount', 'art', 'file', 'firstaired', 'rating']
# fuer die Wahl der naechsten Folge reicht wenig (eine Serie kann Hunderte Folgen haben)
CHOOSE_PROPS = ['title', 'season', 'episode', 'playcount', 'resume', 'lastplayed', 'file', 'runtime']
CACHE = 'glas.nextup.cache'     # {"gen", "limit", "time", "entries"}
BUSY = 'glas.nextup.busy'       # "gen|Zeit": eine Reihe rechnet gerade, die anderen warten auf ihr Ergebnis
GEN = 'glas.nextup.gen'         # Stand der Bibliothek (wake.nextup_gen)
MAX_AGE = 60                    # Sekunden; auch ohne Meldung danach neu rechnen
WAIT = 4.0                      # so lange auf eine rechnende Reihe warten


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def localize(string_id):
    return xbmc.getInfoLabel('$LOCALIZE[%d]' % string_id)


def remaining_minutes(resume, runtime):
    total = (resume or {}).get('total') or runtime or 0
    position = (resume or {}).get('position') or 0
    return max(0, int(round((total - position) / 60.0))) if total else 0


def percent_played(resume):
    total = (resume or {}).get('total') or 0
    return int(100 * resume.get('position', 0) / total) if total else 0


def episode_label(season, episode):
    """"S2, F4" (Deutsch) bzw. "S2, E4" """
    return localize(31203).format(season, episode)


def choose_episode(episodes):
    """Naechste Folge wie in der TV-App des Vorbilds -> (Zustand, Folge).
    continue: angefangene Folge bzw. die nach der zuletzt gesehenen; start: noch nichts gesehen (erste Folge);
    rewatch: alles gesehen (erste Folge). Specials (Staffel 0) nur, wenn es nichts anderes gibt."""
    regular = [e for e in episodes if e.get('season', 0) > 0] or list(episodes)
    if not regular:
        return '', None
    regular.sort(key=lambda e: (e.get('season', 0), e.get('episode', 0)))
    played = [e for e in regular if e.get('lastplayed')]
    if played:
        anchor = max(played, key=lambda e: e['lastplayed'])
        # angefangen bzw. nur kurz angespielt: dieselbe Folge. Eine gesehene Folge zaehlt als fertig, auch wenn Kodi noch
        # eine Fortsetzungsstelle kennt (beim Beenden zwischen 90 und 92 % zaehlt Kodi die Folge und merkt sich trotzdem
        # die Stelle; Testerbericht 22.11.2026: gesehene Titel in "Weiter ansehen")
        if not anchor.get('playcount'):
            return 'continue', anchor
        # danach die erste ungesehene Folge (eine schon als gesehen markierte wird uebersprungen; Testerbericht
        # 05.11.2026: gesehene Folgen standen in "Weiter ansehen")
        index = regular.index(anchor)
        later = [e for e in regular[index + 1:] if not e.get('playcount')]
        if later:
            return 'continue', later[0]
    unwatched = [e for e in regular if not e.get('playcount')]
    if not unwatched:
        return 'rewatch', regular[0]
    if len(unwatched) == len(regular):
        return 'start', regular[0]
    # ohne Wiedergabedatum als gesehen markiert: erste ungesehene nach der letzten gesehenen
    last_seen = max(i for i, e in enumerate(regular) if e.get('playcount'))
    later = [e for e in regular[last_seen + 1:] if not e.get('playcount')]
    return 'continue', (later or unwatched)[0]


def show_episodes(tvshowid, properties=CHOOSE_PROPS):
    return rpc('VideoLibrary.GetEpisodes', tvshowid=int(tvshowid), properties=properties).get('episodes', [])


def play_url(kind, dbid):
    return BASE + '?' + urlencode({'action': 'play', 'type': kind, 'id': dbid})


def video_item(kind, data, sub=''):
    """Plugin-Eintrag mit den Daten aus der Videobibliothek (DBID, Art, Fortschritt)"""
    art = dict(data.get('art') or {})
    if kind == 'episode':
        label = data.get('showtitle') or data.get('title', '')
        for key in ('fanart', 'poster', 'clearlogo', 'landscape', 'banner'):
            if not art.get(key) and art.get('tvshow.' + key):
                art[key] = art['tvshow.' + key]
    else:
        label = data.get('title') or data.get('label', '')
    item = xbmcgui.ListItem(label, offscreen=True)
    item.setArt(art)
    tag = item.getVideoInfoTag()
    tag.setMediaType(kind)
    tag.setDbId(int(data.get(kind + 'id', 0)))
    tag.setTitle(data.get('title', ''))
    tag.setPlot(data.get('plot', ''))
    tag.setDuration(int(data.get('runtime') or 0))
    tag.setPlaycount(int(data.get('playcount') or 0))
    if data.get('lastplayed'):
        tag.setLastPlayed(data['lastplayed'])
    if data.get('file'):
        tag.setFilenameAndPath(data['file'])
    if data.get('rating'):
        tag.setRating(float(data['rating']))
    resume = data.get('resume') or {}
    if resume.get('position'):
        tag.setResumePoint(float(resume['position']), float(resume.get('total') or 0))
    if kind == 'episode':
        tag.setTvShowTitle(data.get('showtitle', ''))
        tag.setSeason(int(data.get('season', 0)))
        tag.setEpisode(int(data.get('episode', 0)))
        tag.setFirstAired(data.get('firstaired', ''))
    else:
        if data.get('year'):
            tag.setYear(int(data['year']))
        tag.setGenres(data.get('genre') or [])
        tag.setMpaa(data.get('mpaa', ''))
        tag.setTagLine(data.get('tagline', ''))
        tag.setPremiered(data.get('premiered', ''))
    if data.get('tag'):
        tag.setTags(data['tag'])
    item.setProperty('glas.sub', sub)
    return play_url(kind, data.get(kind + 'id', 0)), item, False


def left_label(data):
    minutes = remaining_minutes(data.get('resume'), data.get('runtime'))
    return localize(31205).format(minutes) if minutes else ''


def cached_entries(gen, limit):
    try:
        cache = json.loads(HOME.getProperty(CACHE) or '{}')
    except ValueError:
        return None
    if cache.get('gen') == gen and cache.get('limit', 0) >= limit and 0 <= time.time() - cache.get('time', 0) < MAX_AGE:
        return cache.get('entries')
    return None


def shared_entries(limit=20):
    """Filme und Folgen fuer alle Reihen "Weiter ansehen", je Stand der Bibliothek einmal gerechnet."""
    gen = HOME.getProperty(GEN)
    entries = cached_entries(gen, limit)
    if entries is not None:
        return entries
    busy = HOME.getProperty(BUSY).split('|')
    try:
        waiting = busy[0] == gen and time.time() - float(busy[1]) < WAIT
    except (IndexError, ValueError):
        waiting = False
    if waiting:  # eine andere Reihe rechnet gerade dasselbe
        monitor = xbmc.Monitor()
        end = time.time() + WAIT
        while time.time() < end and not monitor.waitForAbort(0.05):
            entries = cached_entries(gen, limit)
            if entries is not None:
                return entries
            if not HOME.getProperty(BUSY):
                break
    HOME.setProperty(BUSY, '%s|%f' % (gen, time.time()))
    try:
        entries = nextup_entries('all', limit, cut=False)
        HOME.setProperty(CACHE, json.dumps({'gen': gen, 'limit': limit, 'time': time.time(), 'entries': entries}))
    finally:
        HOME.clearProperty(BUSY)
    return entries


def nextup_entries(kind='all', limit=20, cut=True):
    """[(zuletzt gesehen, Art, Daten)] fuer "Weiter ansehen"; cut=False: Filme und Folgen je bis limit (fuer alle Reihen)"""
    entries = []
    if kind in ('all', 'movies'):
        # angefangen und noch nicht gesehen: Kodi zaehlt einen Film ab 90 % als gesehen, merkt sich bis 92 % aber die
        # Stelle (advancedsettings playcountminimumpercent / ignorepercentatend) - solche Filme standen in "Weiter
        # ansehen" (Testerbericht 22.11.2026)
        movies = rpc('VideoLibrary.GetMovies', properties=MOVIE_PROPS, limits={'end': limit},
                     sort={'method': 'lastplayed', 'order': 'descending'},
                     filter={'and': [{'field': 'inprogress', 'operator': 'true', 'value': ''},
                                     {'field': 'playcount', 'operator': 'lessthan', 'value': '1'}]}).get('movies', [])
        entries += [(m.get('lastplayed', ''), 'movie', m) for m in movies]
    if kind in ('all', 'episodes'):
        shows = rpc('VideoLibrary.GetTVShows', properties=['lastplayed'], limits={'end': limit},
                    sort={'method': 'lastplayed', 'order': 'descending'}).get('tvshows', [])
        for show in shows:
            if not show.get('lastplayed'):
                continue
            state, episode = choose_episode(show_episodes(show['tvshowid']))
            if state != 'continue':
                continue    # noch nicht begonnen oder fertig gesehen
            details = rpc('VideoLibrary.GetEpisodeDetails', episodeid=episode['episodeid'],
                          properties=EPISODE_PROPS).get('episodedetails')
            if details:
                entries.append((episode.get('lastplayed') or show['lastplayed'], 'episode', details))
    entries.sort(key=lambda e: e[0], reverse=True)
    return entries[:limit] if cut else entries


def source_paths(source):
    """Pfade der Videoquelle (Dock-Schluessel source:<id>), [] = nicht filtern"""
    if not source.startswith('source:'):
        return []
    import sources
    return sources.paths_of(source) or ['\0']  # unbekannte Quelle: nichts zeigen statt alles


def list_nextup(handle, kind='all', limit=20, source=''):
    """source: nur Titel aus dieser Videoquelle (Dock-Platz mit einer Quelle; Testerbericht 22.11.2026: "Movies" und
    "Zeichentrick" zeigten dieselbe Reihe)"""
    want = {'all': ('movie', 'episode'), 'movies': ('movie',), 'episodes': ('episode',)}.get(kind, ('movie', 'episode'))
    entries = [e for e in shared_entries(limit) if e[1] in want]
    paths = source_paths(source)
    if paths:
        import sources
        entries = [e for e in entries if sources.in_paths(e[2].get('file', ''), paths)]
    entries = entries[:limit]
    items = []
    for _, media, data in entries:
        if media == 'episode':
            head = episode_label(data.get('season', 0), data.get('episode', 0))
            tail = left_label(data) if (data.get('resume') or {}).get('position') else data.get('title', '')
            sub = '  ·  '.join(x for x in (head, tail) if x)
        else:
            sub = left_label(data)
        items.append(video_item(media, data, sub))
    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def list_new(handle, kind='movies', source='', limit=15):
    """Neu hinzugefuegte, ungesehene Filme bzw. Folgen einer Videoquelle (Top Shelf ohne "Weiter ansehen"; ohne Quelle
    nimmt der Skin die Wiedergabelisten recent_unwatched_*.xsp, gleiche Regeln)"""
    paths = source_paths(source)
    rules = [{'field': 'playcount', 'operator': 'lessthan', 'value': '1'}]
    if paths:
        import sources
        rules.append(sources.path_filter(paths))
    if kind == 'episodes':
        # je Serie ein Eintrag wie "Weiter ansehen" (Testerbericht 23.11.2026: neu hinzugefuegte Staffeln fuellten die
        # Reihe mit fuenf Folgen derselben Serie): Serien nach ihrer neuesten Folge geordnet, gezeigt wird jeweils die
        # erste ungesehene der neuen Folgen (die naechste zum Anschauen)
        many = rpc('VideoLibrary.GetEpisodes', properties=EPISODE_PROPS, limits={'end': max(limit * 8, 100)},
                   sort={'method': 'dateadded', 'order': 'descending'}, filter={'and': rules}).get('episodes', [])
        shows, order = {}, []
        for e in many:
            show = e.get('tvshowid', -1)
            if show not in shows:
                shows[show] = e
                order.append(show)
            elif (e.get('season', 0), e.get('episode', 0)) < (shows[show].get('season', 0), shows[show].get('episode', 0)):
                shows[show] = e
        found = [shows[s] for s in order[:limit]]
        items = [video_item('episode', e, episode_label(e.get('season', 0), e.get('episode', 0))) for e in found]
        content = 'episodes'
    else:
        found = rpc('VideoLibrary.GetMovies', properties=MOVIE_PROPS, limits={'end': limit},
                    sort={'method': 'dateadded', 'order': 'descending'}, filter={'and': rules}).get('movies', [])
        items = [video_item('movie', m) for m in found]
        content = 'movies'
    # Pfad = die Datei selbst: Die Reihe hat kein <onclick>, Kodi fuehrt wie bei der Wiedergabeliste die eingestellte
    # Standardaktion aus (Abspielen bzw. Informationen) - der Abspiel-Pfad des Helpers ist kein aufloesbarer Eintrag
    items = [(data.get('file') or url, item, folder) for (url, item, folder), data in zip(items, found)]
    xbmcplugin.setContent(handle, content)
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def session_seed():
    seed = HOME.getProperty('glas.seed')
    if not seed:
        seed = str(random.getrandbits(32))
        HOME.setProperty('glas.seed', seed)
    return seed


def list_random(handle, start=0, count=20):
    """Ungesehene Filme, je Sitzung gleich gemischt: Rang = Hash aus Sitzung und Film-ID (ein gesehener Film faellt
    heraus, ohne die uebrigen umzustellen)"""
    seed = session_seed()
    movies = rpc('VideoLibrary.GetMovies', filter={'field': 'playcount', 'operator': 'lessthan', 'value': '1'}
                 ).get('movies', [])
    ids = sorted((m['movieid'] for m in movies),
                 key=lambda i: hashlib.md5(('%s:%d' % (seed, i)).encode()).hexdigest())
    from watchlist import mark  # watchlist importiert nextup
    items = []
    for movieid in ids[start:start + count]:
        data = rpc('VideoLibrary.GetMovieDetails', movieid=movieid, properties=MOVIE_PROPS + ['tag']
                   ).get('moviedetails')
        if data:
            items.append(video_item('movie', data))
            mark(items[-1][1], 'movie', data)
    xbmcplugin.setContent(handle, 'movies')
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def play(kind, dbid, resume=True):
    key = {'movie': 'movieid', 'episode': 'episodeid'}.get(kind)
    if key and str(dbid).isdigit() and int(dbid) > 0:
        rpc('Player.Open', item={key: int(dbid)}, options={'resume': bool(resume)})


NEXTEP_FIELDS = ('state', 'label', 'title', 'season', 'episode', 'file', 'episodeid', 'percent', 'remaining')


def next_episode(tvshowid):
    """Naechste Folge einer Serie fuer die Detailseite (Window(Home)-Properties glas.nextep.*)"""
    if not str(tvshowid).isdigit():
        return
    state, episode = choose_episode(show_episodes(tvshowid))
    values = dict.fromkeys(NEXTEP_FIELDS, '')
    if episode:
        resume = episode.get('resume') or {}
        values.update(state=state, label=episode_label(episode.get('season', 0), episode.get('episode', 0)),
                      title=episode.get('title', ''), season=str(episode.get('season', '')),
                      episode=str(episode.get('episode', '')), file=episode.get('file', ''),
                      episodeid=str(episode.get('episodeid', '')), percent=str(percent_played(resume)),
                      remaining=str(remaining_minutes(resume, episode.get('runtime'))))
    for field in NEXTEP_FIELDS:
        HOME.setProperty('glas.nextep.' + field, values[field])
    HOME.setProperty('glas.nextep.tvshowid', str(tvshowid))  # zuletzt: Werte sind jetzt vollstaendig


def number(value, default):
    return int(value) if str(value).isdigit() else default


def list_info(handle, query):
    """Verteiler fuer default.py (info=nextup|random)"""
    if query.get('info') == 'nextup':
        kind = query.get('type', 'all')
        list_nextup(handle, kind if kind in ('all', 'movies', 'episodes') else 'all', number(query.get('limit'), 20),
                    query.get('source', ''))
    elif query.get('info') == 'new':
        list_new(handle, query.get('type', 'movies'), query.get('source', ''), number(query.get('limit'), 15))
    else:
        list_random(handle, number(query.get('start'), 0), number(query.get('count'), 20))


def run(action, query):
    """Verteiler fuer default.py (action=play|nextep)"""
    if action == 'play':
        play(query.get('type', ''), query.get('id', ''), query.get('resume') != '0')
    elif action == 'nextep':
        next_episode(query.get('tvshowid', ''))
