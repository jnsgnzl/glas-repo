"""Glas Helper (Dienst): Profilwahl nach dem Ruhezustand und Farbe des Ersatz-Avatars.

tvOS: Einstellung "Profil beim Beenden des Ruhezustands auswaehlen" - nach dem Aufwachen fragt Apple TV, wer zusieht.
Glas: Skin-Einstellung Skin.HasSetting(glas_profile_on_wake). Ausloeser:
  - Kodi meldet System.OnWake (Rueckkehr aus Suspend(), Ruhezustand des Geraets),
  - nach dem Ruhezustand ueber CEC (Geraet ohne Suspend, z. B. Vero: power.py schaltet nur den Fernseher aus und setzt
    Window(Home).Property(glas.standby)) die erste Bedienung danach (Leerlaufzeit springt zurueck bzw. der
    Bildschirmschoner endet).
Dann, wenn mehr als ein Profil existiert, nichts abgespielt wird und die Profilwahl nicht schon offen ist:
ActivateWindow(LoginScreen). Das ist Kodis eigenes Anmeldefenster im laufenden Profil - anders als System.LogOff wird
dabei nichts entladen: waehlt man dasselbe Profil, bleibt es geladen (Kodi startet nur die Dienste neu), ein anderes
Profil laedt Kodi wie beim Wechsel im Kontrollzentrum. Zurueck schliesst die Profilwahl nicht (wie bei Apple).

Ausserdem: Window(Home).Property(glas.avatar) = 1..6, Farbe des Ersatz-Avatars des aktuellen Profils nach seinem Platz in
Kodis Profilliste (gleiche Zuordnung wie die Profillisten im Skin, Variablen GlasAvatarItemVar/GlasAvatarCurrentVar).
"""
import json
import time

import xbmc
import xbmcgui

import stereo
import tags3d

HOME = xbmcgui.Window(10000)
SETTING = 'Skin.HasSetting(glas_profile_on_wake)'
STANDBY = 'glas.standby'
AVATAR_COLORS = 6


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.glas.helper] ' + msg, level)


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def profiles():
    return rpc('Profiles.GetProfiles').get('profiles', [])


def set_avatar():
    """Farbe des Ersatz-Avatars fuer das aktuelle Profil (Platz in der Profilliste, 1-basiert, alle 6 von vorn)."""
    current = rpc('Profiles.GetCurrentProfile').get('label', '')
    names = [p.get('label', '') for p in profiles()]
    index = names.index(current) if current in names else 0
    HOME.setProperty('glas.avatar', str(index % AVATAR_COLORS + 1))


class WakeMonitor(xbmc.Monitor):
    """Ersetzt im Dienst xbmc.Monitor (waitForAbort bleibt) und merkt sich das Aufwachen; tick() im Takt des Dienstes."""

    def __init__(self):
        super().__init__()
        self.pending = False
        self.armed = False      # nach CEC-Ruhezustand: erst einmal Leerlauf gesehen, dann zaehlt die naechste Bedienung
        self.standby_since = 0.0
        try:
            set_avatar()
        except Exception as e:  # nur Optik
            log('Avatar-Farbe: %s' % e, xbmc.LOGDEBUG)

    def onNotification(self, sender, method, data):
        if method == 'System.OnWake':
            log('Aufwachen (System.OnWake)')
            self.pending = True
        elif method == 'System.OnSleep':
            self.armed = False
        elif method in ('VideoLibrary.OnScanFinished', 'Player.OnStop'):
            tags3d.schedule()  # 3D-Schlagwort (tags3d.py); nach dem Stopp kennt Kodi den Stereomodus der ISO
            if method == 'VideoLibrary.OnScanFinished':
                stereo.schedule()  # Stereo-Poster fuer neue Filme (stereo.py), nach dem Schlagwort

    def onScreensaverDeactivated(self):
        if HOME.getProperty(STANDBY):
            log('Aufwachen nach Ruhezustand (Bildschirmschoner beendet)')
            self.pending = True

    def tick(self):
        if HOME.getProperty(STANDBY) and not self.pending:
            # CEC-Ruhezustand: der Klick auf "Ruhezustand" setzt die Leerlaufzeit selbst zurueck, daher erst nach
            # 10 s Leerlauf scharf schalten; danach ist die erste Bedienung das Aufwachen
            if not self.armed:
                if xbmc.getCondVisibility('System.IdleTime(10)'):
                    self.armed = True
            elif not xbmc.getCondVisibility('System.IdleTime(1)'):
                log('Aufwachen nach Ruhezustand (Bedienung)')
                self.pending = True
        if self.pending:
            self.pending = False
            self.armed = False
            HOME.clearProperty(STANDBY)
            self.ask_profile()

    @staticmethod
    def ask_profile():
        if not xbmc.getCondVisibility(SETTING):
            return
        if xbmc.getCondVisibility('Player.HasMedia | Window.IsActive(loginscreen)'):
            return
        if len(profiles()) < 2:
            return
        log('Profilwahl nach dem Ruhezustand')
        xbmc.executebuiltin('Dialog.Close(all,true)')
        # kurz warten, bis die Dialoge zu sind (sonst oeffnet Kodi das Fenster darunter)
        time.sleep(0.3)
        xbmc.executebuiltin('ActivateWindow(LoginScreen)')
