"""Glas Helper: Leinwand kalibrieren (Scope-Modus, docs/plan-scope.md) - fuer Leinwaende, zu denen keines der Formate
2.40 / 2.35 / 2.33 / 2.00 passt oder die nicht mittig im Bild haengen.

plugin://script.glas.helper/?action=screen   Auswahl "Eigene (kalibrieren ...)" ruft run() auf (default.py)

Das Fenster script-glas-screencal.xml (Skin) zeigt zwei helle Balken mit je einer weissen Kante. Hoch/Runter schiebt
die Kante, OK wechselt von der Ober- zur Unterkante und speichert dann; Links/Rechts wechselt ebenfalls, Zurueck bricht
ab. Gespeichert wird Skin.String(glas_screen) = custom mit glas_screen_top / glas_screen_bottom (0 bis 140 in
5er-Schritten wie tools/dev/gen_scope.py; 140 = engster Streifen, auf den der Skin seine Verkleinerungen rechnet),
danach laedt der Skin neu. Solange das Fenster offen ist, blendet der Skin seine Balken aus (Window(Home).Property
(glas_screencal)).
"""
import xbmc
import xbmcaddon
import xbmcgui

STEP, MAX = 5, 140
FORMATS = {'2.40': 140, '2.35': 131, '2.33': 128, '2.00': 60}   # wie service.py (SCOPE_MARGIN)
HEIGHT = 1080
BAR_TOP, BAR_BOTTOM, EDGE_TOP, EDGE_BOTTOM, TEXT, VALUES = 10, 11, 12, 13, 20, 21
EDGE = 4                # Dicke der weissen Kante

ACTION_UP, ACTION_DOWN, ACTION_LEFT, ACTION_RIGHT = 3, 4, 1, 2
ACTION_SELECT = 7
ACTION_BACK = (9, 10, 92)  # Zurueck, Vorheriges Menue, Navigation zurueck


def loc(string_id):
    return xbmc.getInfoLabel('$LOCALIZE[%d]' % string_id)


def snap(value):
    return max(0, min(MAX, int(round(value / STEP)) * STEP))


def current():
    """Ausgangswerte: die gespeicherte Kalibrierung, sonst der Rand des gewaehlten Formats, sonst 2.40."""
    screen = xbmc.getInfoLabel('Skin.String(glas_screen)')
    if screen == 'custom':
        values = [xbmc.getInfoLabel('Skin.String(glas_screen_%s)' % e) for e in ('top', 'bottom')]
        return [int(v) if v.isdigit() else MAX for v in values]
    margin = snap(FORMATS.get(screen, MAX))
    return [margin, margin]


class Calibration(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.values = current()
        self.edge = 0           # 0 = oben, 1 = unten
        self.saved = False

    def onInit(self):
        self.show_state()

    def show_state(self):
        top, bottom = self.values
        self.getControl(BAR_TOP).setHeight(max(1, top))
        self.getControl(BAR_BOTTOM).setPosition(0, HEIGHT - bottom)
        self.getControl(BAR_BOTTOM).setHeight(max(1, bottom))
        self.getControl(EDGE_TOP).setPosition(0, top - EDGE)
        self.getControl(EDGE_BOTTOM).setPosition(0, HEIGHT - bottom)
        self.getControl(TEXT).setText(loc(31583 if self.edge == 0 else 31584))
        self.getControl(VALUES).setLabel(loc(31587) % (top, bottom))

    def onAction(self, action):
        a = action.getId()
        if a in ACTION_BACK:
            self.close()
        elif a in (ACTION_UP, ACTION_DOWN):
            # Hoch schiebt die bearbeitete Kante nach oben: oben kleinerer Rand, unten groesserer
            delta = -STEP if a == ACTION_UP else STEP
            if self.edge == 1:
                delta = -delta
            self.values[self.edge] = snap(self.values[self.edge] + delta)
            self.show_state()
        elif a in (ACTION_LEFT, ACTION_RIGHT):
            self.edge = 1 - self.edge
            self.show_state()
        elif a == ACTION_SELECT:
            if self.edge == 0:
                self.edge = 1
                self.show_state()
            else:
                self.saved = True
                self.close()


def run():
    home = xbmcgui.Window(10000)
    home.setProperty('glas_screencal', '1')
    try:
        path = xbmcaddon.Addon('script.glas.helper').getAddonInfo('path')
        dialog = Calibration('script-glas-screencal.xml', path, 'default', '1080i')
        dialog.doModal()
        saved, (top, bottom) = dialog.saved, dialog.values
        del dialog
    finally:
        home.clearProperty('glas_screencal')
    if not saved:
        return
    xbmc.executebuiltin('Skin.SetString(glas_screen,custom)')
    xbmc.executebuiltin('Skin.SetString(glas_screen_top,%d)' % top)
    xbmc.executebuiltin('Skin.SetString(glas_screen_bottom,%d)' % bottom)
    xbmc.sleep(300)  # Fenster ganz schliessen lassen: ReloadSkin ueber einem Dialog kann Kodi abstuerzen lassen
    xbmc.executebuiltin('ReloadSkin()')
