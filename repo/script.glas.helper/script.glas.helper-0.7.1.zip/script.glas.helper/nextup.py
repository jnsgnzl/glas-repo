"""Glas Helper: Listen und Aktionen fuer "Weiter ansehen" (Up Next), die naechste Folge einer Serie und die Zufallsreihe.

plugin://script.glas.helper/?info=nextup[&type=all|movies|episodes][&limit=20]
    Angefangene Filme und je laufender Serie die naechste Folge (angefangen oder ungesehen), sortiert nach "zuletzt
    gesehen". Eintraege mit vollem Artwork, Fortschritt (Resume), DBID/DBType; Property "glas.sub" = Unterzeile
    ("S2, F4 · Noch 20 Min."), "glas.remaining" = Restminuten, "glas.tvshowid". Der Pfad spielt fortsetzend ab
    (?action=play...). Im Skin per <onclick> am Container abspielen, damit Kodi nicht nach dem Fortsetzen fragt.
plugin://script.glas.helper/?info=random&start=0&count=20
    Ungesehene Filme in zufaelliger, aber je Kodi-Sitzung fester Reihenfolge (Window(Home).Property(glas.seed)).
    start/count schneiden einen Teil heraus (Titelbild 0-7, Reihe ab 8), damit nichts doppelt erscheint.
plugin://script.glas.helper/?action=play&type=movie|episode&id=N[&resume=0]
    Abspielen ueber Player.Open; fortsetzend ohne Rueckfrage (resume=0: von Anfang an).
plugin://script.glas.helper/?action=nextep&tvshowid=N
    Naechste Folge einer Serie in Window(Home)-Properties (ein JSON-RPC-Aufruf):
    glas.nextep.state (start|continue|rewatch, leer = keine Folgen), .label ("S2, F4"), .title, .season, .episode,
    .file, .episodeid, .percent (0-100), .remaining (Minuten), zuletzt .tvshowid (gilt, wenn = aktuelle Serie).
"""
import hashlib
import json
import random
from urllib.parse import urlencode

import xbmc
import xbmcgui
import xbmcplugin

BASE = 'plugin://script.glas.helper/'
HOME = xbmcgui.Window(10000)
MOVIE_PROPS = ['title', 'year', 'genre', 'plot', 'runtime', 'resume', 'lastplayed', 'playcount', 'art', 'file',
               'rating', 'mpaa', 'tagline', 'premiered']
EPISODE_PROPS = ['title', 'season', 'episode', 'showtitle', 'tvshowid', 'plot', 'runtime', 'resume', 'lastplayed',
                 'playcount', 'art', 'file', 'firstaired', 'rating']
# fuer die Wahl der naechsten Folge reicht wenig (eine Serie kann Hunderte Folgen haben)
CHOOSE_PROPS = ['title', 'season', 'episode', 'playcount', 'resume', 'lastplayed', 'file', 'runtime']


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def localize(string_id):
    return xbmc.getInfoLabel('$LOCALIZE[%d]' % string_id)


def remaining_minutes(resume, runtime):
    total = (resume or {}).get('total') or runtime or 0
    position = (resume or {}).get('position') or 0
    return max(0, int(round((total - position) / 60.0))) if total else 0


def percent_played(resume):
    total = (resume or {}).get('total') or 0
    return int(100 * resume.get('position', 0) / total) if total else 0


def episode_label(season, episode):
    """"S2, F4" (Deutsch) bzw. "S2, E4" """
    return localize(31203).format(season, episode)


def choose_episode(episodes):
    """Naechste Folge wie in Apples TV-App -> (Zustand, Folge).
    continue: angefangene Folge bzw. die nach der zuletzt gesehenen; start: noch nichts gesehen (erste Folge);
    rewatch: alles gesehen (erste Folge). Specials (Staffel 0) nur, wenn es nichts anderes gibt."""
    regular = [e for e in episodes if e.get('season', 0) > 0] or list(episodes)
    if not regular:
        return '', None
    regular.sort(key=lambda e: (e.get('season', 0), e.get('episode', 0)))
    played = [e for e in regular if e.get('lastplayed')]
    if played:
        anchor = max(played, key=lambda e: e['lastplayed'])
        if (anchor.get('resume') or {}).get('position', 0) > 0 or not anchor.get('playcount'):
            return 'continue', anchor   # angefangen bzw. nur kurz angespielt: dieselbe Folge
        index = regular.index(anchor)
        if index + 1 < len(regular):
            return 'continue', regular[index + 1]
    unwatched = [e for e in regular if not e.get('playcount')]
    if not unwatched:
        return 'rewatch', regular[0]
    if len(unwatched) == len(regular):
        return 'start', regular[0]
    # ohne Wiedergabedatum als gesehen markiert: erste ungesehene nach der letzten gesehenen
    last_seen = max(i for i, e in enumerate(regular) if e.get('playcount'))
    later = [e for e in regular[last_seen + 1:] if not e.get('playcount')]
    return 'continue', (later or unwatched)[0]


def show_episodes(tvshowid, properties=CHOOSE_PROPS):
    return rpc('VideoLibrary.GetEpisodes', tvshowid=int(tvshowid), properties=properties).get('episodes', [])


def play_url(kind, dbid):
    return BASE + '?' + urlencode({'action': 'play', 'type': kind, 'id': dbid})


def video_item(kind, data, sub=''):
    """Plugin-Eintrag mit den Daten aus der Videobibliothek (DBID, Art, Fortschritt)"""
    art = dict(data.get('art') or {})
    if kind == 'episode':
        label = data.get('showtitle') or data.get('title', '')
        for key in ('fanart', 'poster', 'clearlogo', 'landscape', 'banner'):
            if not art.get(key) and art.get('tvshow.' + key):
                art[key] = art['tvshow.' + key]
    else:
        label = data.get('title') or data.get('label', '')
    item = xbmcgui.ListItem(label, offscreen=True)
    item.setArt(art)
    tag = item.getVideoInfoTag()
    tag.setMediaType(kind)
    tag.setDbId(int(data.get(kind + 'id', 0)))
    tag.setTitle(data.get('title', ''))
    tag.setPlot(data.get('plot', ''))
    tag.setDuration(int(data.get('runtime') or 0))
    tag.setPlaycount(int(data.get('playcount') or 0))
    if data.get('lastplayed'):
        tag.setLastPlayed(data['lastplayed'])
    if data.get('file'):
        tag.setFilenameAndPath(data['file'])
    if data.get('rating'):
        tag.setRating(float(data['rating']))
    resume = data.get('resume') or {}
    if resume.get('position'):
        tag.setResumePoint(float(resume['position']), float(resume.get('total') or 0))
    if kind == 'episode':
        tag.setTvShowTitle(data.get('showtitle', ''))
        tag.setSeason(int(data.get('season', 0)))
        tag.setEpisode(int(data.get('episode', 0)))
        tag.setFirstAired(data.get('firstaired', ''))
        item.setProperty('glas.tvshowid', str(data.get('tvshowid', '')))
    else:
        if data.get('year'):
            tag.setYear(int(data['year']))
        tag.setGenres(data.get('genre') or [])
        tag.setMpaa(data.get('mpaa', ''))
        tag.setTagLine(data.get('tagline', ''))
        tag.setPremiered(data.get('premiered', ''))
    item.setProperty('glas.remaining', str(remaining_minutes(resume, data.get('runtime'))))
    item.setProperty('glas.sub', sub)
    return play_url(kind, data.get(kind + 'id', 0)), item, False


def left_label(data):
    minutes = remaining_minutes(data.get('resume'), data.get('runtime'))
    return localize(31205).format(minutes) if minutes else ''


def nextup_entries(kind='all', limit=20):
    """[(zuletzt gesehen, Art, Daten)] fuer "Weiter ansehen" """
    entries = []
    if kind in ('all', 'movies'):
        movies = rpc('VideoLibrary.GetMovies', properties=MOVIE_PROPS, limits={'end': limit},
                     sort={'method': 'lastplayed', 'order': 'descending'},
                     filter={'field': 'inprogress', 'operator': 'true', 'value': ''}).get('movies', [])
        entries += [(m.get('lastplayed', ''), 'movie', m) for m in movies]
    if kind in ('all', 'episodes'):
        shows = rpc('VideoLibrary.GetTVShows', properties=['lastplayed'], limits={'end': limit},
                    sort={'method': 'lastplayed', 'order': 'descending'}).get('tvshows', [])
        for show in shows:
            if not show.get('lastplayed'):
                continue
            state, episode = choose_episode(show_episodes(show['tvshowid']))
            if state != 'continue':
                continue    # noch nicht begonnen oder fertig gesehen
            details = rpc('VideoLibrary.GetEpisodeDetails', episodeid=episode['episodeid'],
                          properties=EPISODE_PROPS).get('episodedetails')
            if details:
                entries.append((episode.get('lastplayed') or show['lastplayed'], 'episode', details))
    entries.sort(key=lambda e: e[0], reverse=True)
    return entries[:limit]


def list_nextup(handle, kind='all', limit=20):
    items = []
    for _, media, data in nextup_entries(kind, limit):
        if media == 'episode':
            head = episode_label(data.get('season', 0), data.get('episode', 0))
            tail = left_label(data) if (data.get('resume') or {}).get('position') else data.get('title', '')
            sub = '  ·  '.join(x for x in (head, tail) if x)
        else:
            sub = left_label(data)
        items.append(video_item(media, data, sub))
    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def session_seed():
    seed = HOME.getProperty('glas.seed')
    if not seed:
        seed = str(random.getrandbits(32))
        HOME.setProperty('glas.seed', seed)
    return seed


def list_random(handle, start=0, count=20):
    """Ungesehene Filme, je Sitzung gleich gemischt: Rang = Hash aus Sitzung und Film-ID (ein gesehener Film faellt
    heraus, ohne die uebrigen umzustellen)"""
    seed = session_seed()
    movies = rpc('VideoLibrary.GetMovies', filter={'field': 'playcount', 'operator': 'lessthan', 'value': '1'}
                 ).get('movies', [])
    ids = sorted((m['movieid'] for m in movies),
                 key=lambda i: hashlib.md5(('%s:%d' % (seed, i)).encode()).hexdigest())
    items = []
    for movieid in ids[start:start + count]:
        data = rpc('VideoLibrary.GetMovieDetails', movieid=movieid, properties=MOVIE_PROPS).get('moviedetails')
        if data:
            items.append(video_item('movie', data))
    xbmcplugin.setContent(handle, 'movies')
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def play(kind, dbid, resume=True):
    key = {'movie': 'movieid', 'episode': 'episodeid'}.get(kind)
    if key and str(dbid).isdigit() and int(dbid) > 0:
        rpc('Player.Open', item={key: int(dbid)}, options={'resume': bool(resume)})


NEXTEP_FIELDS = ('state', 'label', 'title', 'season', 'episode', 'file', 'episodeid', 'percent', 'remaining')


def next_episode(tvshowid):
    """Naechste Folge einer Serie fuer die Detailseite (Window(Home)-Properties glas.nextep.*)"""
    if not str(tvshowid).isdigit():
        return
    state, episode = choose_episode(show_episodes(tvshowid))
    values = dict.fromkeys(NEXTEP_FIELDS, '')
    if episode:
        resume = episode.get('resume') or {}
        values.update(state=state, label=episode_label(episode.get('season', 0), episode.get('episode', 0)),
                      title=episode.get('title', ''), season=str(episode.get('season', '')),
                      episode=str(episode.get('episode', '')), file=episode.get('file', ''),
                      episodeid=str(episode.get('episodeid', '')), percent=str(percent_played(resume)),
                      remaining=str(remaining_minutes(resume, episode.get('runtime'))))
    for field in NEXTEP_FIELDS:
        HOME.setProperty('glas.nextep.' + field, values[field])
    HOME.setProperty('glas.nextep.tvshowid', str(tvshowid))  # zuletzt: Werte sind jetzt vollstaendig


def number(value, default):
    return int(value) if str(value).isdigit() else default


def list_info(handle, query):
    """Verteiler fuer default.py (info=nextup|random)"""
    if query.get('info') == 'nextup':
        kind = query.get('type', 'all')
        list_nextup(handle, kind if kind in ('all', 'movies', 'episodes') else 'all', number(query.get('limit'), 20))
    else:
        list_random(handle, number(query.get('start'), 0), number(query.get('count'), 20))


def run(action, query):
    """Verteiler fuer default.py (action=play|nextep)"""
    if action == 'play':
        play(query.get('type', ''), query.get('id', ''), query.get('resume') != '0')
    elif action == 'nextep':
        next_episode(query.get('tvshowid', ''))
