"""App-Logos fuer die Apps-Seite: aus dem quadratischen Add-on-Symbol ein freigestelltes Logo machen.

Kodi-Add-ons bringen nur ein deckendes Symbol mit (meist Logo auf einfarbiger Flaeche). Liegt am Rand eine einheitliche
Farbe, wird diese Flaeche von aussen her freigestellt (Flood-Fill), die Kanten weich ausgeblendet und von der alten
Hintergrundfarbe befreit, dann auf das Logo zugeschnitten. Dunkle, farblose Teile werden hell, damit sie auf der
dunklen Kachel lesbar sind. Ohne einheitlichen Rand (Foto-Symbole) gibt es stattdessen einen weichgezeichneten Kachelhintergrund.
Nur Pillow, ohne Kodi-Module (testbar ausserhalb von Kodi).
"""
import statistics
from collections import deque

from PIL import Image, ImageEnhance, ImageFilter, ImageOps

SIZE = 256          # Arbeitsgroesse
TOL = 38            # Farbabstand, der noch als Hintergrund gilt
SOLID = 0.82        # Anteil Randpixel mit Hintergrundfarbe, ab dem der Rand als einfarbig gilt
PHOTO = 160         # Farbstufen (4 Bit je Kanal, mind. 4 Pixel) im Vordergrund, ab denen ein Symbol als Foto gilt
VISIBLE = 110       # Deckkraft, ab der Pixel beim Zuschneiden zaehlen (blasse Reste bleiben ausserhalb)
NEAR = 0.3          # Anteil des Motivs nahe der (hellen) Hintergrundfarbe, ab dem nicht freigestellt wird


def _dist(a, b):
    return ((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2) ** 0.5


def _border(w, h):
    for x in range(w):
        yield x, 0
        yield x, h - 1
    for y in range(1, h - 1):
        yield 0, y
        yield w - 1, y


def make_logo(src):
    """Gibt ('logo', Bild) oder ('tile', Bild) zurueck."""
    img = Image.open(src).convert('RGBA')
    img.thumbnail((SIZE, SIZE), Image.LANCZOS)
    w, h = img.size
    px = img.load()
    border = [px[x, y] for x, y in _border(w, h)]

    # schon freigestellt (transparenter Rand)
    if sum(1 for p in border if p[3] < 30) / len(border) > SOLID:
        return 'logo', _finish(img)

    opaque = [p for p in border if p[3] > 200]
    if not opaque:
        return 'tile', _tile(img)
    bg = tuple(sorted(c[i] for c in opaque)[len(opaque) // 2] for i in range(3))
    if sum(1 for p in opaque if _dist(p, bg) < TOL) / len(border) < SOLID:
        return 'tile', _tile(img)

    # Hintergrund von aussen her fluten
    is_bg = [[False] * h for _ in range(w)]
    queue = deque((x, y) for x, y in _border(w, h) if _dist(px[x, y], bg) < TOL)
    for x, y in queue:
        is_bg[x][y] = True
    while queue:
        x, y = queue.popleft()
        for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
            if 0 <= nx < w and 0 <= ny < h and not is_bg[nx][ny] and _dist(px[nx, ny], bg) < TOL:
                is_bg[nx][ny] = True
                queue.append((nx, ny))

    # Motiv aehnelt dem Hintergrund (z. B. weisse Maus auf Weiss) oder ist ein Foto mit vielen Abstufungen: die Flutung
    # wuerde Teile anfressen. Dann lieber Kachelhintergrund mit abgerundetem Symbol.
    buckets, fg, near = {}, 0, 0
    for x in range(w):
        for y in range(h):
            if not is_bg[x][y] and px[x, y][3] > 200:
                fg += 1
                r, g, b, _ = px[x, y]
                if _dist((r, g, b), bg) < TOL * 2:
                    near += 1
                key = (r >> 4, g >> 4, b >> 4)
                buckets[key] = buckets.get(key, 0) + 1
    light_bg = 0.2126 * bg[0] + 0.7152 * bg[1] + 0.0722 * bg[2] > 200
    if not fg or (light_bg and near / fg > NEAR) or sum(1 for n in buckets.values() if n >= 4) > PHOTO:
        return 'tile', _tile(img)

    out = Image.new('RGBA', (w, h), (0, 0, 0, 0))
    po = out.load()
    for x in range(w):
        for y in range(h):
            if is_bg[x][y]:
                continue
            r, g, b, a = px[x, y]
            edge = any(0 <= nx < w and 0 <= ny < h and is_bg[nx][ny]
                       for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)))
            if edge:
                # Kante: Deckkraft nach Farbabstand, Farbe ohne Anteil der alten Hintergrundfarbe
                k = min(1.0, max(0.05, _dist((r, g, b), bg) / (TOL * 3)))
                r, g, b = (min(255, max(0, round((c - (1 - k) * bc) / k))) for c, bc in zip((r, g, b), bg))
                a = round(a * k)
            po[x, y] = (r, g, b, a)
    return 'logo', _finish(out)


def _finish(img):
    # Dunkle, farblose Teile (z. B. schwarzer Schriftzug) wie im dunklen Modus von tvOS weiss; Farbiges bleibt.
    # Nur wenn das Dunkle gleichmaessig ist (Schrift, Flaeche), nicht bei Fotos. Die Deckkraft behaelt die weiche Kante.
    px = img.load()
    dark = [max(r, g, b) for x in range(img.width) for y in range(img.height)
            for r, g, b, a in (px[x, y],) if a > 200 and max(r, g, b) < 110 and max(r, g, b) - min(r, g, b) < 36]
    # nicht, wenn das Logo selbst grosse helle Flaechen hat (dunkle Schrift auf hellem Feld bliebe sonst unsichtbar)
    solid = [min(r, g, b) for x in range(img.width) for y in range(img.height)
             for r, g, b, a in (px[x, y],) if a > 200]
    bright = sum(1 for v in solid if v > 200) / max(1, len(solid))
    if len(dark) > 20 and statistics.pstdev(dark) < 14 and bright < 0.25:  # gleichmaessig dunkel = Schrift
        for x in range(img.width):
            for y in range(img.height):
                r, g, b, a = px[x, y]
                if a and max(r, g, b) < 110 and max(r, g, b) - min(r, g, b) < 36:
                    px[x, y] = (255, 255, 255, a)
    # danach: Zuschnitt nur auf das, was auf der dunklen Kachel sichtbar ist (deckend und nicht fast schwarz)
    alpha = img.getchannel('A').point(lambda v: 255 if v > VISIBLE else 0)
    light = img.convert('RGB').convert('L').point(lambda v: 255 if v > 60 else 0)
    box = Image.composite(alpha, Image.new('L', img.size, 0), light).getbbox() or alpha.getbbox()
    if box:
        img = img.crop(box)
    return img


def _tile(img):
    """Kachelhintergrund aus dem Symbol: fuellend, weichgezeichnet, abgedunkelt (16:10 wie die Kachel)."""
    rgb = img.convert('RGB')
    tile = ImageOps.fit(rgb, (320, 192), Image.BILINEAR)
    tile = tile.filter(ImageFilter.GaussianBlur(14))
    return ImageEnhance.Brightness(tile).enhance(0.6)


def _rounded(img, size, radius):
    img = ImageOps.fit(img.convert('RGBA'), (size, size), Image.LANCZOS)
    # abgerundete Maske von Hand (rounded_rectangle gibt es erst ab Pillow 8.2, die Vero hat 8.1)
    from PIL import ImageDraw
    big, r = size * 4, radius * 4
    mask = Image.new('L', (big, big), 0)
    draw = ImageDraw.Draw(mask)
    draw.rectangle((r, 0, big - 1 - r, big - 1), fill=255)
    draw.rectangle((0, r, big - 1, big - 1 - r), fill=255)
    for x, y in ((0, 0), (big - 1 - 2 * r, 0), (0, big - 1 - 2 * r), (big - 1 - 2 * r, big - 1 - 2 * r)):
        draw.ellipse((x, y, x + 2 * r, y + 2 * r), fill=255)
    mask = mask.resize((size, size), Image.LANCZOS)
    img.putalpha(Image.composite(img.getchannel('A'), Image.new('L', (size, size), 0), mask))
    return img


def make_card(tile_path=None, logo_path=None, icon_path=None):
    """Fertige App-Kachel 500 x 300 wie auf dem Homescreen (Kachelanzeige 250 x 150, doppelte Aufloesung):
    Kachelhintergrund (Marke oder weichgezeichnet) bzw. dunkle Flaeche, darauf das Logo (Feld 380 x 180) oder das
    abgerundete Symbol (220 x 220). Ecken rundet der Skin."""
    if tile_path:
        card = ImageOps.fit(Image.open(tile_path).convert('RGB'), (500, 300), Image.LANCZOS)
    else:
        card = Image.new('RGB', (500, 300), (44, 44, 46))
        top = Image.new('RGB', (500, 300), (58, 58, 60))
        card = Image.composite(top, card, Image.linear_gradient('L').resize((500, 300)).point(lambda v: 255 - v))
    if logo_path:
        logo = Image.open(logo_path).convert('RGBA')
        logo.thumbnail((380, 180), Image.LANCZOS)
        card.paste(logo, ((500 - logo.width) // 2, (300 - logo.height) // 2), logo)
    elif icon_path:
        icon = _rounded(Image.open(icon_path), 220, 44)
        card.paste(icon, (140, 40), icon)
    return card


def make_brand(glyph_path, hex_color):
    """Kachel in Markenfarbe (oben 6 % heller, wie die Tiefe von tvOS-Symbolen) und das Marken-Logo darauf.
    Gibt (Kachel, Logo) zurueck; das Logo ist weiss, bei sehr heller Markenfarbe dunkel."""
    r, g, b = (int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
    tile = Image.new('RGB', (320, 192), (r, g, b))
    top = Image.new('RGB', (320, 192), tuple(min(255, round(c + (255 - c) * 0.06)) for c in (r, g, b)))
    grad = Image.linear_gradient('L').resize((320, 192)).point(lambda v: 255 - v)
    tile = Image.composite(top, tile, grad)
    glyph = Image.open(glyph_path).convert('RGBA')
    box = glyph.getchannel('A').getbbox()
    if box:
        glyph = glyph.crop(box)
    light = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255 > 0.65
    if light:
        glyph = Image.merge('RGBA', (*Image.new('RGB', glyph.size, (28, 28, 30)).split(), glyph.getchannel('A')))
    # Logo hoechstens 300 x 100 auf einer 380 x 180 grossen Flaeche (Kachelanzeige 190 x 90): Symbol etwa 50 px hoch
    glyph.thumbnail((300, 100), Image.LANCZOS)
    logo = Image.new('RGBA', (380, 180), (0, 0, 0, 0))
    logo.paste(glyph, ((380 - glyph.width) // 2, (180 - glyph.height) // 2), glyph)
    return tile, logo
