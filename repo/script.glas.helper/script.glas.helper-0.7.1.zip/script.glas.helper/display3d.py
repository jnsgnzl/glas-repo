"""Glas Helper: Oberflaeche in 3D (Kreis mit 3D-Symbol im Kontrollzentrum, anstelle von Ton aus/an).

Kodi zeichnet Menues nur waehrend eines 3D-Films stereo - oder wenn beides eingestellt ist: eine 3D-Aufloesung der
Ausgabe (videoscreen.resolution, 1920x1080p (3D FP) = 1080p 24 Hz Frame Packing) und der Stereomodus der Oberflaeche
(videoscreen.stereoscopicmode = 8, Frame Packing). Nur die Aufloesung ergibt eine 3D-Ausgabe mit flacher Oberflaeche,
nur der Stereomodus eine 2D-Ausgabe mit zerlegtem Bild (beides auf der Vero gemessen, 24.10.2026). Erst mit beidem
zeigt die Mediathek die Stereo-Poster (stereo.py).

plugin://script.glas.helper/?action=gui3d   Oberflaeche zwischen 3D (Frame Packing) und der vorigen 2D-Aufloesung
                                            umschalten (Kodis Einstellungen, bleiben gespeichert)

Kodi fragt nach dem Aufloesungswechsel 15 s lang "Aufloesung beibehalten?" und schaltet ohne "Ja" zurueck - so bleibt
nie ein schwarzes Bild stehen, wenn der Projektor kein 3D zeigt. Der Helper setzt den Fokus dort auf "Ja" (Knopf 11),
die Fernbedienung bestaetigt mit OK. Den Stereomodus stellt er erst nach einem "Ja" um (hin zu 3D danach, zurueck zu
2D ebenfalls erst nach bestaetigter 2D-Aufloesung). Waehrend der Rueckfrage kehrt der JSON-RPC-Aufruf nicht zurueck (er
wartet auf den Dialog), daher laeuft er in einem eigenen Faden.
Ohne Rueckfrage (Skin-Einstellung "Aufloesung bestaetigen" aus, Skin.HasSetting(glas_3d_noconfirm)): der Alert bleibt
unsichtbar (Window(Home).Property(glas.silentconfirm), DialogConfirm.xml) und der Helper klickt selbst "Ja"
(SendClick an den Ja/Nein-Dialog 10100). Meldet die Vero keinen angeschlossenen Bildschirm (HDMI hpd_state 0), kommt
die Rueckfrage trotzdem.
Rueckweg: die vor dem Wechsel gemerkte 2D-Einstellung (Skin.String(glas_gui2d_mode), Wert von videoscreen.screenmode
wie 0192001080060.00000pstd), sonst 1920x1080p (2D).
Window(Home).Property(glas.can3d): die Ausgabe kennt 1920x1080p (3D FP), nur dann zeigt der Skin den 3D-Kreis (update(),
beim Start des Dienstes).
"""
import json
import os
import threading
import time

import xbmc

FP_LABEL = '1920x1080p (3D FP)'     # OSMC-Bezeichnung in der Aufloesungsliste (DisplaySettings, vero5-Patch)
FLAT_LABEL = '1920x1080p (2D)'
STEREO_FP = 8                       # RENDER_STEREO_MODE_HARDWAREBASED, in Kodi "Frame Packing"
STEREO_OFF = 0
SAVED = 'glas_gui2d_mode'
CONFIRM_WAIT = 30                   # Sekunden: Umschalten (~5 s) plus Kodis Rueckfrage (15 s)
YESNO = 10100                       # Fenster-ID des Ja/Nein-Dialogs (WINDOW_DIALOG_YES_NO)
HPD = '/sys/class/amhdmitx/amhdmitx0/hpd_state'  # Amlogic: 1 = Bildschirm angeschlossen


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.glas.helper] ' + msg, level)


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result')


def resolution_options():
    """{Bezeichnung: Wert} der Einstellung videoscreen.resolution (Liste haengt an der Ausgabe)."""
    result = rpc('Settings.GetSettings', level='expert', filter={'section': 'system', 'category': 'display'}) or {}
    for setting in result.get('settings') or []:
        if setting.get('id') == 'videoscreen.resolution':
            return {o.get('label'): o.get('value') for o in setting.get('options') or []}
    return {}


def update():
    """Beim Start des Dienstes: Window(Home).Property(glas.can3d) setzen, wenn die Ausgabe eine 3D-FP-Aufloesung
    anbietet. Startet Kodi ohne 3D-Ausgabe (Projektor aus: keine 3D-Aufloesungen, Kodi nimmt eine 2D-Aufloesung), darf
    der Stereomodus nicht auf Frame Packing bleiben - sonst zerfaellt die Oberflaeche in zwei Haelften."""
    home = 'SetProperty(glas.can3d,1,home)' if FP_LABEL in resolution_options() else 'ClearProperty(glas.can3d,home)'
    xbmc.executebuiltin(home)
    match_stereo()


def match_stereo():
    """Stereomodus der Oberflaeche passend zur Ausgabe (ohne laufendes Video), in beiden Richtungen:
    - 3D-Modus bei 2D-Ausgabe: zurueck auf aus.
    - 3D-Ausgabe (gespeicherte Aufloesung 1080p FP) bei flacher Oberflaeche: wieder Frame Packing. So kam Kodi nach
      einem Absturz hoch (Stereomodus nicht mehr gespeichert), und so endet jeder 3D-Film: Kodis
      videoplayer.quitstereomodeonstop schaltet den Stereomodus aus, die Aufloesung kehrt aber zur 3D-Aufloesung der
      Oberflaeche zurueck - 3D-Ausgabe mit flacher Oberflaeche, auf der Leinwand unbrauchbar (Vero, 24.10.2026)."""
    if xbmc.getCondVisibility('Player.HasVideo'):
        return
    stereo = (rpc('Settings.GetSettingValue', setting='videoscreen.stereoscopicmode') or {}).get('value')
    fp = screenmode().endswith('fp')
    if stereo == STEREO_FP and not fp:
        log('3D-Oberflaeche: Ausgabe ist 2D, Stereomodus zurueck auf aus', xbmc.LOGWARNING)
        set_stereo(STEREO_OFF)
    elif stereo == STEREO_OFF and fp:
        log('3D-Oberflaeche: Ausgabe ist 3D, Stereomodus wieder Frame Packing', xbmc.LOGWARNING)
        set_stereo(STEREO_FP)


class Watch:
    """Dienst, 4x je Sekunde (tick): Wechsel zwischen Wiedergabe und Menues.
    1. Eigener Build in 3D: am Ende jedes Bildes auf die GPU warten (glFinish) nur waehrend ein Video laeuft.
    Der Build wartet in 3D sonst immer (seit 17.10.2026: ueber einem 3D-Film stockten ohne das Film und Glas). In den
    Menues ohne Film bremst es: auf der Vero (24.10.2026, Mediathek bzw. Homescreen in 3D blaettern) 74 bzw. 64 % der
    Bilder verspaetet, ohne Warten 18 bzw. 27 %. Der Build prueft je Sekunde den Messschalter
    /tmp/glas-stereo-finish-off; der Dienst legt ihn ohne Video an und entfernt ihn mit Video. Besser waere die
    Bedingung im Kern selbst (beim naechsten Build: nur mit Video warten).
    2. Nach dem Ende einer Wiedergabe: Stereomodus wieder passend zur Ausgabe (match_stereo). Kodi schaltet ihn erst
    nach dem Stopp aus (videoplayer.quitstereomodeonstop) und stellt die Aufloesung zurueck; darum WINDOW Sekunden lang
    bei jedem Durchlauf nachsehen, sobald die Oberflaeche flach ist (gemessen: nach etwa 2 s)."""
    SWITCH = '/tmp/glas-stereo-finish-off'
    WINDOW = 10.0

    def __init__(self):
        self.state = None
        self.check_until = None

    def tick(self):
        off = not xbmc.getCondVisibility('Player.HasVideo')
        if self.check_until:
            if not off or time.monotonic() > self.check_until:
                self.check_until = None
            elif xbmc.getInfoLabel('System.StereoscopicMode') == '0':
                match_stereo()
        if off == self.state:
            return
        # nur wenn die Oberflaeche auf 3D steht (gespeicherte Aufloesung 1080p FP); sonst gibt es nichts zu korrigieren
        if off and self.state is not None and xbmc.getInfoLabel('Window(Home).Property(glas.can3d)') and \
                screenmode().endswith('fp'):
            self.check_until = time.monotonic() + self.WINDOW
        self.state = off
        if not xbmc.getInfoLabel('Window(Home).Property(glas.corebuild)'):
            return
        try:
            if off:
                open(self.SWITCH, 'w').close()
            elif os.path.exists(self.SWITCH):
                os.remove(self.SWITCH)
        except OSError as e:
            log('3D: Schalter %s nicht gesetzt: %s' % (self.SWITCH, e), xbmc.LOGWARNING)


def screenmode():
    return (rpc('Settings.GetSettingValue', setting='videoscreen.screenmode') or {}).get('value') or ''


def set_stereo(mode):
    rpc('Settings.SetSettingValue', setting='videoscreen.stereoscopicmode', value=mode)


def display_connected():
    """False nur, wenn die Vero sicher keinen Bildschirm meldet (anderswo: unbekannt = True)."""
    try:
        with open(HPD, encoding='ascii') as f:
            return f.read().strip() != '0'
    except OSError:
        return True


def change_resolution(setting, value):
    """Aufloesung setzen und auf Kodis Rueckfrage warten; True, wenn mit "Ja" bestaetigt."""
    silent = xbmc.getCondVisibility('Skin.HasSetting(glas_3d_noconfirm)') and display_connected()
    if silent:
        xbmc.executebuiltin('SetProperty(glas.silentconfirm,1,home)')
    result = {}

    def change():
        result['ok'] = rpc('Settings.SetSettingValue', setting=setting, value=value) is True
        log('3D-Oberflaeche: %s = %s -> %s' % (setting, value, result['ok']))

    worker = threading.Thread(target=change, daemon=True)
    worker.start()
    monitor = xbmc.Monitor()
    answered = False
    try:
        for _ in range(CONFIRM_WAIT * 4):
            if not worker.is_alive() or monitor.waitForAbort(0.25):
                break
            if not answered and xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
                # Ja (Knopf 11): still selbst klicken, sonst nur den Fokus dorthin setzen
                xbmc.executebuiltin('SendClick(%d,11)' % YESNO if silent else 'SetFocus(11)')
                answered = True
        worker.join(1)
    finally:
        if silent:
            xbmc.executebuiltin('ClearProperty(glas.silentconfirm,home)')
    return result.get('ok', False)


def toggle():
    if xbmc.getCondVisibility('Player.HasVideo'):
        return  # waehrend der Wiedergabe bestimmt der Film die Ausgabe
    xbmc.executebuiltin('Dialog.Close(1120)')  # Kontrollzentrum zu, damit Kodis Rueckfrage frei steht
    options = resolution_options()
    current = screenmode()
    if current.endswith('fp'):
        saved = xbmc.getInfoLabel('Skin.String(%s)' % SAVED)
        ok = (change_resolution('videoscreen.screenmode', saved) if saved
              else change_resolution('videoscreen.resolution', options.get(FLAT_LABEL)))
        if ok or not screenmode().endswith('fp'):
            set_stereo(STEREO_OFF)
    else:
        if FP_LABEL not in options:
            log('3D-Oberflaeche: Ausgabe ohne %s' % FP_LABEL, xbmc.LOGWARNING)
            return
        xbmc.executebuiltin('Skin.SetString(%s,%s)' % (SAVED, current))
        if change_resolution('videoscreen.resolution', options[FP_LABEL]):
            set_stereo(STEREO_FP)
