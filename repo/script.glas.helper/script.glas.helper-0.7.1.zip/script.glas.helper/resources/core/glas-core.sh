#!/bin/sh
# Glas Helper (core.py): eigenen Kodi-Build einsetzen bzw. OSMCs Kodi wiederherstellen. Laeuft als root (sudo -n).
#   glas-core.sh install <kodi.bin> <Kennung>   Build einsetzen, Starter davor, OSMCs Kodi-Paket sperren
#   glas-core.sh starter                        nur den Starter erneuern (neuere Fassung im Glas Helper)
#   glas-core.sh remove                         OSMCs kodi.bin zurueck, Sperre aufheben
#   glas-core.sh restart                        Kodi ueber systemd neu starten (getrennt von Kodi)
# Exit 3: kein unveraendertes OSMC-Original gefunden (nichts geaendert).
set -eu
LIB=/usr/lib/kodi
STATE=/var/lib/glas-core
PKG=vero5-mediacenter-osmc
HERE=$(dirname "$0")

original_md5() { awk '$2 == "usr/lib/kodi/kodi.bin" { print $1 }' /var/lib/dpkg/info/$PKG.md5sums; }
is_original() { [ -f "$1" ] && [ "$(md5sum < "$1" | cut -d' ' -f1)" = "$(original_md5)" ]; }
# mv statt Ueberschreiben: das laufende Kodi behaelt seine Datei
put_starter() {
    tr -d '\r' < "$HERE/kodi-start.sh" > $LIB/kodi.bin.tmp
    chmod 755 $LIB/kodi.bin.tmp
    mv -f $LIB/kodi.bin.tmp $LIB/kodi.bin
}

case "${1:-}" in
install)
    new=$2
    # OSMCs Original als kodi.bin.osmc sichern; es muss zur Pruefsumme des Pakets passen
    if ! is_original $LIB/kodi.bin.osmc; then
        is_original $LIB/kodi.bin || { echo "kein OSMC-Original" >&2; exit 3; }
        cp -a $LIB/kodi.bin $LIB/kodi.bin.osmc.tmp
        mv -f $LIB/kodi.bin.osmc.tmp $LIB/kodi.bin.osmc
    fi
    install -d -o osmc -g osmc $STATE
    install -m 755 "$new" $LIB/kodi.bin.glas.tmp
    mv -f $LIB/kodi.bin.glas.tmp $LIB/kodi.bin.glas
    put_starter
    printf '%s\n' "$3" > $STATE/build
    echo 0 > $STATE/starts
    rm -f $STATE/off
    chown osmc:osmc $STATE/build $STATE/starts
    apt-mark hold $PKG > /dev/null
    ;;
starter)
    if [ -x $LIB/kodi.bin.glas ]; then put_starter; fi
    ;;
remove)
    if ! is_original $LIB/kodi.bin.osmc; then
        is_original $LIB/kodi.bin && { rm -rf $STATE; apt-mark unhold $PKG > /dev/null; exit 0; }
        echo "kein OSMC-Original" >&2
        exit 3
    fi
    cp -a $LIB/kodi.bin.osmc $LIB/kodi.bin.tmp
    mv -f $LIB/kodi.bin.tmp $LIB/kodi.bin
    rm -f $LIB/kodi.bin.glas $LIB/kodi.bin.osmc
    rm -rf $STATE
    apt-mark unhold $PKG > /dev/null
    ;;
restart)
    systemctl --no-block restart mediacenter
    ;;
*)
    echo "Aufruf: $0 install <kodi.bin> <Kennung> | remove | restart" >&2
    exit 2
    ;;
esac
