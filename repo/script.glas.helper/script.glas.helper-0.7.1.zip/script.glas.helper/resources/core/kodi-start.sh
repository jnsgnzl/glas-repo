#!/bin/sh
# Glas-Kern-Starter: von script.glas.helper (core.py, glas-core.sh) anstelle von OSMCs kodi.bin eingesetzt.
# Startet den eigenen Kodi-Build (kodi.bin.glas). Endet er dreimal hintereinander in der ersten Minute (Absturz beim
# Start, fehlende Bibliothek), startet ab dann OSMCs Kodi (kodi.bin.osmc) und der Glas Helper meldet das.
# Ob der vorige Lauf gesund war, zeigt dessen Log (Kodi benennt es erst nach diesem Start um): es beginnt nach dem
# vorigen Start (started; sonst ist es ein altes Log, weil der Build gar nicht bis zum Log kam), traegt die
# Build-Markierung und reicht ueber mindestens 60 s. Entfernen: Glas-Einstellungen > Live-Glas-Kern > Entfernen.
LIB=/usr/lib/kodi
STATE=/var/lib/glas-core
LOG=/home/osmc/.kodi/temp/kodi.log
STAMP='^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}'

if [ -x $LIB/kodi.bin.glas ] && [ ! -e $STATE/off ]; then
    n=$(cat $STATE/starts 2>/dev/null || echo 0)
    if [ "$n" -gt 0 ] && [ -f $LOG ] && grep -q 'Glas: eigener Kodi-Build' $LOG; then
        since=$(cat $STATE/started 2>/dev/null || echo 0)
        first=$(date -d "$(grep -m 1 -oE "$STAMP" $LOG)" +%s 2>/dev/null || echo 0)
        last=$(date -d "$(grep -oE "$STAMP" $LOG | tail -n 1)" +%s 2>/dev/null || echo 0)
        if [ "$first" -ge $((since - 2)) ] && [ $((last - first)) -ge 60 ]; then
            n=0
        fi
    fi
    if [ "$n" -lt 3 ]; then
        echo $((n + 1)) > $STATE/starts
        date +%s > $STATE/started
        exec $LIB/kodi.bin.glas "$@"
    fi
    date '+%F %T' > $STATE/off
fi
exec $LIB/kodi.bin.osmc "$@"
