"""Glas Helper: was am AV-Receiver ankommt (Denon/Marantz mit HEOS, z. B. Marantz SR6015).

Ersetzt den Blick per INFO-Taste auf das Receiver-Display: eingehendes Tonformat (Dolby Atmos, TrueHD, DTS:X, PCM ...),
aktiver Klangmodus und Abtastrate, im Kontrollzentrum (Audio-Untermenue, audio.py) und als Zeile im Info-Paneel des
Players (Custom_1123). Nur lesend: der Receiver wird nicht eingeschaltet und nichts wird umgestellt.

Schnittstelle (HTTP, Port 8080, ohne Anmeldung; Denon/Marantz ab etwa 2016, "AppCommand"):
  GET  /goform/Deviceinfo.xml                         Modellname (ModelName)
  GET  /goform/formMainZone_MainZoneXmlStatusLite.xml Hauptzone an/aus (Power: ON | STANDBY | OFF)
  POST /goform/AppCommand0300.xml  GetAudioInfo        inputmode, output, signal, sound, fs
Aufbau nach der quelloffenen Bibliothek DenonMarantzAvrNet (conebo-com); an einem SR6015 gemessen: Modell und
Standby (24.10.2026), Werte bei laufender Wiedergabe noch ungeprueft.

Receiver finden: UPnP-Suche (SSDP) nach "Denon-Heos", dann Deviceinfo.xml. Ergebnis in Skin.String(glas_avr_host) und
Skin.String(glas_avr_model); ein von Hand gesetzter Host bleibt. Werte fuer den Skin als Window(Home)-Properties:
glas.avr.model, glas.avr.power (on|standby), glas.avr.signal, glas.avr.sound, glas.avr.fs, glas.avr.line (fertige Zeile).
"""
import socket
import threading
import time
import urllib.request
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui

PORT = 8080
TIMEOUT = 2.0
POLL = 5.0              # Sekunden zwischen zwei Abfragen waehrend der Wiedergabe
HOME = xbmcgui.Window(10000)
AUDIO_INFO = ('<?xml version="1.0" encoding="utf-8"?><tx><cmd id="3"><name>GetAudioInfo</name><list>'
              '<param name="inputmode"/><param name="output"/><param name="signal"/><param name="sound"/>'
              '<param name="fs"/></list></cmd></tx>')
# Schreibweise wie auf dem Receiver-Display, aber nicht in Grossbuchstaben (Klangmodus kommt als "DOLBY ATMOS")
KEEP_UPPER = {'DTS', 'DTS:X', 'PCM', 'HD', 'MA', 'MSTR', 'IMAX', 'DSD', 'AURO', 'AURO-3D', 'EX', 'ES', 'LPCM', 'PL', 'II',
              'IIX', 'IIZ', 'X', 'CH', 'DSUR', 'NEO:6', 'NEO:X', 'AAC', 'MPEG'}


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.glas.helper] ' + msg, level)


def loc(string_id):
    return xbmc.getInfoLabel('$LOCALIZE[%d]' % string_id)


def host():
    return xbmc.getInfoLabel('Skin.String(glas_avr_host)')


def http(path, data=None, address=None):
    url = 'http://%s:%d%s' % (address or host(), PORT, path)
    request = urllib.request.Request(url, data=data.encode() if data else None,
                                     headers={'Content-Type': 'text/xml'} if data else {})
    with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
        return response.read()


def nice(text):
    words = (text or '').strip().split()
    return ' '.join(w if w.upper() in KEEP_UPPER or any(c.isdigit() for c in w) else w.capitalize() for w in words)


def model_of(address):
    try:
        root = ET.fromstring(http('/goform/Deviceinfo.xml', address=address))
    except Exception:
        return ''
    return (root.findtext('ModelName') or '').strip()


def discover():
    """Receiver im Heimnetz finden (einmal beim Start des Dienstes, nur ohne gesetzten Host)."""
    if host():
        return
    msg = ('M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: "ssdp:discover"\r\nMX: 2\r\n'
           'ST: urn:schemas-upnp-org:device:MediaRenderer:1\r\n\r\n').encode()
    found = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
        s.settimeout(0.5)
        s.sendto(msg, ('239.255.255.250', 1900))
        end = time.monotonic() + 3
        while time.monotonic() < end:
            try:
                data, addr = s.recvfrom(4096)
            except socket.timeout:
                continue
            if b'Denon-Heos' in data and addr[0] not in found:
                found.append(addr[0])
        s.close()
    except OSError as e:
        log('Receiver-Suche: %s' % e, xbmc.LOGDEBUG)
    for address in found:
        model = model_of(address)
        if model:
            xbmc.executebuiltin('Skin.SetString(glas_avr_host,%s)' % address)
            xbmc.executebuiltin('Skin.SetString(glas_avr_model,%s)' % model)
            log('Receiver gefunden: %s (%s)' % (model, address))
            return


def status():
    """{'power': 'on'|'standby', 'signal', 'sound', 'fs', 'inputmode', 'output'} oder None (nicht erreichbar)."""
    if not host():
        return None
    try:
        zone = ET.fromstring(http('/goform/formMainZone_MainZoneXmlStatusLite.xml'))
        power = (zone.findtext('Power/value') or '').strip().upper()
        result = {'power': 'on' if power == 'ON' else 'standby'}
        if result['power'] == 'on':
            info = ET.fromstring(http('/goform/AppCommand0300.xml', AUDIO_INFO))
            for param in info.iter('param'):
                result[param.get('name', '')] = (param.text or '').strip()
        return result
    except Exception as e:
        log('Receiver %s: %s' % (host(), e), xbmc.LOGDEBUG)
        return None


def describe(info):
    """(Titel, Zeile) fuer Menue und Info-Paneel, z. B. ('SR6015', 'Dolby Atmos · Dolby Atmos · 48 kHz')."""
    model = xbmc.getInfoLabel('Skin.String(glas_avr_model)') or 'Receiver'
    if info is None:
        return model, ''
    if info.get('power') != 'on':
        return model, loc(31463)
    signal = nice(info.get('signal'))
    sound = nice(info.get('sound'))
    fs = (info.get('fs') or '').replace('kHz', ' kHz').replace('  ', ' ').strip()
    parts = [signal or loc(31464)]
    if sound and sound.lower() != signal.lower():
        parts.append(sound)
    if fs:
        parts.append(fs)
    return model, ' · '.join(parts)


def publish(info):
    model, line = describe(info)
    values = {'glas.avr.model': model if info is not None else '', 'glas.avr.line': line,
              'glas.avr.power': (info or {}).get('power', ''), 'glas.avr.signal': nice((info or {}).get('signal')),
              'glas.avr.sound': nice((info or {}).get('sound')), 'glas.avr.fs': (info or {}).get('fs', '')}
    for key, value in values.items():
        if HOME.getProperty(key) != value:
            HOME.setProperty(key, value)


def clear():
    for key in ('glas.avr.model', 'glas.avr.line', 'glas.avr.power', 'glas.avr.signal', 'glas.avr.sound', 'glas.avr.fs'):
        HOME.clearProperty(key)


class Poller:
    """Dienst: waehrend einer Wiedergabe alle POLL Sekunden abfragen (eigener Faden, blockiert den Dienst nicht);
    nach dem Ende die Werte leeren."""

    def __init__(self):
        self.next = 0.0
        self.busy = False
        self.active = False
        threading.Thread(target=discover, daemon=True).start()

    def tick(self):
        playing = xbmc.getCondVisibility('Player.HasMedia')
        if not playing:
            if self.active:
                self.active = False
                clear()
            return
        now = time.monotonic()
        if self.busy or now < self.next or not host():
            return
        self.active = True
        self.busy = True
        self.next = now + POLL

        def run():
            try:
                publish(status())
            finally:
                self.busy = False

        threading.Thread(target=run, daemon=True).start()
