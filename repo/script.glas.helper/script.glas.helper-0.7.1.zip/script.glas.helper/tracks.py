"""Spurmenues im Player (Fenster 1124 des Skins Glas), wie tvOS 26: je Button ein eigenes Menue "Audio" bzw.
"Untertitel" direkt ueber dem Button.

plugin://script.glas.helper/?action=tracks&focus=audio|subtitle
    Liest die Spuren des laufenden Videos (Player.GetProperties) und legt sie als Eigenschaften von
    Window(Home) ab, dann oeffnet es das Menue des Buttons (focus). Ein Plugin-Listing waere je Pfad gecacht
    und braeuchte zwei Aufrufe; Eigenschaften sind in einem Lauf fertig, das Menue oeffnet vollstaendig.
      glas_ta_count / glas_ts_count             Zahl der Audio- bzw. Untertitelspuren (im Menue hoechstens MAX_*)
      glas_ta_<n>_label, _index, _cur           Zeile n (1-basiert): Text, Kodi-Index, "true" bei der aktiven Spur
      glas_ts_<n>_label, _index, _cur           dasselbe fuer Untertitel
      glas_ts_off                               "true", wenn Untertitel aus sind
      glas_ts_last                              Control-ID der letzten Untertitelzeile (Ziel von "Versatz" nach oben)
      glas_tracks_mode                          "audio" oder "subtitle": welches Menue das Fenster zeigt
      glas_tracks_focus                         Control-ID, die beim Oeffnen den Fokus bekommt (aktive Zeile)
plugin://script.glas.helper/?action=settrack&type=audio|subtitle&index=<n>|off
    Spur waehlen (Player.SetAudioStream / Player.SetSubtitle inkl. Ein/Aus).

Zeilen im Skin (Fenster 1124): Audio = 2101.., "Weitere Optionen" im Audiomenue = 2311, Untertitel = 2201..,
"Aus" = 2200 (siehe tools/dev/gen_trackmenu.py).
"""
import json

import xbmc
import xbmcgui

MAX_AUDIO = 10
MAX_SUBS = 24
AUDIO_BASE = 2100
SUB_BASE = 2200
AUDIO_MORE = 2311
HOME = xbmcgui.Window(10000)

# Sprachnamen wie in Apples Menue in der Sprache der Oberflaeche (Kodi kennt nur englische Namen)
NAMES_DE = {
    'deu': 'Deutsch', 'ger': 'Deutsch', 'gsw': 'Schweizerdeutsch', 'eng': 'Englisch', 'fra': 'Französisch',
    'fre': 'Französisch', 'spa': 'Spanisch', 'ita': 'Italienisch', 'nld': 'Niederländisch', 'dut': 'Niederländisch',
    'por': 'Portugiesisch', 'pol': 'Polnisch', 'tur': 'Türkisch', 'dan': 'Dänisch', 'swe': 'Schwedisch',
    'nor': 'Norwegisch', 'nob': 'Norwegisch', 'nno': 'Norwegisch', 'fin': 'Finnisch', 'ces': 'Tschechisch',
    'cze': 'Tschechisch', 'slk': 'Slowakisch', 'slo': 'Slowakisch', 'hun': 'Ungarisch', 'jpn': 'Japanisch',
    'kor': 'Koreanisch', 'zho': 'Chinesisch', 'chi': 'Chinesisch', 'rus': 'Russisch', 'ukr': 'Ukrainisch',
    'ell': 'Griechisch', 'gre': 'Griechisch', 'heb': 'Hebräisch', 'ara': 'Arabisch', 'hin': 'Hindi',
    'tha': 'Thailändisch', 'vie': 'Vietnamesisch', 'ind': 'Indonesisch', 'msa': 'Malaiisch', 'may': 'Malaiisch',
    'ron': 'Rumänisch', 'rum': 'Rumänisch', 'bul': 'Bulgarisch', 'hrv': 'Kroatisch', 'srp': 'Serbisch',
    'slv': 'Slowenisch', 'est': 'Estnisch', 'lav': 'Lettisch', 'lit': 'Litauisch', 'isl': 'Isländisch',
    'ice': 'Isländisch', 'cat': 'Katalanisch', 'eus': 'Baskisch', 'baq': 'Baskisch', 'glg': 'Galicisch',
    'fil': 'Filipino', 'tam': 'Tamil', 'tel': 'Telugu', 'lat': 'Latein',
}
CODECS = {
    'truehd': 'Dolby TrueHD', 'eac3': 'Dolby Digital Plus', 'ac3': 'Dolby Digital', 'dtshd_ma': 'DTS-HD MA',
    'dtshd_ma_x': 'DTS:X', 'dtshd_ma_x_imax': 'DTS:X', 'dtshd_hra': 'DTS-HD HRA', 'dca': 'DTS', 'dts': 'DTS',
    'aac': 'AAC', 'aac_latm': 'AAC', 'flac': 'FLAC', 'mp3': 'MP3', 'mp2': 'MP2', 'opus': 'Opus', 'vorbis': 'Vorbis',
    'alac': 'ALAC',
}
CHANNELS = {1: 'Mono', 2: 'Stereo', 3: '2.1', 6: '5.1', 7: '6.1', 8: '7.1'}


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def video_player():
    for player in rpc('Player.GetActivePlayers') or []:
        if player.get('type') == 'video':
            return player['playerid']
    return None


def localize(string_id):
    return xbmc.getLocalizedString(string_id)


def language_name(code):
    code = (code or '').strip().lower()
    if not code or code in ('und', 'unk', 'mis', 'zxx'):
        return localize(31359)
    if xbmc.getLanguage(xbmc.ISO_639_1) == 'de':
        if code in NAMES_DE:
            return NAMES_DE[code]
        three = xbmc.convertLanguage(code, xbmc.ISO_639_2)
        if three in NAMES_DE:
            return NAMES_DE[three]
    name = xbmc.convertLanguage(code, xbmc.ENGLISH_NAME)
    return name or code


def codec_name(codec, name):
    codec = (codec or '').lower()
    lower = (name or '').lower()
    if codec == 'truehd' and 'atmos' in lower:
        return 'Dolby Atmos'
    if codec == 'eac3' and 'atmos' in lower:
        return 'Dolby Digital Plus Atmos'
    if codec.startswith('dtshd_ma') and ('dts:x' in lower or 'dts-x' in lower):
        return 'DTS:X'
    if codec.startswith('pcm'):
        return 'PCM'
    return CODECS.get(codec, codec.upper())


def is_commentary(name):
    lower = (name or '').lower()
    return 'comment' in lower or 'kommentar' in lower


def audio_label(stream):
    parts = [language_name(stream.get('language'))]
    codec = codec_name(stream.get('codec'), stream.get('name'))
    if codec:
        parts.append(codec)
    channels = stream.get('channels') or 0
    if channels:
        parts.append(CHANNELS.get(channels, '%d Kanäle' % channels))
    if is_commentary(stream.get('name')):
        parts.append(localize(31356))
    if stream.get('isimpaired'):
        parts.append('AD')
    return '  ·  '.join(parts)


def subtitle_label(stream):
    parts = [language_name(stream.get('language'))]
    if stream.get('isforced'):
        parts.append(localize(31357))
    if stream.get('isimpaired'):
        parts.append('SDH')
    if is_commentary(stream.get('name')):
        parts.append(localize(31356))
    return '  ·  '.join(parts)


def disambiguate(labels, streams):
    """Gleiche Texte (z. B. zwei deutsche DTS-Spuren) um den Spurnamen bzw. die Nummer ergaenzen."""
    result = list(labels)
    for i, label in enumerate(labels):
        same = [j for j, other in enumerate(labels) if other == label]
        if len(same) > 1:
            name = (streams[i].get('name') or '').strip()
            if name and all((streams[j].get('name') or '').strip() != name for j in same if j != i):
                result[i] = '%s  ·  %s' % (label, name)
            else:
                result[i] = '%s  ·  %d' % (label, same.index(i) + 1)
    return result


def publish(prefix, labels, streams, current_index, limit):
    count = min(len(streams), limit)
    HOME.setProperty('%s_count' % prefix, str(count))
    for n in range(1, limit + 1):
        if n <= count:
            stream = streams[n - 1]
            HOME.setProperty('%s_%d_label' % (prefix, n), labels[n - 1])
            HOME.setProperty('%s_%d_index' % (prefix, n), str(stream.get('index', n - 1)))
            HOME.setProperty('%s_%d_cur' % (prefix, n), 'true' if stream.get('index') == current_index else '')
        else:
            for key in ('label', 'index', 'cur'):
                HOME.clearProperty('%s_%d_%s' % (prefix, n, key))


def open_menu(focus):
    player = video_player()
    if player is None:
        return
    props = rpc('Player.GetProperties', playerid=player,
                properties=['audiostreams', 'currentaudiostream', 'subtitles', 'currentsubtitle', 'subtitleenabled'])
    audio = props.get('audiostreams') or []
    subs = props.get('subtitles') or []
    cur_audio = (props.get('currentaudiostream') or {}).get('index')
    subs_on = bool(props.get('subtitleenabled')) and bool(subs)
    cur_sub = (props.get('currentsubtitle') or {}).get('index') if subs_on else None

    publish('glas_ta', disambiguate([audio_label(s) for s in audio], audio), audio, cur_audio, MAX_AUDIO)
    publish('glas_ts', disambiguate([subtitle_label(s) for s in subs], subs), subs, cur_sub, MAX_SUBS)
    HOME.setProperty('glas_ts_off', '' if subs_on else 'true')
    # letzte Untertitelzeile ("Aus" ohne Spuren): Ziel von "Versatz" nach oben (eigene Zeile in einer Gruppe)
    HOME.setProperty('glas_ts_last', str(SUB_BASE + min(len(subs), MAX_SUBS)))

    mode = 'subtitle' if focus == 'subtitle' else 'audio'
    HOME.setProperty('glas_tracks_mode', mode)
    target = None
    if mode == 'subtitle':
        target = SUB_BASE
        for n, stream in enumerate(subs[:MAX_SUBS], 1):
            if subs_on and stream.get('index') == cur_sub:
                target = SUB_BASE + n
    else:
        for n, stream in enumerate(audio[:MAX_AUDIO], 1):
            if stream.get('index') == cur_audio:
                target = AUDIO_BASE + n
        if target is None:
            target = AUDIO_BASE + 1 if audio else AUDIO_MORE
    HOME.setProperty('glas_tracks_focus', str(target))
    # aus dem Info-Paneel: das Menue steht ueber seinem Knopf in der Buttonreihe - Paneel zu, Buttonreihe auf
    xbmc.executebuiltin('Dialog.Close(1123,true)')
    if not xbmc.getCondVisibility('Window.IsVisible(videoosd)'):
        xbmc.executebuiltin('ActivateWindow(videoosd)')
        # Fokus auf den Knopf des Menues: er wird heller wie beim Oeffnen aus der Buttonreihe
        xbmc.executebuiltin('SetFocus(%d)' % (70046 if mode == 'subtitle' else 70049))
    xbmc.executebuiltin('ActivateWindow(1124)')


def run(action, query):
    """Einstieg aus default.py (Aktionen tracks und settrack)."""
    if action == 'tracks':
        open_menu(query.get('focus', 'audio'))
    else:
        set_track(query.get('type', ''), query.get('index', ''))


def set_track(kind, index):
    player = video_player()
    if player is None:
        return
    if kind == 'audio' and index.isdigit():
        rpc('Player.SetAudioStream', playerid=player, stream=int(index))
    elif kind == 'subtitle' and index == 'off':
        rpc('Player.SetSubtitle', playerid=player, subtitle='off')
    elif kind == 'subtitle' and index.isdigit():
        rpc('Player.SetSubtitle', playerid=player, subtitle=int(index), enable=True)
