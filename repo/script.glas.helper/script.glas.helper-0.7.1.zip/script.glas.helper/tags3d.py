"""Glas Helper (Dienst): Kodi-Schlagwort "3D" fuer 3D-Filme, Grundlage des Eintrags "3D" in der Mediathek.

Kodis intelligente Listen kennen keinen 3D-Filter (Aufloesung und HDR ja, den Stereomodus nicht). Der Dienst setzt
deshalb das Schlagwort 3D (VideoLibrary.SetMovieDetails, bleibt in der Datenbank, geht auch ohne eigenen Kodi-Build),
die Mediathek filtert danach (Feld tag). Ein Film gilt als 3D, wenn
  - Kodis Datenstrom-Details einen Stereomodus nennen (nicht leer/off/mono). Bei Blu-ray-ISOs traegt Kodi ihn erst nach
    dem ersten Abspielen ein (MVC); daher auch nach jeder Wiedergabe abgleichen.
  - oder der Dateiname ein 3D-Kennzeichen hinter der Aufloesung traegt ("1080p 3D.iso", "1080p DTS 3D HTAB.mkv") bzw.
    als eigenes Wortstueck ("-3D-"). "3D" nur im Titel ("Saw 3D - Vollendung (2010) 1080p.iso") zaehlt nicht: das
    sagt nichts ueber die Fassung.
Nur hinzufuegen, nie entfernen (ein von Hand gesetztes Schlagwort bleibt). Laeuft beim Start (verzoegert), nach jedem
Bibliotheks-Scan und nach jeder Wiedergabe, in einem eigenen Faden.
"""
import json
import re
import threading

import xbmc

TAG = '3D'
MARKER = re.compile(r'(?i)(?:\b(?:2160|1080|720)[pi]\b.*[ ._-]3D(?:[ ._-]|$))|(?:[._-]3D[._-])')
_lock = threading.Lock()
_timer = None


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.glas.helper] ' + msg, level)


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def is_3d(movie):
    video = (movie.get('streamdetails') or {}).get('video') or [{}]
    mode = (video[0].get('stereomode') or '').lower()
    if mode and mode not in ('off', 'mono'):
        return True
    name = re.split(r'[/\\]', movie.get('file') or '')[-1]
    return bool(MARKER.search(name.rsplit('.', 1)[0] + '.'))


def sync():
    with _lock:
        movies = rpc('VideoLibrary.GetMovies', properties=['file', 'streamdetails', 'tag']).get('movies', [])
        added = 0
        for movie in movies:
            tags = movie.get('tag') or []
            if TAG in tags or not is_3d(movie):
                continue
            rpc('VideoLibrary.SetMovieDetails', movieid=movie['movieid'], tag=tags + [TAG])
            added += 1
        if added:
            log('3D-Schlagwort fuer %d Filme gesetzt' % added)


def schedule(delay=8.0):
    """Abgleich gebuendelt nach kurzer Pause (Kodi schreibt die Datenstrom-Details erst nach dem Stopp)."""
    global _timer
    if _timer:
        _timer.cancel()
    _timer = threading.Timer(delay, _run)
    _timer.daemon = True
    _timer.start()


def _run():
    try:
        sync()
    except Exception as e:  # nur Komfort
        log('3D-Schlagwort: %s' % e, xbmc.LOGWARNING)
