"""Glas Helper: Audio-Untermenue des Kontrollzentrums (wie Apples "Audio Routing").

Zeilen: oben, was am AV-Receiver ankommt (avr.py, nur mit gefundenem Receiver) und was Kodi gerade sendet (nur bei
Wiedergabe); dann Kodis Audio-Ausgabegeraete (audiooutput.audiodevice, das aktive mit Haken), zuletzt Passthrough Ein/Aus.
plugin://script.glas.helper/?action=audio&avr=refresh     Receiver neu abfragen (Liste neu laden)
plugin://script.glas.helper/?action=audio&device=<wert>   Ausgabegeraet setzen
plugin://script.glas.helper/?action=audio&passthrough=toggle  Passthrough umschalten
"""
import json
import re
from urllib.parse import urlencode

import xbmc

from power import BASE, bump, item, loc

DEVICE = 'audiooutput.audiodevice'
PASSTHROUGH = 'audiooutput.passthrough'


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def audio_settings():
    result = rpc('Settings.GetSettings', level='expert', filter={'section': 'system', 'category': 'audio'})
    return {s.get('id'): s for s in result.get('settings', [])}


def device_label(label):
    """'WASAPI: HDMI - 2 - P24h-2L (AMD High Definition Audio Device), WASAPI: 2 - ...' -> Titel, Unterzeile."""
    first = label.split(', ')[0]
    driver, _, name = first.partition(': ')
    if not name:
        driver, name = '', first
    extra = ''
    match = re.match(r'^(.*?)\s*\((.+)\)\s*$', name)
    if match:
        name, extra = match.group(1), match.group(2)
    if name.lower() == 'default':
        name = loc(31432)
    # Zusatz in Klammern nur, wenn er kurz ist (sonst gekuerzt und ohne Nutzen)
    caption = ' · '.join(part for part in (driver, extra if len(extra) <= 18 else '') if part)
    return name or first, caption


# Kodis Codec-Namen (Player.GetProperties currentaudiostream) wie auf dem Receiver-Display
CODECS = {'truehd': 'Dolby TrueHD', 'eac3': 'Dolby Digital Plus', 'ac3': 'Dolby Digital', 'dtshd_ma': 'DTS-HD MA',
          'dtshd_hra': 'DTS-HD HRA', 'dca': 'DTS', 'dts': 'DTS', 'flac': 'FLAC', 'aac': 'AAC', 'opus': 'Opus', 'mp3': 'MP3'}


def kodi_stream():
    """Was Kodi gerade sendet, z. B. 'Dolby TrueHD Atmos · 7.1' (leer ohne Wiedergabe)."""
    players = [p for p in rpc('Player.GetActivePlayers') or [] if p.get('type') in ('video', 'audio')]
    if not players:
        return ''
    props = rpc('Player.GetProperties', playerid=players[0]['playerid'], properties=['currentaudiostream'])
    stream = props.get('currentaudiostream') or {}
    codec = stream.get('codec', '')
    name = 'PCM' if codec.startswith('pcm') else CODECS.get(codec, codec.upper())
    if 'atmos' in (stream.get('name') or '').lower():
        name += ' Atmos'
    channels = stream.get('channels') or 0
    layout = {1: '1.0', 2: '2.0', 6: '5.1', 8: '7.1'}.get(channels, str(channels) if channels else '')
    return ' · '.join(part for part in (name, layout) if part)


def list_receiver():
    import avr
    rows = []
    if avr.host():
        model, line = avr.describe(avr.status())
        rows.append(item(model, BASE + '?action=audio&avr=refresh', line or '–', 'glas/icon-waveform.png'))
    sending = kodi_stream()
    if sending:
        rows.append(item(loc(31465), BASE + '?action=audio&avr=refresh', sending, 'glas/icon-tv.png'))
    return rows


def list_audio():
    settings = audio_settings()
    items = list_receiver()
    device = settings.get(DEVICE, {})
    current = device.get('value', '')
    for option in device.get('options', []):
        title, caption = device_label(option.get('label', ''))
        icon = 'glas/icon-tv.png' if 'hdmi' in option.get('label', '').lower() else 'glas/icon-speaker.png'
        path = BASE + '?' + urlencode({'action': 'audio', 'device': option.get('value', '')})
        items.append(item(title, path, caption, icon, option.get('value') == current))
    passthrough = settings.get(PASSTHROUGH)
    if passthrough is not None:
        items.append(item(loc(31427), BASE + '?action=audio&passthrough=toggle', loc(31430), 'glas/icon-waveform.png',
                          bool(passthrough.get('value'))))
    return items


def run(query):
    if 'device' in query:
        rpc('Settings.SetSettingValue', setting=DEVICE, value=query['device'])
    elif query.get('passthrough') == 'toggle':
        value = rpc('Settings.GetSettingValue', setting=PASSTHROUGH).get('value')
        rpc('Settings.SetSettingValue', setting=PASSTHROUGH, value=not value)
    bump()
