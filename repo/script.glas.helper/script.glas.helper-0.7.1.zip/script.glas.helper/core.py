"""Glas Helper: Live-Glas-Kern (eigener Kodi-Build, tools/kodi-build) auf einer Vero V installieren, aktualisieren und
entfernen.

plugin://script.glas.helper/?action=core   Auswahl Installieren / Aktualisieren / Entfernen (Skin-Einstellung 724)

Welche Builds es gibt, steht in MANIFEST (oeffentliches Repository jnsgnzl/glas-repo, core/manifest.json). Ein Build
passt nur zu genau einer Version von OSMCs Kodi-Paket (er nutzt dessen Bibliotheken). Installiert wird so (als root
ueber sudo -n, resources/core/glas-core.sh):
  /usr/lib/kodi/kodi.bin.osmc   OSMCs Original (passt zur Pruefsumme des Pakets, sonst bricht die Installation ab)
  /usr/lib/kodi/kodi.bin.glas   der eigene Build
  /usr/lib/kodi/kodi.bin        Starter (resources/core/kodi-start.sh): startet kodi.bin.glas; bricht der Build dreimal
                                hintereinander in der ersten Minute ab, ab dann OSMCs Kodi (Notfall-Rueckweg)
  /var/lib/glas-core/           build (Kennung), starts (Zaehler), started (letzter Start), off (Zeitpunkt des
                                Rueckwegs); gehoert osmc
und OSMCs Kodi-Paket wird gesperrt (apt-mark hold), damit ein OSMC-Update den Build nicht ueberschreibt.
Entfernen stellt das Original her und hebt die Sperre auf.

Der Dienst ruft check() einmal nach dem Start: setzt Window(Home).Property(glas.corecapable) (nur Vero V) und
glas.corestate (Zustand fuer die Skin-Einstellung), meldet einen neuen Build und einen erfolgten Notfall-Rueckweg.
"""
import hashlib
import json
import lzma
import os
import subprocess
import threading
import time
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

MANIFEST = 'https://jnsgnzl.github.io/glas-repo/core/manifest.json'
DEVICE = 'vero5'                    # Vero V (osmcdev= in /proc/cmdline)
PACKAGE = 'vero5-mediacenter-osmc'  # OSMCs Kodi-Paket
LIB = '/usr/lib/kodi'
STATE = '/var/lib/glas-core'
HOME = xbmcgui.Window(10000)
HEADING = 31552

# Skin-Strings (skin.glas, strings.po)
S_NOT_INSTALLED, S_INSTALLED, S_UPDATE, S_FALLBACK_STATE = 31554, 31555, 31556, 31557
S_ASK_INSTALL, S_INSTALL, S_REMOVE, S_UPDATE_TO = 31558, 31559, 31560, 31561
S_NO_BUILD, S_FAILED, S_NOT_ORIGINAL, S_FALLBACK = 31562, 31563, 31564, 31565
S_AVAILABLE, S_RESTART, S_ASK_REMOVE, S_LOADING, S_OFFLINE = 31566, 31567, 31568, 31570, 31571


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.glas.helper] core: %s' % msg, level)


def loc(string_id):
    return xbmc.getInfoLabel('$LOCALIZE[%d]' % string_id)


def device():
    try:
        with open('/proc/cmdline') as f:
            return 'vero5' if 'osmcdev=vero5' in f.read().split() else ''
    except OSError:
        return ''


def osmc_version():
    try:
        return subprocess.run(['dpkg-query', '-W', '-f=${Version}', PACKAGE], capture_output=True, text=True,
                              timeout=10).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return ''


def read(path):
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError:
        return ''


def state():
    """installed: Starter und Build liegen da; build: Kennung; off: Zeitpunkt des Notfall-Rueckwegs."""
    return {'installed': os.path.exists(os.path.join(LIB, 'kodi.bin.glas')),
            'build': read(os.path.join(STATE, 'build')),
            'off': read(os.path.join(STATE, 'off'))}


def fetch_manifest():
    try:
        with urllib.request.urlopen(MANIFEST, timeout=15) as r:
            return json.loads(r.read().decode('utf-8'))
    except Exception as e:  # kein Netz, Seite nicht erreichbar: nur Hinweis, nichts aendern
        log('Manifest nicht lesbar: %s' % e, xbmc.LOGWARNING)
        return None


def best_build(manifest, version):
    """Neuester Build fuer dieses Geraet und genau diese Version von OSMCs Kodi."""
    builds = [b for b in (manifest or {}).get('builds', [])
              if b.get('device') == DEVICE and b.get('osmc') == version]
    return max(builds, key=lambda b: b.get('id', '')) if builds else None


def data_path(name):
    folder = xbmcvfs.translatePath('special://profile/addon_data/script.glas.helper/')
    xbmcvfs.mkdirs(folder)
    return os.path.join(folder, name)


def update_state(st, build=None):
    """Text fuer die Skin-Einstellung (label2 von 724)."""
    if st['installed'] and st['off']:
        text = loc(S_FALLBACK_STATE)
    elif st['installed']:
        text = '%s (%s)' % (loc(S_INSTALLED), st['build'])
        if build and build['id'] > st['build']:
            text = loc(S_UPDATE) % build['id']
    else:
        text = loc(S_NOT_INSTALLED)
    HOME.setProperty('glas.corestate', text)


def check():
    """Beim Start des Dienstes (eigener Faden): Zustand anzeigen, neuen Build und Notfall-Rueckweg melden."""
    if device() != DEVICE:
        HOME.clearProperty('glas.corecapable')
        return
    HOME.setProperty('glas.corecapable', '1')
    st = state()
    update_state(st)
    if st['installed'] and read(os.path.join(LIB, 'kodi.bin')) != read(resource('kodi-start.sh')).replace('\r', ''):
        root('starter')  # neuere Fassung des Starters aus einem Helper-Update
    if st['installed'] and st['off'] and read(data_path('core_off_seen')) != st['off']:
        xbmcgui.Dialog().ok(loc(HEADING), loc(S_FALLBACK))
        with open(data_path('core_off_seen'), 'w') as f:
            f.write(st['off'])
    if not st['installed']:
        return
    build = best_build(fetch_manifest(), osmc_version())
    update_state(st, build)
    if build and build['id'] > st['build'] and read(data_path('core_seen')) != build['id']:
        xbmcgui.Dialog().notification(loc(HEADING), loc(S_AVAILABLE) % build['id'], xbmcgui.NOTIFICATION_INFO, 8000)
        with open(data_path('core_seen'), 'w') as f:
            f.write(build['id'])


def schedule(delay):
    timer = threading.Timer(delay, check)
    timer.daemon = True
    timer.start()


def resource(name):
    return os.path.join(xbmcaddon.Addon('script.glas.helper').getAddonInfo('path'), 'resources', 'core', name)


def root(*args):
    """Teil von glas-core.sh als root ausfuehren (OSMC: sudo ohne Passwort fuer osmc)."""
    result = subprocess.run(['sudo', '-n', 'sh', resource('glas-core.sh')] + list(args), capture_output=True,
                            text=True, timeout=120)
    log('glas-core.sh %s -> %d %s' % (' '.join(args), result.returncode, result.stderr.strip()))
    return result.returncode


def download(build):
    """Build laden, entpacken und pruefen; Pfad der fertigen Datei oder None."""
    folder = xbmcvfs.translatePath('special://temp/glas-core/')
    xbmcvfs.mkdirs(folder)
    packed, target = os.path.join(folder, 'kodi.bin.xz'), os.path.join(folder, 'kodi.bin')
    progress = xbmcgui.DialogProgress()
    progress.create(loc(HEADING), loc(S_LOADING) % build['id'])
    try:
        with urllib.request.urlopen(build['url'], timeout=30) as r, open(packed, 'wb') as out:
            total = int(r.headers.get('Content-Length') or build.get('xz_size') or 0)
            done = 0
            while True:
                chunk = r.read(1 << 16)
                if not chunk:
                    break
                out.write(chunk)
                done += len(chunk)
                if total:
                    progress.update(min(99, done * 100 // total))
                if progress.iscanceled():
                    return None
        digest = hashlib.sha256()
        with lzma.open(packed) as src, open(target, 'wb') as out:
            for chunk in iter(lambda: src.read(1 << 20), b''):
                digest.update(chunk)
                out.write(chunk)
        if digest.hexdigest() != build['sha256']:
            log('Pruefsumme falsch: %s' % digest.hexdigest(), xbmc.LOGERROR)
            return None
        return target
    except Exception as e:
        log('Download fehlgeschlagen: %s' % e, xbmc.LOGERROR)
        return None
    finally:
        progress.close()
        if os.path.exists(packed):
            os.remove(packed)


def install(build):
    path = download(build)
    if not path:
        xbmcgui.Dialog().ok(loc(HEADING), loc(S_FAILED))
        return
    code = root('install', path, build['id'])
    os.remove(path)
    if code == 3:
        xbmcgui.Dialog().ok(loc(HEADING), loc(S_NOT_ORIGINAL))
    elif code:
        xbmcgui.Dialog().ok(loc(HEADING), loc(S_FAILED))
    else:
        restart()


def remove():
    if not xbmcgui.Dialog().yesno(loc(HEADING), loc(S_ASK_REMOVE)):
        return
    code = root('remove')
    if code == 3:
        xbmcgui.Dialog().ok(loc(HEADING), loc(S_NOT_ORIGINAL))
    elif code:
        xbmcgui.Dialog().ok(loc(HEADING), loc(S_FAILED))
    else:
        restart()


def restart():
    """Kodi ueber systemd neu starten (laeuft getrennt von Kodi weiter, --no-block)."""
    xbmcgui.Dialog().notification(loc(HEADING), loc(S_RESTART), xbmcgui.NOTIFICATION_INFO, 3000)
    time.sleep(2)
    root('restart')


def run():
    """Skin-Einstellung "Live-Glas-Kern": je nach Zustand installieren, aktualisieren oder entfernen."""
    if device() != DEVICE:
        return
    st = state()
    version = osmc_version()
    manifest = fetch_manifest()
    build = best_build(manifest, version)
    if not st['installed']:
        if manifest is None:
            xbmcgui.Dialog().ok(loc(HEADING), loc(S_OFFLINE))
        elif not build:
            xbmcgui.Dialog().ok(loc(HEADING), loc(S_NO_BUILD) % version)
        elif xbmcgui.Dialog().yesno(loc(HEADING), loc(S_ASK_INSTALL) % (build['id'], version),
                                    yeslabel=loc(S_INSTALL), nolabel=xbmc.getLocalizedString(222)):
            install(build)
        return
    choices, actions = [], []
    if build and (build['id'] > st['build'] or st['off']):
        choices.append(loc(S_UPDATE_TO) % build['id'] if build['id'] > st['build'] else loc(S_INSTALL))
        actions.append(lambda: install(build))
    choices.append(loc(S_REMOVE))
    actions.append(remove)
    pick = xbmcgui.Dialog().select(loc(HEADING), choices)
    if pick >= 0:
        actions[pick]()
    update_state(state(), build)
