"""Glas Helper (Dienst): Stereo-Poster (Side-by-Side) aus den Kodex-Tiefenkarten fuer die 3D-Oberflaeche.

Kodex (Medienverwaltung im Heimnetz) verwahrt zu vielen Filmen eine Tiefenkarte des Covers (PNG 256 x 384, 8 Bit grau,
hell = nah; erzeugt ausserhalb auf einer Grafikeinheit, hier wird nichts nachgerechnet). Daraus rechnet der Dienst je
Film ein Bildpaar: links das Poster fuers linke, rechts fuers rechte Auge, nebeneinander in einer Datei (doppelt so
breit wie das Poster). Der eigene Kodi-Build zeigt solche Bilder mit <texture stereo="sbs"> je Auge getrennt; der Skin
nimmt sie nur, wenn der Build das kann (Window(Home).Property(glas.corestereo), service.core_build) und die Oberflaeche
gerade stereo zeichnet (System.StereoscopicMode > 0), sonst das normale Poster.

Ablauf (eigener Faden, nie im Takt des Dienstes; ohne Kodex im Netz still nichts):
  1. GET {KODEX}/api/media?limit=1000&hasDepthMap=true -> Medien mit Karte (nur GET, keine Anmeldung).
  2. Zuordnung zu Kodis Filmen ueber den Pfad: Kodex' relativePath ist das Ende von Kodis Datei
     (Freigabe der Filme + relativePath); verglichen wird jedes Pfadende, die Freigabe ist egal.
  3. Karte holen (bedingt: If-Modified-Since, Kopie unter stereo/maps/<kodex-id>.png), Kodis Poster aus dem Bildcache
     (sonst ueber den Art-Pfad mit xbmcvfs), Paar rechnen (render_pair), als JPEG ablegen.
  4. Pfad als eigene Art-Sorte "glasstereo" in Kodis Datenbank (VideoLibrary.SetMovieDetails): so fragt der Skin
     ListItem.Art(glasstereo) bzw. Player.Art(glasstereo) ab - "Bild vorhanden" laesst sich in Kodi-Bedingungen sonst
     nicht pruefen (es gibt kein File.Exists, und $INFO in Property-Namen wertet Kodi nicht aus).
Dateien: special://masterprofile/addon_data/script.glas.helper/stereo/<tmdb-id>.jpg (ohne tmdb-ID: movie<DB-ID>.jpg;
zwei Fassungen desselben Films, z. B. 2D und 3D mit je eigener Karte: <tmdb-id>-<DB-ID>.jpg),
im Hauptprofil, damit Profile mit gemeinsamer Bibliothek dieselben Dateien finden. index.json merkt je Datei die
Herkunft (Poster-Datei mit Groesse/Datum, Last-Modified der Karte, Rechenverfahren); neu gerechnet wird nur bei
Aenderung. 3D-Filme (Schlagwort 3D) zuerst, dann alle anderen mit Karte: in einer 3D-Oberflaeche sehen alle Poster 3D aus.
Ausloeser: Start des Dienstes (verzoegert, nach tags3d) und jeder Bibliotheks-Scan (wake.WakeMonitor).
"""
import io
import json
import os
import threading
import time
import unicodedata
import urllib.error
import urllib.request
from urllib.parse import unquote

import xbmc
import xbmcvfs

try:
    from PIL import Image, ImageFilter, ImageOps
except ImportError:  # ohne Pillow keine Stereo-Poster (der Skin zeigt dann die normalen)
    Image = None

# Kodex im Heimnetz, nur wenn eingetragen (Skin.String(glas_kodex_url), z. B. http://<Rechner>:3000): ohne
# Eintrag fragt der Helper bei Testern niemanden im Heimnetz an
KODEX = ''
ART = 'glasstereo'                      # Art-Sorte in Kodis Datenbank -> ListItem.Art(glasstereo)
FOLDER = 'special://masterprofile/addon_data/script.glas.helper/stereo/'
HALF = (480, 720)                       # eine Haelfte (Auge); das Paar ist 960 x 720 und passt so ungeteilt in Kodis
                                        # Bildcache (Vorgabe imageres 720, hoechstens 1280 breit)
CELL = 10                               # Kantenlaenge der Netzzellen fuer Image.MESH in Pixeln

# Verschiebung je Auge als Anteil der Posterbreite fuer Weiss (ganz nah) bzw. Schwarz (ganz fern); Mittelgrau bleibt in
# der Posterebene (wie bei Kodex: d = Wert/255 - 0,5). Kodex' WACKEL_STAERKE 0,045 lenkt ein Bild bei voller Neigung um
# 0,045 x 0,5 = 0,0225 der Breite aus und ist ueber zwoelf Karten gemessen unbedenklich (ab 0,08 = 0,04 je Seite
# Schlieren, ab 0,12 = 0,06 faltet sich die Abbildung). 0,025 je Auge liegt knapp darueber und mit Faktor 1,6 unter den
# Schlieren - jedes Auge fuer sich wird nicht staerker verzogen als ein Kodex-Cover beim Wackeln. Abstand der beiden
# Bilder (Disparitaet) dann bis 0,05 der Breite nach vorn und nach hinten: beim Poster 200 px im Mediathek-Raster
# +-10 px, also etwa so viel wie eine halbe Tiefeneinheit der Oberflaeche (20 px x depth bei 1080p, Includes.xml).
# Nicht ueber 0,04 erhoehen.
EYE_SHIFT = 0.025
SMOOTH = 3                              # Weichzeichnen der Karte in Pixeln (Haelfte 480 breit): weiche Uebergaenge
                                        # statt harter Kanten an Objektgrenzen, weniger Faltung
ALGO = 'mesh-%s-%s-%s-%sx%s' % (EYE_SHIFT, CELL, SMOOTH, HALF[0], HALF[1])  # andere Werte -> alles neu rechnen
TIMEOUT = 6
PAUSE = 0.3                             # Sekunden nach jedem gerechneten Paar (Dienst und Oberflaeche bleiben fluessig)

_lock = threading.Lock()
_timer = None


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.glas.helper] ' + msg, level)


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


# ---------------------------------------------------------------- Bildrechnung (ohne Kodi pruefbar)

def fit(img, size, resample):
    """Wie CSS object-fit: cover - mittig zuschneiden und auf size bringen (Kodex schneidet Cover und Karte so zu)."""
    return ImageOps.fit(img, size, resample, centering=(0.5, 0.5))


def eye(poster, depth, sign):
    """Ein Auge: jede Netzzelle holt ihr Bild aus der waagerecht verschobenen Quelle (rueckwaerts gerechnet wie Kodex:
    keine Loecher, nur leichte Verzerrung). sign +1 = linkes Auge: Nahes wandert nach rechts, im rechten Auge nach
    links (gekreuzte Disparitaet = vor der Posterebene)."""
    w, h = poster.size
    px = depth.load()
    scale = EYE_SHIFT * w / 127.5 * sign
    xs = list(range(0, w, CELL)) + [w]
    ys = list(range(0, h, CELL)) + [h]
    # Quelle je Netzpunkt: x - Verschiebung, auf das Bild begrenzt (an den Raendern wird gestaucht statt schwarz)
    src = [[min(w, max(0, x - (px[min(x, w - 1), min(y, h - 1)] - 127.5) * scale)) for x in xs] for y in ys]
    mesh = []
    for j in range(len(ys) - 1):
        y0, y1 = ys[j], ys[j + 1]
        top, bottom = src[j], src[j + 1]
        for i in range(len(xs) - 1):
            # Ziel-Rechteck -> Quell-Viereck (oben links, unten links, unten rechts, oben rechts)
            mesh.append(((xs[i], y0, xs[i + 1], y1),
                         (top[i], y0, bottom[i], y1, bottom[i + 1], y1, top[i + 1], y0)))
    return poster.transform((w, h), Image.MESH, mesh, Image.BILINEAR)


def render_pair(poster, depthmap, half=HALF):
    """Poster (beliebige Groesse) + Tiefenkarte (hell = nah) -> Side-by-Side-Bild (2 x half[0]) x half[1]."""
    poster = fit(poster.convert('RGB'), half, Image.BICUBIC)
    depth = fit(depthmap.convert('L'), half, Image.BILINEAR)
    if SMOOTH:
        depth = depth.filter(ImageFilter.GaussianBlur(SMOOTH))
    pair = Image.new('RGB', (half[0] * 2, half[1]))
    pair.paste(eye(poster, depth, 1), (0, 0))
    pair.paste(eye(poster, depth, -1), (half[0], 0))
    return pair


# ---------------------------------------------------------------- Kodex und Kodi

def kodex_url():
    return (xbmc.getInfoLabel('Skin.String(glas_kodex_url)') or KODEX).rstrip('/')


def http_get(url, headers=None):
    """GET; liefert (Status, Daten, Kopfzeilen). 304 kommt als Status zurueck, Netzfehler als Ausnahme."""
    request = urllib.request.Request(url, headers=headers or {})
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
            return response.status, response.read(), response.headers
    except urllib.error.HTTPError as e:
        if e.code in (304, 404):
            return e.code, b'', e.headers
        raise


def norm(path):
    return unicodedata.normalize('NFC', path.replace('\\', '/')).lower()


def match(movies, media):
    """Kodex-Medien den Kodi-Filmen zuordnen: relativePath ist ein Pfadende der Kodi-Datei."""
    by_path = {norm(m.get('relativePath') or ''): m for m in media if m.get('relativePath')}
    pairs = []
    for movie in movies:
        parts = norm(movie.get('file') or '').split('/')
        for k in range(1, len(parts)):
            item = by_path.get('/'.join(parts[k:]))
            if item:
                pairs.append((movie, item))
                break
    return pairs


def read_file(path):
    f = xbmcvfs.File(path, 'rb')
    try:
        return bytes(f.readBytes())
    finally:
        f.close()


def file_sig(path):
    st = xbmcvfs.Stat(path)
    return '%d-%d' % (st.st_size(), st.st_mtime())


def poster_source(art):
    """(Pfad, Kennung) des Posters: Kodis Bildcache (lokal, schon verkleinert), sonst das Original."""
    path = unwrap(art)
    textures = rpc('Textures.GetTextures', filter={'field': 'url', 'operator': 'is', 'value': path},
                   properties=['cachedurl']).get('textures') or []
    for texture in textures:
        if texture.get('cachedurl'):
            cached = 'special://thumbnails/' + texture['cachedurl']
            if xbmcvfs.exists(cached):
                return cached, path + '|' + file_sig(cached)
    return path, path + '|' + file_sig(path)


def drop_cached(path):
    """Kodis Bildcache kennt die alte Fassung unter demselben Pfad: entfernen, damit das neue Paar geladen wird. Ueber die
    Art-Sorte geladen steht der Pfad dort als image://-Adresse (special%3a%2f%2f...), daher nach dem Dateinamen suchen."""
    name = path.rsplit('/', 1)[-1]
    for value in ('%2f' + name, '/' + name):
        found = rpc('Textures.GetTextures', filter={'field': 'url', 'operator': 'contains', 'value': value},
                    properties=['url']).get('textures') or []
        for texture in found:
            if unwrap(texture.get('url') or '') == path:
                rpc('Textures.RemoveTexture', textureid=texture['textureid'])


class Store:
    def __init__(self):
        self.folder = xbmcvfs.translatePath(FOLDER)
        os.makedirs(os.path.join(self.folder, 'maps'), exist_ok=True)
        self.index_path = os.path.join(self.folder, 'index.json')
        try:
            with open(self.index_path, encoding='utf-8') as f:
                self.index = json.load(f)
        except (OSError, ValueError):
            self.index = {}

    def save(self):
        tmp = self.index_path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(self.index, f, indent=1, sort_keys=True)
        os.replace(tmp, self.index_path)

    def depthmap(self, base, media_id):
        """Karte bedingt holen; (Bytes, Last-Modified). Kodex sendet die Datei mit Last-Modified, 304 = unveraendert."""
        local = os.path.join(self.folder, 'maps', '%d.png' % media_id)
        stamp_path = local + '.date'
        headers = {}
        if os.path.exists(local) and os.path.exists(stamp_path):
            with open(stamp_path, encoding='utf-8') as f:
                headers['If-Modified-Since'] = f.read().strip()
        status, data, response_headers = http_get('%s/api/media/%d/tiefenkarte' % (base, media_id), headers)
        if status == 304:
            with open(local, 'rb') as f:
                return f.read(), headers['If-Modified-Since']
        if status != 200 or not data:
            return None, None
        stamp = response_headers.get('Last-Modified') or str(len(data))
        with open(local, 'wb') as f:
            f.write(data)
        with open(stamp_path, 'w', encoding='utf-8') as f:
            f.write(stamp)
        return data, stamp


def key_of(movie, shared=()):
    """Dateiname: tmdb-ID; ohne sie oder bei mehreren Fassungen desselben Films (2D und 3D, je eigene Karte) mit DB-ID."""
    tmdb = (movie.get('uniqueid') or {}).get('tmdb')
    if not tmdb:
        return 'movie%d' % movie['movieid']
    return '%s-%d' % (tmdb, movie['movieid']) if str(tmdb) in shared else str(tmdb)


def unwrap(art):
    return unquote(art[len('image://'):].rstrip('/')) if art.startswith('image://') else art


def set_art(movie, value):
    """Nur schreiben, wenn sich etwas aendert (Kodi liefert Art-Pfade als image://...-Adresse zurueck)."""
    if unwrap((movie.get('art') or {}).get(ART) or '') != (value or ''):
        rpc('VideoLibrary.SetMovieDetails', movieid=movie['movieid'], art={ART: value})


def wait_idle(monitor):
    """Nicht waehrend ein Video laeuft (Rechenzeit gehoert der Wiedergabe); False bei Kodi-Ende. Der Bildschirmschoner
    Aerial (screensaver.atv4) spielt ebenfalls Video, zaehlt aber nicht - sonst rechnete die Vero nur, solange jemand sie
    bedient. Sein Video laeuft nach dem Schliessen teils noch weiter (Fenster schon zu), daher auch die Apple-Adresse."""
    while xbmc.getCondVisibility('Player.HasVideo + !Window.IsActive(screensaver-atv4.xml) + '
                                 '!String.Contains(Player.Filenameandpath,apple.com/Videos/)'):
        if monitor.waitForAbort(15):
            return False
    return not monitor.abortRequested()


def sync():
    if Image is None:
        return
    base = kodex_url()
    if not base:
        return
    try:
        status, data, _ = http_get(base + '/api/media?limit=1000&hasDepthMap=true')
        media = json.loads(data.decode('utf-8')).get('items') or [] if status == 200 else None
    except Exception as e:  # Kodex nicht erreichbar (anderes Netz): still nichts tun
        log('Stereo-Poster: Kodex nicht erreichbar (%s)' % e, xbmc.LOGDEBUG)
        return
    if media is None:
        return
    media = [m for m in media if m.get('hasTiefenkarte', True)]
    monitor = xbmc.Monitor()
    with _lock:
        movies = rpc('VideoLibrary.GetMovies', properties=['file', 'uniqueid', 'art', 'tag']).get('movies', [])
        pairs = match(movies, media)
        pairs.sort(key=lambda p: '3D' not in (p[0].get('tag') or []))  # 3D-Filme zuerst
        store = Store()
        seen = {}
        for movie, _ in pairs:
            tmdb = str((movie.get('uniqueid') or {}).get('tmdb') or '')
            seen[tmdb] = seen.get(tmdb, 0) + 1
        shared = {t for t, n in seen.items() if t and n > 1}
        done = made = 0
        started = time.monotonic()
        wanted = set()
        for movie, item in pairs:
            before = made
            if not wait_idle(monitor):
                break
            key = key_of(movie, shared)
            wanted.add(movie['movieid'])
            art = (movie.get('art') or {}).get('poster')
            if not art:
                continue
            target = FOLDER + key + '.jpg'
            local = os.path.join(store.folder, key + '.jpg')
            try:
                map_bytes, map_stamp = store.depthmap(base, item['id'])
                if not map_bytes:
                    continue
                poster_path, poster_stamp = poster_source(art)
                stamp = {'kodex': item['id'], 'map': map_stamp, 'poster': poster_stamp, 'algo': ALGO}
                if store.index.get(key) != stamp or not os.path.exists(local):
                    poster = Image.open(io.BytesIO(read_file(poster_path)))
                    poster.draft('RGB', (HALF[0] * 2, HALF[1] * 2))  # JPEG gleich verkleinert dekodieren
                    pair = render_pair(poster, Image.open(io.BytesIO(map_bytes)))
                    pair.save(local + '.tmp', 'JPEG', quality=88)
                    os.replace(local + '.tmp', local)
                    store.index[key] = stamp
                    store.save()
                    drop_cached(target)
                    made += 1
                set_art(movie, target)
                done += 1
            except Exception as e:  # ein Film darf die anderen nicht aufhalten
                log('Stereo-Poster fuer %s nicht gerechnet: %s' % (movie.get('file'), e), xbmc.LOGWARNING)
            if monitor.waitForAbort(PAUSE if made > before else 0.01):
                break
        else:
            # Karte bei Kodex entfernt oder Film nicht mehr zuordenbar: Art-Eintrag entfernen. Die Datei bleibt liegen
            # (klein; ein anderes Profil mit eigener Bibliothek koennte sie noch nutzen)
            for movie in movies:
                if movie['movieid'] not in wanted and (movie.get('art') or {}).get(ART):
                    set_art(movie, None)
        log('Stereo-Poster: %d Filme mit Tiefenkarte, %d neu gerechnet (%.0f s)' % (done, made, time.monotonic() - started))


def schedule(delay=30.0):
    """Abgleich gebuendelt nach einer Pause (nach tags3d, das beim Start und nach Scans zuerst laeuft)."""
    global _timer
    if _timer:
        _timer.cancel()
    _timer = threading.Timer(delay, _run)
    _timer.daemon = True
    _timer.start()


def _run():
    try:
        sync()
    except Exception as e:  # nur Komfort
        log('Stereo-Poster: %s' % e, xbmc.LOGWARNING)
