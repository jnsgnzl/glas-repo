"""Glas Helper (Dienst): Profilwahl nach dem Ruhezustand und Farbe des Ersatz-Avatars.

das Vorbild: Einstellung "Profil beim Beenden des Ruhezustands auswaehlen" - nach dem Aufwachen fragt das Vorbild, wer zusieht.
Glas: Skin-Einstellung Skin.HasSetting(glas_profile_on_wake). Ausloeser:
  - Kodi meldet System.OnWake (Rueckkehr aus Suspend(), Ruhezustand des Geraets),
  - nach dem Ruhezustand ueber CEC (Geraet ohne Suspend, z. B. Vero: power.py schaltet nur den Fernseher aus und setzt
    Window(Home).Property(glas.standby) mit dem Zeitpunkt) die erste Bedienung danach (Leerlaufzeit springt zurueck;
    das Ende des Bildschirmschoners allein zaehlt nicht, Aerial beendet ihn schon beim Start). Ohne Leerlauf binnen
    einer Minute nach dem Klick gilt der Ruhezustand als verworfen.
Dann, wenn mehr als ein Profil existiert, nichts abgespielt wird und die Profilwahl nicht schon offen ist:
ActivateWindow(LoginScreen). Das ist Kodis eigenes Anmeldefenster im laufenden Profil - anders als System.LogOff wird
dabei nichts entladen: waehlt man dasselbe Profil, bleibt es geladen (Kodi startet nur die Dienste neu), ein anderes
Profil laedt Kodi wie beim Wechsel im Kontrollzentrum. Zurueck schliesst die Profilwahl nicht (wie bei dem Vorbild).

Ausserdem: Window(Home).Property(glas.avatar) = 1..6, Farbe des Ersatz-Avatars des aktuellen Profils nach seinem Platz in
Kodis Profilliste (gleiche Zuordnung wie die Profillisten im Skin, Variablen GlasAvatarItemVar/GlasAvatarCurrentVar).
"""
import json
import threading
import time

import xbmc
import xbmcgui

import avr
import cine
import marks
import seekthumbs
import stereo
import tags3d

HOME = xbmcgui.Window(10000)
SETTING = 'Skin.HasSetting(glas_profile_on_wake)'
STANDBY = 'glas.standby'
AVATAR_COLORS = 6


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.glas.helper] ' + msg, level)


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def profiles():
    return rpc('Profiles.GetProfiles').get('profiles', [])


def set_avatar():
    """Farbe des Ersatz-Avatars fuer das aktuelle Profil (Platz in der Profilliste, 1-basiert, alle 6 von vorn)."""
    current = rpc('Profiles.GetCurrentProfile').get('label', '')
    names = [p.get('label', '') for p in profiles()]
    index = names.index(current) if current in names else 0
    HOME.setProperty('glas.avatar', str(index % AVATAR_COLORS + 1))


_nextup_lock = threading.Lock()
_nextup_timer = None
_nextup_regen = False


def nextup_gen():
    """Bibliothek geaendert: das gemeinsame Ergebnis der Reihen "Weiter ansehen" gilt nicht mehr (nextup.shared_entries).
    Sofort bei der Meldung, damit schon Kodis eigenes Neuladen der Reihen (bei jeder Meldung der Videobibliothek und
    jedem Wiedergabe-Ende) neu rechnet."""
    HOME.setProperty('glas.nextup.gen', '%.3f' % time.time())


def _nextup_fire():
    global _nextup_regen
    with _nextup_lock:
        regen, _nextup_regen = _nextup_regen, False
    if regen:
        nextup_gen()
    HOME.setProperty('glas.nextup.stamp', str(int(time.time() * 10)))


def nextup_changed(delay, regen=False):
    """Window(Home).Property(glas.nextup.stamp) neu: Reihen "Weiter ansehen" (Inhalt mit &stamp=...) laden neu, auch
    leere (die laedt Kodi bei Bibliotheksmeldungen nicht selbst neu; vorher blieben sie bis zum Neustart des Fensters
    stehen, Testerbericht 05.11.2026). Gebuendelt: ein neues Ereignis ersetzt den wartenden Zeitgeber. regen: auch das
    gemeinsame Ergebnis verwerfen (nach dem Stopp sichert Kodi Fortschritt und Gesehen erst nach Kodis eigenem Neuladen);
    sonst trifft das Neuladen durch den Stempel das Ergebnis von Kodis Neuladen und rechnet nicht noch einmal."""
    global _nextup_timer, _nextup_regen
    if xbmc.Monitor().abortRequested():  # Kodi beendet: keinen neuen Faden mehr (service.py, stop_threads)
        return
    with _nextup_lock:
        _nextup_regen = _nextup_regen or regen
        if _nextup_timer:
            _nextup_timer.cancel()
        _nextup_timer = threading.Timer(delay, _nextup_fire)
        _nextup_timer.daemon = True
        _nextup_timer.start()


def library_item(data):
    """('movie'|'episode'|'tvshow', DB-ID) aus den Daten einer Meldung (item.type, item.id), sonst None. Kodi setzt id nur
    fuer Titel der Bibliothek (AnnouncementManager), nicht fuer Titelmelodien, Aerial oder Dateien."""
    try:
        item = (json.loads(data or '{}') or {}).get('item') or {}
    except ValueError:
        return None
    if item.get('type') in ('movie', 'episode', 'tvshow') and isinstance(item.get('id'), int) and item['id'] > 0:
        return item['type'], item['id']
    return None



def _since(value):
    """Zeitpunkt aus glas.standby (power.suspend setzt time.time(); aeltere Fassungen setzten "1" = jetzt werten)"""
    try:
        stamp = float(value)
    except ValueError:
        return time.time()
    return stamp if stamp > 1e9 else time.time()

class WakeMonitor(xbmc.Monitor):
    """Ersetzt im Dienst xbmc.Monitor (waitForAbort bleibt) und merkt sich das Aufwachen; tick() im Takt des Dienstes."""

    def __init__(self):
        super().__init__()
        self.pending = False
        self.armed = False      # nach CEC-Ruhezustand: erst einmal Leerlauf gesehen, dann zaehlt die naechste Bedienung
        self.standby_since = 0.0
        try:
            set_avatar()
        except Exception as e:  # nur Optik
            log('Avatar-Farbe: %s' % e, xbmc.LOGDEBUG)

    def onNotification(self, sender, method, data):
        if xbmc.getSkinDir() != 'skin.glas':  # anderer Skin: nichts planen (service.glas_active)
            return
        if method == 'Other.' + avr.REFRESH:  # Audio-Menue des Kontrollzentrums offen (avr.Poller)
            avr.REQUEST.set()
        elif method == 'System.OnWake':
            log('Aufwachen (System.OnWake)')
            self.pending = True
        elif method == 'System.OnSleep':
            self.armed = False
        elif method.startswith('VideoLibrary.'):
            nextup_gen()  # jede Aenderung der Bibliothek (auch Fortschritt, eigene Art-Eintraege)
            if method == 'VideoLibrary.OnUpdate' and '"playcount"' in (data or ''):
                nextup_changed(0.5)  # gesehen/ungesehen markiert: "Weiter ansehen" neu laden
                item = library_item(data)
                if item:
                    marks.schedule(item=item)  # Abzeichen "Neu" nur fuer diesen Titel
            elif method == 'VideoLibrary.OnScanFinished':
                nextup_changed(2)
                tags3d.schedule()  # 3D-Schlagwort (tags3d.py) fuer alle Filme
                marks.schedule()  # Abzeichen "Neu" (marks.py): neue Titel
                stereo.schedule()  # Stereo-Poster fuer neue Filme (stereo.py), nach dem Schlagwort
                cine.schedule()  # Logo-Poster fuer neue Titel (cine.py)
        elif method == 'Player.OnStop':
            item = library_item(data)
            if item is None and '"song"' in (data or ''):
                return  # Musik, auch die eigene Titelmelodie: nichts zu tun
            seekthumbs.schedule()  # Vorschaubilder der Spulvorschau aus dem Bild-Cache (seekthumbs.py)
            if item is None:
                return  # Datei ausserhalb der Bibliothek (z. B. Bildschirmschoner Aerial)
            nextup_gen()
            nextup_changed(2, regen=True)  # Kodi sichert Fortschritt und Gesehen erst kurz nach dem Stopp
            if item[0] == 'movie':
                tags3d.schedule(movieid=item[1])  # nach dem Stopp kennt Kodi den Stereomodus der ISO (tags3d.py)
            marks.schedule(item=item)  # Abzeichen "Neu" (marks.py): gesehen

    def onScreensaverDeactivated(self):
        # Kein Aufwachen: Aerial (Vorgabe-Bildschirmschoner) beendet Kodis Bildschirmschoner schon beim Start selbst und
        # spielt dann in einem eigenen Fenster (Pruefplan L53: die Profilwahl lief bei ausgeschaltetem Fernseher und
        # fehlte beim echten Aufwachen). Die Taste, die einen Bildschirmschoner beendet, ist Bedienung - das erkennt tick
        if HOME.getProperty(STANDBY):
            log('Bildschirmschoner beendet (Ruhezustand bleibt scharf)', xbmc.LOGDEBUG)

    def tick(self):
        standby = HOME.getProperty(STANDBY)
        if standby and not self.pending:
            # CEC-Ruhezustand: der Klick auf "Ruhezustand" setzt die Leerlaufzeit selbst zurueck, daher erst nach
            # 10 s Leerlauf scharf schalten; danach ist die erste Bedienung das Aufwachen
            if not self.armed:
                if xbmc.getCondVisibility('System.IdleTime(10)'):
                    self.armed = True
                elif time.time() - _since(standby) > 60:
                    # binnen einer Minute kein Leerlauf: der Nutzer bedient weiter (Fernseher gleich wieder an) - nicht
                    # spaeter mitten in der Bedienung als Aufwachen werten (Pruefplan L56)
                    log('Ruhezustand verworfen (weiter bedient)')
                    HOME.clearProperty(STANDBY)
            elif not xbmc.getCondVisibility('System.IdleTime(1)'):
                log('Aufwachen nach Ruhezustand (Bedienung)')
                self.pending = True
                self.wait = time.time()
        if self.pending:
            # Aerial schliesst nach der Taste noch (Fenster und Wiedergabe): kurz warten, statt die Profilwahl wegen
            # Player.HasMedia ganz ausfallen zu lassen (Pruefplan L53)
            if (xbmc.getCondVisibility('Window.IsVisible(screensaver-atv4.xml) | System.ScreenSaverActive')
                    and time.time() - getattr(self, 'wait', 0) < 5):
                return
            self.pending = False
            self.armed = False
            HOME.clearProperty(STANDBY)
            self.ask_profile()

    @staticmethod
    def ask_profile():
        if not xbmc.getCondVisibility(SETTING):
            return
        if xbmc.getCondVisibility('Player.HasMedia | Window.IsActive(loginscreen)'):
            return
        if len(profiles()) < 2:
            return
        log('Profilwahl nach dem Ruhezustand')
        xbmc.executebuiltin('Dialog.Close(all,true)')
        # kurz warten, bis die Dialoge zu sind (sonst oeffnet Kodi das Fenster darunter)
        time.sleep(0.3)
        xbmc.executebuiltin('ActivateWindow(LoginScreen)')
