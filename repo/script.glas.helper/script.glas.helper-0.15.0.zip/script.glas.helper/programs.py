"""Glas Helper: eigene Programme im Dock (nur Windows; Testerwunsch 17.11.2026: Netflix-Starter mit HDR-Umschaltung als
Eintrag im Hauptmenue, ohne Home.xml oder favourites.xml von Hand zu aendern).

In der Auswahl des Dock-Platzes "Programm waehlen ...": Kodis Dateiauswahl (.exe, .cmd, .bat, .lnk), dann der Name im
Dock (Vorschlag aus dem Dateinamen). Kachel: Markenkachel, wenn der Name eine bekannte Marke enthaelt (brands.json
"names", wie bei den Favoriten); sonst auf Wunsch ein eigenes Bild, aus dem applogo.make_custom Kachel und Logo baut;
sonst die Namenskachel (sources.tile).

Die Programme stehen in addon_data/script.glas.helper/programs.json ({id: {label, path, image, art}}), die gebauten
Bilder (art: tile, logo, preview) in programs/. Schluessel im Dock exe:<id>. Gestartet wird ueber den Helper (?action=exec&key=exe:<id>) mit Kodis
System.Exec - Windows-Pfade haben Backslashes, die ein Skin-String nicht heil uebersteht (favourites.py).
"""
import hashlib
import json
import os
import re
from urllib.parse import urlencode

import xbmc
import xbmcgui
import xbmcvfs

PREFIX = 'exe:'
NEW = 'exe:new'
BASE = 'plugin://script.glas.helper/'
DATA = xbmcvfs.translatePath('special://profile/addon_data/script.glas.helper/')
FILE = os.path.join(DATA, 'programs.json')
IMAGES = os.path.join(DATA, 'programs')
MASK = '.exe|.cmd|.bat|.lnk'
IMAGE_MASK = '.png|.jpg|.jpeg|.webp|.bmp|.gif'


def available():
    return xbmc.getCondVisibility('System.Platform.Windows')


def _s(n):
    return xbmc.getInfoLabel('$LOCALIZE[%d]' % n)


def load():
    try:
        with open(FILE, encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save(data):
    os.makedirs(DATA, exist_ok=True)
    tmp = FILE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, FILE)


def entries(brand=None):
    """[(Schluessel, Name, Vorschaubild)] der angelegten Programme fuer die Auswahl des Dock-Platzes"""
    out = []
    for pid, p in sorted(load().items(), key=lambda kv: kv[1].get('label', '').lower()):
        art = _art(pid, p, brand)
        out.append((PREFIX + pid, p.get('label', ''), art.get('preview') or art.get('tile', '')))
    return out


def _art(pid, p, brand):
    """{'tile', 'logo', 'preview'} eines Programms: eigenes Bild, sonst Marke, sonst Namenskachel"""
    own = p.get('art') or {}
    if all(os.path.isfile(own.get(k, '')) for k in ('tile', 'logo', 'preview')):
        return dict(own)
    art = brand(p.get('label', '')) if brand else {}
    if art:
        return art
    name = __import__('sources').tile('exe-' + pid, p.get('label', ''), int(pid[:4], 16))
    return {'tile': name, 'preview': name}


def entry(key, brand=None):
    p = load().get(key[len(PREFIX):])
    if not p:
        return None
    art = _art(key[len(PREFIX):], p, brand)
    return {'key': key, 'label': p.get('label', ''), 'tile': art.get('tile', ''), 'logo': art.get('logo', ''),
            'action': 'RunPlugin(%s?%s)' % (BASE, urlencode({'action': 'exec', 'key': key}))}


def delete(key):
    """Programm samt gebauten Bildern loeschen (Kontextmenue des Docks, default.home_context); die Datei selbst bleibt"""
    pid = key[len(PREFIX):]
    data = load()
    if data.pop(pid, None) is not None:
        save(data)
    if os.path.isdir(IMAGES):
        for name in os.listdir(IMAGES):
            if name.startswith(pid + '-'):
                os.remove(os.path.join(IMAGES, name))
    tiles = xbmcvfs.translatePath(__import__('sources').TILES)  # Namenskachel (sources.tile, exe-<id>-<stand>.png)
    if os.path.isdir(tiles):
        for name in os.listdir(tiles):
            if name.startswith('exe-%s-' % pid):
                os.remove(os.path.join(tiles, name))


def run(key):
    p = load().get(key[len(PREFIX):])
    if not p or not p.get('path'):
        xbmc.log('[script.glas.helper] Programm %s nicht mehr vorhanden' % key, xbmc.LOGWARNING)
        return
    xbmc.executebuiltin('System.Exec("%s")' % p['path'])


def _suggest(path):
    """Name aus dem Dateinamen: "LaunchNetflix.exe" -> "Netflix", "netflix_hdr.cmd" -> "netflix hdr",
    "StreamBox.cmd" -> "StreamBox" """
    stem = os.path.splitext(os.path.basename(path))[0]
    # "Launch"/"Start"/"Run" am Anfang in jeder Schreibweise, danach Trenner oder ein Grossbuchstabe (nicht "Launcher")
    stem = re.sub(r'^(?i:launch|start|run)(?:[\s_\-]+|(?=[A-Z0-9]))', '', stem) or stem
    # Binnenmajuskeln bleiben ("StreamBox" ist meist der Name), nur _ und - werden Leerzeichen
    return re.sub(r'[_\-]+', ' ', stem).strip()


def create(brand=None):
    """Programm waehlen, benennen, Logo festlegen; gibt den Schluessel zurueck oder None (abgebrochen)"""
    dialog = xbmcgui.Dialog()
    path = dialog.browse(1, _s(32921), 'local', MASK)
    if not path or not os.path.isfile(path):
        return None
    label = dialog.input(_s(32922), defaultt=_suggest(path))
    if not label:
        return None
    pid = hashlib.sha1(('%s|%s' % (path.lower(), label)).encode('utf-8')).hexdigest()[:10]
    p = {'label': label, 'path': path}
    if not (brand and brand(label)) and dialog.yesno(label, _s(32924) % label, nolabel=_s(32926), yeslabel=_s(32925)):
        image = dialog.browse(2, _s(32925), 'local', IMAGE_MASK)
        if image and os.path.isfile(image):
            art = make_images(pid, image)
            if art:
                p.update({'image': image, 'art': art})
            else:
                dialog.notification(label, _s(32923), xbmcgui.NOTIFICATION_WARNING, 4000)
    data = load()
    data[pid] = p
    save(data)
    return PREFIX + pid


def make_images(pid, image):
    """Kachel, Logo und Vorschau aus dem Bild; {'tile', 'logo', 'preview'} oder {} (ohne Pillow, Bild nicht lesbar)"""
    try:
        from applogo import make_custom, preview
        tile, logo = make_custom(image)
    except Exception as e:
        xbmc.log('[script.glas.helper] Logo aus %s nicht erzeugt: %s' % (image, e), xbmc.LOGWARNING)
        return {}
    os.makedirs(IMAGES, exist_ok=True)
    for old in os.listdir(IMAGES):
        if old.startswith(pid + '-'):
            os.remove(os.path.join(IMAGES, old))
    # Name je Bild und Stand: Kodi haelt Texturen unter ihrem Pfad zwischengespeichert, ein neues Logo fuer dasselbe
    # Programm braucht deshalb einen neuen Dateinamen
    stamp = hashlib.sha1(('%s|%d' % (image, int(os.path.getmtime(image)))).encode('utf-8')).hexdigest()[:6]
    art = {k: os.path.join(IMAGES, '%s-%s-%s.png' % (pid, stamp, k)) for k in ('tile', 'logo', 'preview')}
    tile.save(art['tile'])
    logo.save(art['logo'])
    preview(tile, logo).save(art['preview'])
    return art
