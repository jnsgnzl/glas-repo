"""Glas Helper (Dienst): Schreibzugriffe auf die Videobibliothek buendeln.

Jedes VideoLibrary.Set*Details meldet Kodi als VideoLibrary.OnUpdate, und Kodi laedt daraufhin jede sichtbare Reihe mit
Videos neu (CDirectoryProvider::Announce) - auf dem Homescreen und der TV-Seite je drei bis fuenf Plugin-Starts. Der
erste Lauf von Logo-Postern, Stereo-Postern, "Neu" und 3D-Schlagwort schrieb so Hunderte Male einzeln, jedes Mal mit
diesem Neuladen. Batch sammelt die Schreibzugriffe eines Laufs; wenige (bis SMALL) gehen sofort hinaus, mehr erst im
Leerlauf (QUIET: 30 s keine Bedienung oder Bildschirmschoner, kein Film) und dann am Stueck - Kodi fasst die Meldungen
eines Schwalls zu wenigen Neuladungen zusammen. Einzelne Aenderungen (Merkliste, Wertung) schreiben weiter sofort.
"""
import json

import xbmc

SMALL = 3
# Leerlauf: 30 s ohne Bedienung oder Bildschirmschoner; kein Film (die Bildschirmschoner Aerial und Glas Videos spielen
# selbst Video)
QUIET = ('[System.IdleTime(30) | System.ScreenSaverActive] + '
         '![Player.HasVideo + !Window.IsActive(screensaver-atv4.xml) + !Window.IsActive(screensaver-glas-videos.xml)]')
CHECK = 5.0


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


class Batch:
    def __init__(self, monitor=None):
        self.monitor = monitor or xbmc.Monitor()
        self.calls = []

    def add(self, method, **params):
        self.calls.append((method, params))

    def __len__(self):
        return len(self.calls)

    def flush(self):
        """Alles schreiben (ab SMALL erst im Leerlauf); False, wenn Kodi vorher beendet wurde (dann bleibt der Rest
        liegen - die Laeufe gleichen beim naechsten Mal ohnehin gegen die Bibliothek ab)."""
        if len(self.calls) > SMALL:
            while not xbmc.getCondVisibility(QUIET):
                if self.monitor.waitForAbort(CHECK):
                    return False
        while self.calls:
            if self.monitor.abortRequested():
                return False
            method, params = self.calls.pop(0)
            rpc(method, **params)
        return True
