"""App-Logos fuer die Apps-Seite: aus dem quadratischen Add-on-Symbol ein freigestelltes Logo machen.

Kodi-Add-ons bringen nur ein deckendes Symbol mit (meist Logo auf einfarbiger Flaeche). Liegt am Rand eine einheitliche
Farbe, wird diese Flaeche von aussen her freigestellt (Flood-Fill), die Kanten weich ausgeblendet und von der alten
Hintergrundfarbe befreit, dann auf das Logo zugeschnitten. Dunkle, farblose Teile werden hell, damit sie auf der
dunklen Kachel lesbar sind. Ohne einheitlichen Rand (Foto-Symbole) gibt es stattdessen einen weichgezeichneten Kachelhintergrund.
Nur Pillow, ohne Kodi-Module (testbar ausserhalb von Kodi). Pixelweise Rechnungen laufen als Masken und Kanaloperationen
in Pillow (ImageMath, ImageChops; vorhanden ab Pillow 6, die Vero hat 8.1, Kodi unter Windows 6.2); in Python bleiben
nur die Flutung ueber einer fertigen Maske und die Kantenpixel.
"""
import math
from collections import deque
from fractions import Fraction

from PIL import Image, ImageChops, ImageEnhance, ImageFilter, ImageMath, ImageOps

SIZE = 256          # Arbeitsgroesse
TOL = 38            # Farbabstand, der noch als Hintergrund gilt
SOLID = 0.82        # Anteil Randpixel mit Hintergrundfarbe, ab dem der Rand als einfarbig gilt
PHOTO = 160         # Farbstufen (4 Bit je Kanal, mind. 4 Pixel) im Vordergrund, ab denen ein Symbol als Foto gilt
VISIBLE = 110       # Deckkraft, ab der Pixel beim Zuschneiden zaehlen (blasse Reste bleiben ausserhalb)
NEAR = 0.3          # Anteil des Motivs nahe der (hellen) Hintergrundfarbe, ab dem nicht freigestellt wird


def _dist(a, b):
    return ((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2) ** 0.5


def _border(w, h):
    for x in range(w):
        yield x, 0
        yield x, h - 1
    for y in range(1, h - 1):
        yield 0, y
        yield w - 1, y


def _dist2(img, color):
    """Quadrat des Farbabstands (RGB, wie _dist) jedes Pixels zu color als Bild im Modus I (in C gerechnet)."""
    r, g, b = img.convert('RGB').split()
    return ImageMath.eval('(r - %d) * (r - %d) + (g - %d) * (g - %d) + (b - %d) * (b - %d)'
                          % (color[0], color[0], color[1], color[1], color[2], color[2]), r=r, g=g, b=b)


def _below(dist2, limit):
    """Maske (L, 255/0): Abstand < limit (ganzzahlig: dist2 < limit**2 gilt genau dann, wenn sqrt(dist2) < limit)."""
    return ImageMath.eval('convert(min(max(%d - d, 0), 1) * 255, "L")' % (limit * limit), d=dist2)


def _count(mask):
    return mask.histogram()[255]


def _and(a, b):
    return ImageChops.darker(a, b)


def _shift(mask, dx, dy):
    """Maske um (dx, dy) verschoben, ohne Umlauf am Rand."""
    out = Image.new('L', mask.size, 0)
    out.paste(mask, (dx, dy))
    return out


def make_logo(src):
    """Gibt ('logo', Bild) oder ('tile', Bild) zurueck. Rechnet wie die fruehere Fassung mit Schleifen ueber alle Pixel
    (gleiche Abstaende, gleiche Flutung mit vier Nachbarn), aber mit Masken in Pillow: auf der Vero dauerte ein Symbol
    in reinem Python geschaetzt 0,3-1 s, das App-Raster blieb beim ersten Start entsprechend lange leer."""
    img = Image.open(src).convert('RGBA')
    img.thumbnail((SIZE, SIZE), Image.LANCZOS)
    w, h = img.size
    px = img.load()
    border = [px[x, y] for x, y in _border(w, h)]

    # schon freigestellt (transparenter Rand)
    if sum(1 for p in border if p[3] < 30) / len(border) > SOLID:
        return 'logo', _finish(img)

    opaque = [p for p in border if p[3] > 200]
    if not opaque:
        return 'tile', _tile(img)
    bg = tuple(sorted(c[i] for c in opaque)[len(opaque) // 2] for i in range(3))
    if sum(1 for p in opaque if _dist(p, bg) < TOL) / len(border) < SOLID:
        return 'tile', _tile(img)

    # Hintergrund von aussen her fluten: Maske "nahe der Hintergrundfarbe" in C, dann nur noch Bytes vergleichen
    dist2 = _dist2(img, bg)
    near_bg = _below(dist2, TOL).tobytes()
    is_bg = bytearray(w * h)
    queue = deque()
    for x, y in _border(w, h):
        i = y * w + x
        if near_bg[i] and not is_bg[i]:
            is_bg[i] = 1
            queue.append(i)
    while queue:
        i = queue.popleft()
        x, y = i % w, i // w
        for j, ok in ((i + 1, x + 1 < w), (i - 1, x > 0), (i + w, y + 1 < h), (i - w, y > 0)):
            if ok and not is_bg[j] and near_bg[j]:
                is_bg[j] = 1
                queue.append(j)
    bg_mask = Image.frombytes('L', (w, h), bytes(is_bg)).point(lambda v: 255 if v else 0)
    not_bg = ImageChops.invert(bg_mask)

    # Motiv aehnelt dem Hintergrund (z. B. weisse Maus auf Weiss) oder ist ein Foto mit vielen Abstufungen: die Flutung
    # wuerde Teile anfressen. Dann lieber Kachelhintergrund mit abgerundetem Symbol.
    fg_mask = _and(not_bg, img.getchannel('A').point(lambda v: 255 if v > 200 else 0))
    fg = _count(fg_mask)
    near = _count(_and(fg_mask, _below(dist2, TOL * 2)))
    quant = img.convert('RGB').point(lambda v: v >> 4 << 4)
    colors = Image.composite(quant, Image.new('RGB', (w, h), (1, 1, 1)), fg_mask).getcolors(w * h) or []
    photo = sum(1 for n, c in colors if n >= 4 and c != (1, 1, 1))
    light_bg = 0.2126 * bg[0] + 0.7152 * bg[1] + 0.0722 * bg[2] > 200
    if not fg or (light_bg and near / fg > NEAR) or photo > PHOTO:
        return 'tile', _tile(img)

    out = Image.composite(img, Image.new('RGBA', (w, h), (0, 0, 0, 0)), not_bg)
    # Kante (Pixel neben dem Hintergrund): Deckkraft nach Farbabstand, Farbe ohne Anteil der alten Hintergrundfarbe
    beside = ImageChops.lighter(ImageChops.lighter(_shift(bg_mask, 1, 0), _shift(bg_mask, -1, 0)),
                                ImageChops.lighter(_shift(bg_mask, 0, 1), _shift(bg_mask, 0, -1)))
    edge = _and(beside, not_bg).tobytes()
    po = out.load()
    for i in (i for i, v in enumerate(edge) if v):
        x, y = i % w, i // w
        r, g, b, a = px[x, y]
        k = min(1.0, max(0.05, _dist((r, g, b), bg) / (TOL * 3)))
        r, g, b = (min(255, max(0, round((c - (1 - k) * bc) / k))) for c, bc in zip((r, g, b), bg))
        po[x, y] = (r, g, b, round(a * k))
    return 'logo', _finish(out)


def _finish(img):
    # Dunkle, farblose Teile (z. B. schwarzer Schriftzug) wie im dunklen Modus von dem Vorbild weiss; Farbiges bleibt.
    # Nur wenn das Dunkle gleichmaessig ist (Schrift, Flaeche), nicht bei Fotos. Die Deckkraft behaelt die weiche Kante.
    r, g, b, a = img.split()
    hi = ImageChops.lighter(ImageChops.lighter(r, g), b)
    lo = ImageChops.darker(ImageChops.darker(r, g), b)
    grey_dark = _and(hi.point(lambda v: 255 if v < 110 else 0),
                     ImageChops.subtract(hi, lo).point(lambda v: 255 if v < 36 else 0))
    solid = a.point(lambda v: 255 if v > 200 else 0)
    hist = hi.histogram(_and(solid, grey_dark))
    n = sum(hist)
    # nicht, wenn das Logo selbst grosse helle Flaechen hat (dunkle Schrift auf hellem Feld bliebe sonst unsichtbar)
    bright = _count(_and(solid, lo.point(lambda v: 255 if v > 200 else 0))) / max(1, _count(solid))
    if n > 20 and bright < 0.25:
        mean = Fraction(sum(v * c for v, c in enumerate(hist)), n)
        var = sum(c * (v - mean) ** 2 for v, c in enumerate(hist) if c) / n
        if math.sqrt(var) < 14:  # gleichmaessig dunkel = Schrift (wie statistics.pstdev)
            white = Image.merge('RGBA', (Image.new('L', img.size, 255),) * 3 + (a,))
            img = Image.composite(white, img, _and(a.point(lambda v: 255 if v else 0), grey_dark))
    # danach: Zuschnitt nur auf das, was auf der dunklen Kachel sichtbar ist (deckend und nicht fast schwarz)
    alpha = img.getchannel('A').point(lambda v: 255 if v > VISIBLE else 0)
    light = img.convert('RGB').convert('L').point(lambda v: 255 if v > 60 else 0)
    box = Image.composite(alpha, Image.new('L', img.size, 0), light).getbbox() or alpha.getbbox()
    if box:
        img = img.crop(box)
    return img


def _tile(img):
    """Kachelhintergrund aus dem Symbol: fuellend, weichgezeichnet, abgedunkelt (16:10 wie die Kachel)."""
    rgb = img.convert('RGB')
    tile = ImageOps.fit(rgb, (320, 192), Image.BILINEAR)
    tile = tile.filter(ImageFilter.GaussianBlur(14))
    return ImageEnhance.Brightness(tile).enhance(0.6)


def _rounded(img, size, radius):
    img = ImageOps.fit(img.convert('RGBA'), (size, size), Image.LANCZOS)
    # abgerundete Maske von Hand (rounded_rectangle gibt es erst ab Pillow 8.2, die Vero hat 8.1)
    from PIL import ImageDraw
    big, r = size * 4, radius * 4
    mask = Image.new('L', (big, big), 0)
    draw = ImageDraw.Draw(mask)
    draw.rectangle((r, 0, big - 1 - r, big - 1), fill=255)
    draw.rectangle((0, r, big - 1, big - 1 - r), fill=255)
    for x, y in ((0, 0), (big - 1 - 2 * r, 0), (0, big - 1 - 2 * r), (big - 1 - 2 * r, big - 1 - 2 * r)):
        draw.ellipse((x, y, x + 2 * r, y + 2 * r), fill=255)
    mask = mask.resize((size, size), Image.LANCZOS)
    img.putalpha(Image.composite(img.getchannel('A'), Image.new('L', (size, size), 0), mask))
    return img


def make_card(tile_path=None, logo_path=None, icon_path=None):
    """Fertige App-Kachel 500 x 300 wie auf dem Homescreen (Kachelanzeige 250 x 150, doppelte Aufloesung):
    Kachelhintergrund (Marke oder weichgezeichnet) bzw. dunkle Flaeche, darauf das Logo (Feld 380 x 180) oder das
    abgerundete Symbol (220 x 220). Ecken rundet der Skin."""
    if tile_path:
        card = ImageOps.fit(Image.open(tile_path).convert('RGB'), (500, 300), Image.LANCZOS)
    else:
        card = Image.new('RGB', (500, 300), (44, 44, 46))
        top = Image.new('RGB', (500, 300), (58, 58, 60))
        card = Image.composite(top, card, Image.linear_gradient('L').resize((500, 300)).point(lambda v: 255 - v))
    if logo_path:
        logo = Image.open(logo_path).convert('RGBA')
        logo.thumbnail((380, 180), Image.LANCZOS)
        card.paste(logo, ((500 - logo.width) // 2, (300 - logo.height) // 2), logo)
    elif icon_path:
        icon = _rounded(Image.open(icon_path), 220, 44)
        card.paste(icon, (140, 40), icon)
    return card


def preview(tile, logo):
    """Kachel und Logo in einem Bild wie im Dock (Kachel 250 x 150, Logo-Feld 190 x 90 mittig), fuer Auswahllisten,
    die nur ein Bild zeigen. logo darf None sein."""
    out = tile.convert('RGB').copy()
    if logo is not None:
        w, h = out.size
        small = logo.resize((round(w * 190 / 250), round(h * 90 / 150)), Image.LANCZOS)
        out.paste(small, ((w - small.width) // 2, (h - small.height) // 2), small)
    return out


def _plate(size=(640, 384)):
    """Dunkle App-Flaeche wie Apps ohne eigene Kachel (oben etwas heller, wie make_card)"""
    card = Image.new('RGB', size, (44, 44, 46))
    top = Image.new('RGB', size, (58, 58, 60))
    return Image.composite(top, card, Image.linear_gradient('L').resize(size).point(lambda v: 255 - v))


def _logo_field(img, max_w=340, max_h=150):
    """Logo auf die 380 x 180 grosse Logo-Flaeche des Skins, mittig, hoechstens max_w x max_h (kleine Bilder bis 3fach
    vergroessert)"""
    scale = min(max_w / img.width, max_h / img.height, 3.0)
    img = img.resize((max(1, round(img.width * scale)), max(1, round(img.height * scale))), Image.LANCZOS)
    field = Image.new('RGBA', (380, 180), (0, 0, 0, 0))
    # ohne Maske: Pixel samt Deckkraft uebernehmen (mit Maske mischte Pillow halbdurchsichtige Kanten zu Schwarz hin)
    field.paste(img, ((380 - img.width) // 2, (180 - img.height) // 2))
    return field


def make_custom(src):
    """Eigenes Logo eines Programms im Dock (programs.py; Dienste ohne Logo in resources/brands, Testerwunsch
    17.11.2026). Gibt (Kachel 640 x 384, Logo 380 x 180) zurueck:
      freigestellt (durchsichtiger Rand)  Logo auf der dunklen App-Flaeche, dunkle Schrift wird hell (_finish)
      einfarbiger Rand (Logo auf Flaeche)  Kachel in dieser Farbe, das Bild samt Flaeche darauf; der Rand des Bildes
                                          laeuft weich aus, damit keine Kante zur Kachel bleibt
      sonst (Foto, Verlauf)               weichgezeichneter Grund, das Bild abgerundet darauf (wie App-Symbole)"""
    img = Image.open(src).convert('RGBA')
    img.thumbnail((512, 512), Image.LANCZOS)
    w, h = img.size
    px = img.load()
    border = [px[x, y] for x, y in _border(w, h)]
    if sum(1 for p in border if p[3] < 30) / len(border) > SOLID:
        return _plate(), _logo_field(_finish(img))
    opaque = [p for p in border if p[3] > 200]
    if opaque:
        bg = tuple(sorted(c[i] for c in opaque)[len(opaque) // 2] for i in range(3))
        if sum(1 for p in opaque if _dist(p, bg) < TOL) / len(border) >= SOLID:
            # auf das Motiv zuschneiden (Pixel deutlich anders als die Flaeche), etwas Flaeche drumherum lassen
            box = ImageOps.invert(_below(_dist2(img, bg), TOL)).getbbox() or (0, 0, w, h)
            pad = round(0.08 * max(box[2] - box[0], box[3] - box[1]))
            box = (max(0, box[0] - pad), max(0, box[1] - pad), min(w, box[2] + pad), min(h, box[3] + pad))
            logo = img.crop(box)
            # weicher Rand: Deckkraft zu den Kanten hin auf 0
            fade = max(2, round(0.06 * min(logo.size)))
            mask = Image.new('L', (logo.width - 2 * fade, logo.height - 2 * fade), 255) if min(logo.size) > 4 * fade \
                else Image.new('L', (1, 1), 255)
            edge = Image.new('L', logo.size, 0)
            edge.paste(mask, (fade, fade))
            edge = edge.filter(ImageFilter.GaussianBlur(fade / 2))
            logo.putalpha(ImageChops.multiply(logo.getchannel('A'), edge))
            return Image.new('RGB', (640, 384), bg), _logo_field(logo)
    tile = _tile(img).resize((640, 384), Image.LANCZOS)
    return tile, _logo_field(_rounded(img, 220, 44), 220, 150)


def make_brand(glyph_path, hex_color):
    """Kachel in Markenfarbe (oben 6 % heller, wie die Tiefe von Vorbild-Symbolen) und das Marken-Logo darauf.
    Gibt (Kachel, Logo) zurueck; das Logo ist weiss, bei sehr heller Markenfarbe dunkel."""
    r, g, b = (int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
    tile = Image.new('RGB', (320, 192), (r, g, b))
    top = Image.new('RGB', (320, 192), tuple(min(255, round(c + (255 - c) * 0.06)) for c in (r, g, b)))
    grad = Image.linear_gradient('L').resize((320, 192)).point(lambda v: 255 - v)
    tile = Image.composite(top, tile, grad)
    glyph = Image.open(glyph_path).convert('RGBA')
    box = glyph.getchannel('A').getbbox()
    if box:
        glyph = glyph.crop(box)
    light = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255 > 0.65
    if light:
        glyph = Image.merge('RGBA', (*Image.new('RGB', glyph.size, (28, 28, 30)).split(), glyph.getchannel('A')))
    # Logo hoechstens 300 x 100 auf einer 380 x 180 grossen Flaeche (Kachelanzeige 190 x 90): Symbol etwa 50 px hoch
    glyph.thumbnail((300, 100), Image.LANCZOS)
    logo = Image.new('RGBA', (380, 180), (0, 0, 0, 0))
    logo.paste(glyph, ((380 - glyph.width) // 2, (180 - glyph.height) // 2), glyph)
    return tile, logo
