"""Glas Helper (Dienst): Abzeichen "Neu" auf Kacheln.

das Vorbild markiert neue Titel mit einer Kapsel "Neu" oben links. Kodi-Bedingungen koennen nicht mit Datumswerten rechnen
(ListItem.DateAdded ist nur Text), daher setzt der Dienst eine eigene Art-Sorte "glasnew" in Kodis Datenbank: der Skin
fragt !String.IsEmpty(ListItem.Art(glasnew)) ab (wie glasstereo in stereo.py; Art-Sorten sieht der Nutzer nirgends).

Neu ist, was in den letzten DAYS Tagen hinzukam und noch nicht gesehen ist: Filme, Folgen, und eine Serie mit
mindestens einer solchen Folge. Geschrieben wird nur bei einer Aenderung. Ganze Bibliothek (sync): Start des Dienstes,
jeder Bibliotheks-Scan und alle 6 Stunden (Ablauf der Frist). Nur der betroffene Titel (sync_items, schedule mit item):
Ende einer Wiedergabe aus der Bibliothek und "gesehen/ungesehen" (VideoLibrary.OnUpdate mit playcount; eigene
Set*Details schreiben nur Art und loesen das nicht aus) - vorher glich jedes Wiedergabe-Ende, auch von Titelmelodien und
Aerial, die ganze Bibliothek ab.
"""
import json
import threading
import time

import xbmc

from writes import Batch

ART = 'glasnew'
VALUE = 'special://skin/media/glas/badge-new.png'  # beliebiger Wert; der Skin prueft nur "nicht leer"
DAYS = 14
EVERY = 6 * 3600

_lock = threading.Lock()
_timer = None
_timer_lock = threading.RLock()  # schuetzt _timer, _full, _items: Planen aus dem Dienst und Neuplanen am Ende eines Laufs
_full = False                   # naechster Lauf gleicht alles ab
_items = set()                  # sonst nur diese Titel: ('movie'|'episode'|'tvshow', DB-ID)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.glas.helper] %s' % msg, level)


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def is_new(item, cutoff):
    return (item.get('playcount') or 0) == 0 and (item.get('dateadded') or '') >= cutoff


def update(kind, key, item, want, batch=None):
    """Art-Eintrag nur bei Aenderung schreiben; mit batch gesammelt (writes.Batch, ganzer Abgleich)."""
    have = bool((item.get('art') or {}).get(ART))
    if have == want:
        return 0
    params = {key: item[key], 'art': {ART: VALUE if want else None}}
    if batch is None:
        rpc('VideoLibrary.Set%sDetails' % kind, **params)
    else:
        batch.add('VideoLibrary.Set%sDetails' % kind, **params)
    return 1


def sync():
    if xbmc.getSkinDir() != 'skin.glas':  # anderer Skin aktiv: nicht in die Bibliothek schreiben (service.glas_active)
        return
    cutoff = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() - DAYS * 86400))
    changed = 0
    monitor = xbmc.Monitor()
    batch = Batch(monitor)
    with _lock:
        props = ['dateadded', 'playcount', 'art']
        for movie in rpc('VideoLibrary.GetMovies', properties=props).get('movies', []):
            if monitor.abortRequested():  # Kodi beendet: nicht weiter schreiben (service.stop_threads wartet)
                return
            changed += update('Movie', 'movieid', movie, is_new(movie, cutoff), batch)
        shows = set()
        for ep in rpc('VideoLibrary.GetEpisodes', properties=props + ['tvshowid']).get('episodes', []):
            if monitor.abortRequested():
                return
            want = is_new(ep, cutoff)
            if want:
                shows.add(ep.get('tvshowid'))
            changed += update('Episode', 'episodeid', ep, want, batch)
        for show in rpc('VideoLibrary.GetTVShows', properties=['art']).get('tvshows', []):
            if monitor.abortRequested():
                return
            changed += update('TVShow', 'tvshowid', show, show['tvshowid'] in shows, batch)
    # ausserhalb der Sperre schreiben: der Einzelabgleich nach einer Wiedergabe soll nicht auf den Leerlauf warten
    if changed and batch.flush():
        log('Abzeichen "Neu": %d Eintraege geaendert' % changed)


def _show(tvshowid, cutoff):
    """Serie neu, wenn mindestens eine ihrer Folgen neu ist."""
    eps = rpc('VideoLibrary.GetEpisodes', tvshowid=int(tvshowid), properties=['dateadded', 'playcount']).get('episodes', [])
    show = rpc('VideoLibrary.GetTVShowDetails', tvshowid=int(tvshowid), properties=['art']).get('tvshowdetails')
    if not show:
        return 0
    return update('TVShow', 'tvshowid', show, any(is_new(ep, cutoff) for ep in eps))


def sync_items(items):
    """Nur die genannten Titel (und bei Folgen ihre Serie) abgleichen."""
    if xbmc.getSkinDir() != 'skin.glas':
        return
    cutoff = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() - DAYS * 86400))
    props = ['dateadded', 'playcount', 'art']
    changed = 0
    shows = set()
    with _lock:
        for kind, dbid in items:
            if kind == 'movie':
                movie = rpc('VideoLibrary.GetMovieDetails', movieid=dbid, properties=props).get('moviedetails')
                if movie:
                    changed += update('Movie', 'movieid', movie, is_new(movie, cutoff))
            elif kind == 'episode':
                ep = rpc('VideoLibrary.GetEpisodeDetails', episodeid=dbid,
                         properties=props + ['tvshowid']).get('episodedetails')
                if ep:
                    changed += update('Episode', 'episodeid', ep, is_new(ep, cutoff))
                    shows.add(ep.get('tvshowid'))
            elif kind == 'tvshow':
                shows.add(dbid)
        for tvshowid in shows - {None, -1}:
            changed += _show(tvshowid, cutoff)
    if changed:
        log('Abzeichen "Neu": %d Eintraege geaendert' % changed)


def schedule(delay=20.0, item=None):
    """Gebuendelt nach einer kurzen Pause; danach wieder nach EVERY Sekunden (Frist laeuft ab). item = (Art, DB-ID):
    nur diesen Titel; ohne item die ganze Bibliothek."""
    global _timer, _full
    if xbmc.Monitor().abortRequested():  # Kodi beendet: keinen neuen Faden mehr (service.py, stop_threads)
        return
    with _timer_lock:
        if item is None:
            _full = True
        else:
            _items.add(item)
        if _timer:
            _timer.cancel()
        _timer = threading.Timer(delay, _run)
        _timer.daemon = True
        _timer.start()


def _run():
    global _full
    with _timer_lock:
        full, items = _full, set(_items)
        _full = False
        _items.clear()
    try:
        if full:
            sync()
        elif items:
            sync_items(items)
    except Exception as e:  # nur Komfort
        log('Abzeichen "Neu": %s' % e, xbmc.LOGWARNING)
    if xbmc.Monitor().abortRequested():
        return
    with _timer_lock:
        # nur neu planen, wenn waehrend des Laufs kein neuerer Abgleich geplant wurde (Ereignis wie Wiedergabe-Ende):
        # vorher brach das Neuplanen genau diesen ab, der Abgleich fiel bis zum naechsten Ereignis aus
        if _timer is threading.current_thread():
            schedule(EVERY)
