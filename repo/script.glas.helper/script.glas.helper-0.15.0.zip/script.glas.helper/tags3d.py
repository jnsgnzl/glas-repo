"""Glas Helper (Dienst): Kodi-Schlagwort "3D" fuer 3D-Filme, Grundlage des Eintrags "3D" in der Mediathek.

Kodis intelligente Listen kennen keinen 3D-Filter (Aufloesung und HDR ja, den Stereomodus nicht). Der Dienst setzt
deshalb das Schlagwort 3D (VideoLibrary.SetMovieDetails, bleibt in der Datenbank, geht auch ohne eigenen Kodi-Build),
die Mediathek filtert danach (Feld tag). Ein Film gilt als 3D, wenn
  - Kodis Datenstrom-Details einen Stereomodus nennen (nicht leer/off/mono). Bei Blu-ray-ISOs traegt Kodi ihn erst nach
    dem ersten Abspielen ein (MVC); daher auch nach jeder Wiedergabe abgleichen.
  - oder der Dateiname ein 3D-Kennzeichen hinter der Aufloesung traegt ("1080p 3D.iso", "1080p DTS 3D HTAB.mkv") bzw.
    als eigenes Wortstueck ("-3D-"). "3D" nur im Titel ("Saw 3D - Vollendung (2010) 1080p.iso") zaehlt nicht: das
    sagt nichts ueber die Fassung.
Nur hinzufuegen, nie entfernen (ein von Hand gesetztes Schlagwort bleibt). Alle Filme beim Start (verzoegert) und nach
jedem Bibliotheks-Scan; nach dem Ende einer Wiedergabe nur der gespielte Film (vorher jedes Mal alle, auch nach
Titelmelodien und Aerial). In einem eigenen Faden.
"""
import json
import re
import threading

import xbmc

TAG = '3D'
MARKER = re.compile(r'(?i)(?:\b(?:2160|1080|720)[pi]\b.*[ ._-]3D(?:[ ._-]|$))|(?:[._-]3D[._-])')
_lock = threading.Lock()
_timer = None
_timer_lock = threading.Lock()
_full = False           # naechster Lauf: alle Filme
_movies = set()         # sonst nur diese DB-IDs


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.glas.helper] ' + msg, level)


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def is_3d(movie):
    video = (movie.get('streamdetails') or {}).get('video') or [{}]
    mode = (video[0].get('stereomode') or '').lower()
    if mode and mode not in ('off', 'mono'):
        return True
    name = re.split(r'[/\\]', movie.get('file') or '')[-1]
    return bool(MARKER.search(name.rsplit('.', 1)[0] + '.'))


PROPS = ['file', 'streamdetails', 'tag']


def sync(movieids=None):
    """Alle Filme bzw. nur die genannten DB-IDs."""
    if xbmc.getSkinDir() != 'skin.glas':  # anderer Skin aktiv: nicht in die Bibliothek schreiben (service.glas_active)
        return
    with _lock:
        if movieids is None:
            movies = rpc('VideoLibrary.GetMovies', properties=PROPS).get('movies', [])
        else:
            movies = [m for m in (rpc('VideoLibrary.GetMovieDetails', movieid=i, properties=PROPS).get('moviedetails')
                                  for i in movieids) if m]
        added = 0
        monitor = xbmc.Monitor()
        for movie in movies:
            if monitor.abortRequested():  # Kodi beendet: nicht weiter schreiben (service.stop_threads wartet)
                break
            tags = movie.get('tag') or []
            if TAG in tags or not is_3d(movie):
                continue
            rpc('VideoLibrary.SetMovieDetails', movieid=movie['movieid'], tag=tags + [TAG])
            added += 1
        if added:
            log('3D-Schlagwort fuer %d Filme gesetzt' % added)


def schedule(delay=8.0, movieid=None):
    """Abgleich gebuendelt nach kurzer Pause (Kodi schreibt die Datenstrom-Details erst nach dem Stopp); movieid: nur
    dieser Film, sonst alle."""
    global _timer, _full
    if xbmc.Monitor().abortRequested():  # Kodi beendet: keinen neuen Faden mehr (service.py, stop_threads)
        return
    with _timer_lock:
        if movieid is None:
            _full = True
        else:
            _movies.add(movieid)
        if _timer:
            _timer.cancel()
        _timer = threading.Timer(delay, _run)
        _timer.daemon = True
        _timer.start()


def _run():
    global _full
    with _timer_lock:
        full, movies = _full, set(_movies)
        _full = False
        _movies.clear()
    try:
        if full:
            sync()
        elif movies:
            sync(sorted(movies))
    except Exception as e:  # nur Komfort
        log('3D-Schlagwort: %s' % e, xbmc.LOGWARNING)
