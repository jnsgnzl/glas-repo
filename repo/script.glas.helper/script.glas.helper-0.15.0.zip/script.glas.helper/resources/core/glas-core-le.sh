#!/bin/sh
# Glas Helper (core.py) unter LibreELEC (Generic x86_64): eigenen Kodi-Build ueber LibreELECs Kodi legen bzw. zurueck.
# Kodi laeuft unter LibreELEC als root, deshalb ohne sudo. /usr ist schreibgeschuetzt (squashfs), LibreELECs Kodi bleibt
# also unveraendert: der Build liegt in /storage/.config/glas-core und wird vor jedem Start von kodi.service
# (ExecStartPre aus einem Drop-in in /storage/.config/system.d/kodi.service.d) per Bind-Mount ueber
# /usr/lib/kodi/kodi.bin gelegt - Pfad und Prozessname bleiben gleich (kodi.sh, Kodis Pfade, killall kodi.bin).
# Nur wenn LibreELEC noch genau der Stand von der Installation ist (os-release: Geraet, Version, Build): nach einem
# LibreELEC-Update startet sonst ein alter Build gegen neue Bibliotheken.
# Notfall-Rueckweg wie der Starter der Vero (kodi-start.sh): endet der Build dreimal hintereinander in der ersten
# Minute, ab dann LibreELECs Kodi (Datei off, der Glas Helper meldet das). Ebenso ab drei Abstuerzen in 15 Minuten in
# LibreELECs Zaehler (crashes.dat) - bei fuenf schaltet LibreELEC in den abgesicherten Modus (kodi.sh).
#   glas-core-le.sh install <kodi.bin> <Kennung> [<sha256 von LibreELECs kodi.bin>]
#   glas-core-le.sh prestart     vor jedem Start von kodi.service (Drop-in), legt den Build darueber oder nicht
#   glas-core-le.sh starter      Kopie dieses Skripts in /storage/.config/glas-core erneuern (Helper-Update)
#   glas-core-le.sh remove       Drop-in und Build entfernen; beim naechsten Start laeuft LibreELECs Kodi
#   glas-core-le.sh restart      Kodi ueber systemd neu starten (getrennt von Kodi)
# Exit 3: LibreELECs kodi.bin passt nicht zur Pruefsumme im Manifest (nichts geaendert).
set -u
BIN=/usr/lib/kodi/kodi.bin
DIR=/storage/.config/glas-core
DROPIN=/storage/.config/system.d/kodi.service.d
CONF=$DROPIN/glas-core.conf
LOG=/storage/.kodi/temp/kodi.log
CRASHES=/run/libreelec/crashes.dat
STAMP='^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}'

# Stand des Systems; core.py bildet denselben Text aus /etc/os-release (le_base)
base() { (. /etc/os-release; printf '%s %s %s\n' "${LIBREELEC_ARCH:-}" "${VERSION:-}" "${BUILD_ID:-}"); }
mounted() { grep -q " $BIN " /proc/self/mountinfo; }
unmount_all() {
    # auch Reste eines Tests von Hand (README); laeuft Kodi noch (remove), loest -l den Mount, Kodi behaelt seine Datei
    i=0
    while mounted && [ $i -lt 5 ]; do
        umount "$BIN" 2>/dev/null || umount -l "$BIN" 2>/dev/null
        i=$((i + 1))
    done
}
number() { n=$(cat "$1" 2>/dev/null); case "$n" in ''|*[!0-9]*) echo 0 ;; *) echo "$n" ;; esac; }
# LibreELECs eigenes kodi.bin, auch wenn der Build gerade darueber liegt: / ohne Untermounts nochmals einhaengen
original_sha() {
    if ! mounted; then
        sha256sum "$BIN" | cut -d' ' -f1
        return
    fi
    r=/run/glas-core/root
    mkdir -p $r
    mount --bind / $r || return 0
    sha256sum $r$BIN | cut -d' ' -f1
    umount $r
}
# Abstuerze der letzten 15 Minuten in LibreELECs Zaehler (Monotonzeit wie kodi.sh)
recent_crashes() {
    [ -f $CRASHES ] || { echo 0; return; }
    now=$(awk '/^now/ { print int($3 / 1000000000) }' /proc/timer_list)
    awk -v now="${now:-0}" '$1 + 900 >= now' $CRASHES | wc -l
}
put_self() {
    tr -d '\r' < "$0" > $DIR/glas-core.sh.tmp && mv -f $DIR/glas-core.sh.tmp $DIR/glas-core.sh
}
put_conf() {
    mkdir -p $DROPIN
    printf '%s\n' '# Glas Helper: Live-Glas-Kern (entfernen ueber Glas-Einstellungen > Live-Glas-Kern)' '[Service]' \
        "ExecStartPre=-/bin/sh $DIR/glas-core.sh prestart" > $CONF.tmp && mv -f $CONF.tmp $CONF
}

case "${1:-}" in
install)
    new=$2 id=$3 want=${4:-}
    [ -f /etc/os-release ] && [ -f "$new" ] || exit 1
    if [ -n "$want" ] && [ "$(original_sha)" != "$want" ]; then
        echo "LibreELECs kodi.bin passt nicht zum Build" >&2
        exit 3
    fi
    mkdir -p $DIR || exit 1
    cp "$new" $DIR/kodi.bin.tmp && chmod 755 $DIR/kodi.bin.tmp && mv -f $DIR/kodi.bin.tmp $DIR/kodi.bin || exit 1
    put_self || exit 1
    base > $DIR/base
    printf '%s\n' "$id" > $DIR/build
    echo 0 > $DIR/starts
    rm -f $DIR/off $DIR/started
    put_conf || exit 1
    systemctl daemon-reload
    ;;
prestart)
    unmount_all
    [ -x $DIR/kodi.bin ] && [ ! -e $DIR/off ] || exit 0
    # LibreELEC aktualisiert: dessen Kodi, bis ein passender Build installiert ist (der Glas Helper bietet ihn an)
    [ "$(base)" = "$(cat $DIR/base 2>/dev/null)" ] || exit 0
    n=$(number $DIR/starts)
    # war der vorige Lauf gesund? Sein Log beginnt nach dem vorigen Start, traegt die Build-Markierung und reicht ueber
    # mindestens 60 s (Kodi benennt es erst beim naechsten Start um)
    if [ "$n" -gt 0 ] && [ -f $LOG ] && grep -q 'Glas: eigener Kodi-Build' $LOG; then
        since=$(number $DIR/started)
        first=$(date -d "$(grep -m 1 -oE "$STAMP" $LOG)" +%s 2>/dev/null || echo 0)
        last=$(date -d "$(grep -oE "$STAMP" $LOG | tail -n 1)" +%s 2>/dev/null || echo 0)
        if [ "$first" -ge $((since - 2)) ] && [ $((last - first)) -ge 60 ]; then
            n=0
        fi
    fi
    if [ "$n" -ge 3 ] || [ "$(recent_crashes)" -ge 3 ]; then
        date '+%F %T' > $DIR/off
        exit 0
    fi
    echo $((n + 1)) > $DIR/starts
    date +%s > $DIR/started
    mount --bind $DIR/kodi.bin $BIN
    ;;
starter)
    if [ -f $DIR/build ]; then put_self && put_conf; fi
    ;;
remove)
    rm -f $CONF
    rmdir $DROPIN 2>/dev/null
    systemctl daemon-reload
    unmount_all
    rm -rf $DIR
    ;;
restart)
    systemctl --no-block restart kodi
    ;;
*)
    echo "Aufruf: $0 install <kodi.bin> <Kennung> [<sha256>] | prestart | starter | remove | restart" >&2
    exit 2
    ;;
esac
exit 0
