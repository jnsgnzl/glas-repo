"""Glas Helper: CPU-Regler ondemand fuer fluessige Bewegung (nur Linux, z. B. Vero).

Kodi rechnet jedes Bild der Oberflaeche in einem Stueck auf einem Faden. Der lastet einen Kern nur zu 30-40 % aus, und
der Regler ondemand (Vorgabe: hochtakten erst ab 95 % Last, nach 50 ms wieder herunter) hielt die CPU in Bewegung bei
1,0-1,4 GHz statt 2,0 GHz. Gemessen auf der Vero V (12.11.2026, docs/plan-leistung.md 4f): mit up_threshold 30 und
sampling_down_factor 20 (hochtakten ab 30 %, danach 1 s oben bleiben) so fluessig wie mit festem Hoechsttakt
(App TV Reihen 13 -> 2,5 verspaetete Bilder/s, Startseite 5 -> 1, Mediathek 12 -> 7), Temperatur etwa +1,5 Grad. Im
Leerlauf taktet ondemand weiter herunter.

Gesetzt beim Start und danach einmal je Minute, falls die Werte abweichen (nach einem Neustart des Systems stehen
wieder die Vorgaben). Schreiben direkt (als root) oder ueber sudo ohne Passwort (OSMC); geht beides nicht, bleibt alles
wie es ist (einmal ins Log). Andere Regler (performance, schedutil) bleiben unberuehrt.
"""
import glob
import subprocess
import sys

import xbmc

LINUX = sys.platform.startswith('linux')
WANT = (('up_threshold', '30'), ('sampling_down_factor', '20'))
EVERY = 60.0


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.glas.helper] ' + msg, level)


def _dirs():
    return sorted(set(glob.glob('/sys/devices/system/cpu/cpufreq/ondemand') +
                      glob.glob('/sys/devices/system/cpu/cpufreq/policy*/ondemand')))


def _read(path):
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError:
        return None


def _write(path, value):
    try:
        with open(path, 'w') as f:
            f.write(value)
        return True
    except OSError:
        pass
    try:
        r = subprocess.run(['sudo', '-n', 'tee', path], input=value.encode(), stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=5)
        return r.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


class Governor:
    def __init__(self):
        self.next = 0.0
        self.failed = False

    def tick(self, clock):
        if not LINUX or self.failed or clock < self.next:
            return
        self.next = clock + EVERY
        for d in _dirs():
            for name, value in WANT:
                path = d + '/' + name
                old = _read(path)
                if old is None or old == value:
                    continue
                if _write(path, value) and _read(path) == value:
                    log('CPU-Regler ondemand: %s %s -> %s (%s)' % (name, old, value, d))
                else:
                    log('CPU-Regler ondemand: %s nicht schreibbar (kein root, kein sudo ohne Passwort), bleibt %s'
                        % (path, old), xbmc.LOGWARNING)
                    self.failed = True
                    return
