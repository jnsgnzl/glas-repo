"""Glas Helper: was am AV-Receiver ankommt (Denon/Marantz mit HEOS, z. B. Marantz SR6015).

Ersetzt den Blick per INFO-Taste auf das Receiver-Display: eingehendes Tonformat (Dolby Atmos, TrueHD, DTS:X, PCM ...),
aktiver Klangmodus und Abtastrate, im Kontrollzentrum (Audio-Untermenue, audio.py) und als Zeile im Info-Paneel des
Players (Custom_1123). Nur lesend: der Receiver wird nicht eingeschaltet und nichts wird umgestellt.

Schnittstelle (HTTP, Port 8080, ohne Anmeldung; Denon/Marantz ab etwa 2016, "AppCommand"):
  GET  /goform/Deviceinfo.xml                         Modellname (ModelName)
  GET  /goform/formMainZone_MainZoneXmlStatusLite.xml Hauptzone an/aus (Power: ON | STANDBY | OFF)
  POST /goform/AppCommand0300.xml  GetAudioInfo        inputmode, output, signal, sound, fs
Aufbau nach der quelloffenen Bibliothek DenonMarantzAvrNet (conebo-com); an einem SR6015 gemessen: Modell und
Standby (24.10.2026), Werte bei laufender Wiedergabe noch ungeprueft.

Receiver finden: UPnP-Suche (SSDP) nach "Denon-Heos", dann Deviceinfo.xml. Ergebnis in Skin.String(glas_avr_host) und
Skin.String(glas_avr_model); ein von Hand gesetzter Host bleibt. Werte fuer den Skin als Window(Home)-Properties:
glas.avr.model und glas.avr.line (fertige Zeile).

Abgefragt wird nur, waehrend ein Video laeuft und nicht pausiert (nicht bei Titelmelodien, Musik oder dem
Bildschirmschoner Aerial, der die ganze Nacht Video spielt), und einmal auf Wunsch des Audio-Menues im Kontrollzentrum
(audio.py sendet NotifyAll(script.glas.helper,glas_avr_refresh), wake.WakeMonitor setzt REQUEST): das Menue zeigt
sofort die Werte des Dienstes und laedt neu, sobald frische da sind - vorher fragte es selbst und blieb bis zu 4 s haengen.
"""
import socket
import threading
import time
import urllib.request
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui

PORT = 8080
TIMEOUT = 2.0
POLL = 5.0              # Sekunden zwischen zwei Abfragen waehrend der Wiedergabe
HOME = xbmcgui.Window(10000)
# laufendes Video, nicht pausiert, kein Bildschirmschoner: Aerial (dessen Video laeuft teils nach dem Schliessen weiter,
# daher auch die Adresse; wie stereo.wait_idle) oder Glas Videos (screensaver.glas.videos)
FILM = ('Player.HasVideo + !Player.Paused + !Window.IsActive(screensaver-atv4.xml) + '
        '!Window.IsActive(screensaver-glas-videos.xml) + !String.Contains(Player.Filenameandpath,apple.com/Videos/)')
REFRESH = 'glas_avr_refresh'    # NotifyAll-Nachricht des Audio-Menues
REQUEST = threading.Event()     # gesetzt von wake.WakeMonitor bei REFRESH
AUDIO_INFO = ('<?xml version="1.0" encoding="utf-8"?><tx><cmd id="3"><name>GetAudioInfo</name><list>'
              '<param name="inputmode"/><param name="output"/><param name="signal"/><param name="sound"/>'
              '<param name="fs"/></list></cmd></tx>')
# Schreibweise wie auf dem Receiver-Display, aber nicht in Grossbuchstaben (Klangmodus kommt als "DOLBY ATMOS")
KEEP_UPPER = {'DTS', 'DTS:X', 'PCM', 'HD', 'MA', 'MSTR', 'IMAX', 'DSD', 'AURO', 'AURO-3D', 'EX', 'ES', 'LPCM', 'PL', 'II',
              'IIX', 'IIZ', 'X', 'CH', 'DSUR', 'NEO:6', 'NEO:X', 'AAC', 'MPEG'}


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.glas.helper] ' + msg, level)


def loc(string_id):
    return xbmc.getInfoLabel('$LOCALIZE[%d]' % string_id)


def host():
    return xbmc.getInfoLabel('Skin.String(glas_avr_host)')


def http(path, data=None, address=None):
    url = 'http://%s:%d%s' % (address or host(), PORT, path)
    request = urllib.request.Request(url, data=data.encode() if data else None,
                                     headers={'Content-Type': 'text/xml'} if data else {})
    with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
        return response.read()


def nice(text):
    words = (text or '').strip().split()
    return ' '.join(w if w.upper() in KEEP_UPPER or any(c.isdigit() for c in w) else w.capitalize() for w in words)


def model_of(address):
    try:
        root = ET.fromstring(http('/goform/Deviceinfo.xml', address=address))
    except Exception:
        return ''
    return (root.findtext('ModelName') or '').strip()


def discover():
    """Receiver im Heimnetz finden (einmal beim Start des Dienstes, nur ohne gesetzten Host)."""
    if host():
        return
    msg = ('M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: "ssdp:discover"\r\nMX: 2\r\n'
           'ST: urn:schemas-upnp-org:device:MediaRenderer:1\r\n\r\n').encode()
    found = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
        s.settimeout(0.5)
        s.sendto(msg, ('239.255.255.250', 1900))
        end = time.monotonic() + 3
        while time.monotonic() < end:
            try:
                data, addr = s.recvfrom(4096)
            except socket.timeout:
                continue
            if b'Denon-Heos' in data and addr[0] not in found:
                found.append(addr[0])
        s.close()
    except OSError as e:
        log('Receiver-Suche: %s' % e, xbmc.LOGDEBUG)
    for address in found:
        model = model_of(address)
        if model:
            xbmc.executebuiltin('Skin.SetString(glas_avr_host,%s)' % address)
            xbmc.executebuiltin('Skin.SetString(glas_avr_model,%s)' % model)
            log('Receiver gefunden: %s (%s)' % (model, address))
            return


def status():
    """{'power': 'on'|'standby', 'signal', 'sound', 'fs', 'inputmode', 'output'} oder None (nicht erreichbar)."""
    if not host():
        return None
    try:
        zone = ET.fromstring(http('/goform/formMainZone_MainZoneXmlStatusLite.xml'))
        power = (zone.findtext('Power/value') or '').strip().upper()
        result = {'power': 'on' if power == 'ON' else 'standby'}
        if result['power'] == 'on':
            info = ET.fromstring(http('/goform/AppCommand0300.xml', AUDIO_INFO))
            for param in info.iter('param'):
                result[param.get('name', '')] = (param.text or '').strip()
        return result
    except Exception as e:
        log('Receiver %s: %s' % (host(), e), xbmc.LOGDEBUG)
        return None


def describe(info):
    """(Titel, Zeile) fuer Menue und Info-Paneel, z. B. ('SR6015', 'Dolby Atmos · Dolby Atmos · 48 kHz')."""
    model = xbmc.getInfoLabel('Skin.String(glas_avr_model)') or 'Receiver'
    if info is None:
        return model, ''
    if info.get('power') != 'on':
        return model, loc(31463)
    signal = nice(info.get('signal'))
    sound = nice(info.get('sound'))
    fs = (info.get('fs') or '').replace('kHz', ' kHz').replace('  ', ' ').strip()
    parts = [signal or loc(31464)]
    if sound and sound.lower() != signal.lower():
        parts.append(sound)
    if fs:
        parts.append(fs)
    return model, ' · '.join(parts)


def publish(info):
    """Werte setzen; True, wenn sich etwas geaendert hat."""
    model, line = describe(info)
    values = {'glas.avr.model': model if info is not None else '', 'glas.avr.line': line}
    changed = False
    for key, value in values.items():
        if HOME.getProperty(key) != value:
            HOME.setProperty(key, value)
            changed = True
    return changed


def clear():
    for key in ('glas.avr.model', 'glas.avr.line'):
        HOME.clearProperty(key)


class Poller:
    """Dienst: waehrend ein Film laeuft (FILM) alle POLL Sekunden abfragen, auf Wunsch des Audio-Menues sofort (eigener
    Faden, blockiert den Dienst nicht); nach dem Ende der Wiedergabe die Werte leeren."""

    def __init__(self):
        self.next = 0.0
        self.busy = False
        self.active = False
        threading.Thread(target=discover, daemon=True).start()

    def stop(self):
        """Werte leeren (anderer Skin, service.wait_for_glas); eine laufende Abfrage endet von selbst."""
        if self.active:
            self.active = False
            clear()

    def tick(self, video_on=True):
        """video_on: Player.HasVideo, einmal je Runde vom Dienst abgefragt (ohne Video, Wunsch und Werte: keine Abfrage)"""
        requested = REQUEST.is_set()
        if not video_on and not requested and not self.active:
            return
        film = video_on and xbmc.getCondVisibility(FILM)
        if not film and not requested:
            # pausiert: Werte stehen lassen; Wiedergabe zu Ende: leeren (Werte einer Menue-Abfrage bleiben)
            if self.active and not xbmc.getCondVisibility('Player.HasMedia'):
                self.active = False
                clear()
            return
        now = time.monotonic()
        if self.busy or (now < self.next and not requested) or not host():
            return
        REQUEST.clear()
        self.active = film
        self.busy = True
        self.next = now + POLL

        def run():
            try:
                if publish(status()) and requested and HOME.getProperty('glas_ccmenu') == 'audio':
                    # Audio-Menue offen: neu laden (wie power.bump)
                    xbmc.executebuiltin('SetProperty(glas_ccmenu_v,%d,home)' % int(time.time() * 1000 % 100000000))
            finally:
                self.busy = False

        threading.Thread(target=run, daemon=True).start()
