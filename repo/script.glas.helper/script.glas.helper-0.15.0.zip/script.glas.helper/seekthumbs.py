"""Glas Helper: Vorschaubilder der Spulvorschau aus Kodis Bild-Cache entfernen.

Der Skin zeigt beim Spulen glasseek://<Datei>/<Zeit> (DialogSeekBar, Kern: tools/kodi-build/glas-patches.txt). Kodi legt
jedes dieser Bilder wie ein Poster dauerhaft in den Bild-Cache (Textures13.db, userdata/Thumbnails); ohne Aufraeumen
wuechse er mit jedem Spulen. Nach dem Stopp der Wiedergabe und beim Start des Dienstes werden sie entfernt (im
Hintergrund, Kodis eigene Funktion Textures.RemoveTexture loescht Eintrag und Datei).

Textures.GetTextures liefert die Adresse mit der Eigenschaft "url" verpackt (image://glasseek%3a.../), der Filter
vergleicht dagegen die gespeicherte Adresse. Bis Glas Helper 0.12 wurde die verpackte Adresse mit glasseek:// verglichen,
es wurde nie etwas entfernt (auf der Vero standen 82 Eintraege).
Beim Start ausserdem einmal: Glasbilder, die aeltere Fassungen unter /dev/shm/glas_glass ablegten (service.glass_folder).
"""
import json
import threading
from urllib.parse import unquote

import xbmc

PREFIX = 'glasseek://'
OLD_GLASS = '/dev/shm/glas_glass/'


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})


def unwrap(url):
    return unquote(url[len('image://'):].rstrip('/')) if url.startswith('image://') else url


def purge(prefix=PREFIX, what='Spulvorschau'):
    textures = rpc('Textures.GetTextures', properties=['url'],
                   filter={'field': 'url', 'operator': 'startswith', 'value': prefix}).get('textures', [])
    removed = 0
    monitor = xbmc.Monitor()
    for texture in textures:
        if monitor.abortRequested():
            break
        if unwrap(texture.get('url', '')).startswith(prefix):
            rpc('Textures.RemoveTexture', textureid=texture['textureid'])
            removed += 1
    if removed:
        xbmc.log('[script.glas.helper] %s: %d Bilder aus dem Bild-Cache entfernt' % (what, removed), xbmc.LOGINFO)


def purge_start():
    purge()
    purge(OLD_GLASS, 'Glasbilder')


def schedule(delay=5, old_glass=False):
    """nach dem Stopp: kurz warten (das letzte Bild kann noch geladen werden), dann im Hintergrund aufraeumen;
    old_glass (Start des Dienstes): dazu die Glasbilder aelterer Fassungen"""
    if xbmc.Monitor().abortRequested():  # Kodi beendet: keinen neuen Faden mehr (service.py, stop_threads)
        return
    timer = threading.Timer(delay, purge_start if old_glass else purge)
    timer.daemon = True
    timer.start()
