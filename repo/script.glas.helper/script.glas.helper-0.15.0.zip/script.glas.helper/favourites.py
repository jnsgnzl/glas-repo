"""Glas Helper: Kodis Favoriten als Dock-Platz (Testerwunsch 17.11.2026: Netflix-Starter unter Windows als eigener
Eintrag im Hauptmenue, ohne eigenes Add-on).

Liest special://profile/favourites.xml direkt: dort steht der fertige Befehl jedes Favoriten (ActivateWindow, PlayMedia,
RunScript, System.Exec, ...), die JSON-RPC-Schnittstelle liefert fuer System.Exec und aehnliche nur "unknown".
Schluessel fav:<id>, id aus dem Befehl (bleibt beim Umbenennen gleich; bei gleichem Befehl ab dem zweiten mit Name).

Das Dock legt die Aktion als Skin-String ab (Skin.SetString macht aus " ein ' und Kodi wertet Backslashes beim Zerlegen
der Parameter aus). Befehle ohne Anfuehrungszeichen, Backslash und $ stehen deshalb direkt im Dock (startet ohne Python, wie die Apps), alle
anderen startet der Helper: ?action=fav&key=fav:<id> liest den Favoriten neu und fuehrt ihn aus.

Kachel: ist der Favorit ein Add-on (RunAddon/RunScript mit nur der ID), dessen Kachel; mit eigenem Bild dieses (Querformat
als Kachel, sonst als Logo); sonst die Markenkachel, wenn der Name eine bekannte Marke enthaelt (brands.json "names");
sonst eine Namenskachel wie bei den Videoquellen (sources.tile).
"""
import hashlib
import re
import xml.etree.ElementTree as ET
from urllib.parse import urlencode

import xbmc
import xbmcvfs

PREFIX = 'fav:'
FILE = 'special://profile/favourites.xml'
BASE = 'plugin://script.glas.helper/'


def fav_id(builtin):
    return hashlib.sha1(builtin.encode('utf-8')).hexdigest()[:10]


def favourites():
    """[(id, Name, Befehl, Bild)] in Kodis Reihenfolge; ohne Datei oder bei kaputter Datei leer"""
    real = xbmcvfs.translatePath(FILE)
    if not xbmcvfs.exists(FILE):
        return []
    try:
        root = ET.parse(real).getroot()
    except (ET.ParseError, OSError) as e:
        xbmc.log('[script.glas.helper] favourites.xml nicht lesbar: %s' % e, xbmc.LOGWARNING)
        return []
    out, seen = [], set()
    for fav in root.iter('favourite'):
        builtin = (fav.text or '').strip()
        if builtin:
            label = fav.get('name') or builtin
            # gleicher Befehl unter mehreren Namen: der erste behaelt die Kennung (bleibt beim Umbenennen), die weiteren
            # nehmen den Namen dazu (sonst landeten alle auf dem ersten, am PC 17.11.2026 gesehen)
            fid = fav_id(builtin)
            if fid in seen:
                fid = fav_id(builtin + '\n' + label)
            seen.add(fid)
            out.append((fid, label, builtin, fav.get('thumb', '')))
    return out


def addon_of(builtin):
    """Add-on-ID, wenn der Favorit nur ein Add-on startet (RunAddon(id), RunScript(id)), sonst ''"""
    m = re.match(r'^\s*Run(?:Addon|Script)\(\s*"?([\w.\-]+)"?\s*\)\s*$', builtin, re.I)
    return m.group(1) if m else ''


def action_of(key, builtin):
    if any(c in builtin for c in '"\\$'):
        return 'RunPlugin(%s?%s)' % (BASE, urlencode({'action': 'fav', 'key': key}))
    return builtin


def is_default(thumb):
    """Kodis Standardsymbole (DefaultFolder.png, ...) taugen nicht als Kachel"""
    return not thumb or re.match(r'^Default\w*\.png$', thumb) is not None


def thumb_art(thumb):
    """Bild im Querformat (wie eine Kachel, ab 1,4:1) fuellt die Kachel, sonst steht es als Logo darauf. Als "logo",
    nicht "icon": die Property icon eines festen Eintrags im Dock (Home.xml) kommt in Kodi leer an (am PC 17.11.2026
    geprueft, Container(5100).ListItem.Property(icon) bei allen Plaetzen leer)"""
    try:
        from PIL import Image
        with Image.open(xbmcvfs.translatePath(thumb)) as img:
            w, h = img.size
        if w >= 1.4 * h:
            return {'tile': thumb}
    except Exception:  # ohne Pillow, image://-Pfad oder fehlendes Bild
        pass
    return {'logo': thumb}


def entries(brand=None):
    """[(Schluessel, Name, Kachelbild)] fuer die Auswahl des Dock-Platzes (brand: wie bei entry)"""
    out = []
    for fid, label, _, thumb in favourites():
        art = brand(label) if brand and is_default(thumb) else {}
        image = thumb if not is_default(thumb) else art.get('preview', '')
        out.append((PREFIX + fid, label, image))
    return out


def entry(key, apps=None, brand=None):
    """Werte eines Dock-Platzes; apps: installed_apps() fuer die Kachel von Add-on-Favoriten (nur bei Bedarf geladen),
    brand: Name -> Markenkachel (default.brand_by_name; "Netflix" ohne eigenes Bild bekommt die Netflix-Kachel)"""
    for index, (fid, label, builtin, thumb) in enumerate(favourites()):
        if PREFIX + fid != key:
            continue
        values = {'key': key, 'label': label, 'action': action_of(key, builtin)}
        addon_id = addon_of(builtin)
        if addon_id and apps:
            for app_id, _, art in apps():
                if app_id == addon_id:
                    values.update({'tile': art.get('tile', ''), 'logo': art.get('logo', ''), 'icon': art.get('icon', ''),
                                   'shelfimage': art.get('fanart', '')})
                    return values
        if not is_default(thumb):
            values.update(thumb_art(thumb))
        elif brand and brand(label):
            art = brand(label)
            values.update({'tile': art['tile'], 'logo': art['logo']})
        else:
            values['tile'] = __import__('sources').tile('fav-' + fid, label, index + 3)
        return values
    return None


def run(key):
    for fid, label, builtin, _ in favourites():
        if PREFIX + fid == key:
            xbmc.executebuiltin(builtin)
            return
    # Favorit geloescht oder geaendert: der Platz zeigt ihn noch, bis man ihn neu waehlt
    xbmc.log('[script.glas.helper] Favorit %s nicht mehr vorhanden' % key, xbmc.LOGWARNING)
