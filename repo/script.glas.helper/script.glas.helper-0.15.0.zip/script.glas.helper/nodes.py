"""Glas Helper: eigene Mediathek-Knoten (z. B. aus dem Add-on "Library Node Editor") als Dock-Platz.

Testerbericht 22.11.2026: Ein mit dem Library Node Editor angelegter Knoten "Zuletzt hinzugefuegte Filme" liess sich
nicht ins Dock legen (nur das Add-on selbst). Kodi liest die Knoten aus special://profile/library/video/, sobald es den
Ordner gibt (sonst aus special://xbmc/system/library/video/); der Editor kopiert dafuer zuerst Kodis Standardknoten
dorthin. Eigene Knoten sind die, die es unter Kodis Standardknoten nicht gibt.

Je Knoten ein Schluessel node:<relativer Pfad> (z. B. node:movies/neu.xml oder node:meine-filme), die Kachel mit dem
Namen auf einem Farbverlauf (wie die Videoquellen, sources.tile), die Aktion oeffnet library://video/<Pfad>/ in der
Mediathek. Top Shelf: "Weiter ansehen" der Filme bzw. Serien je nach Inhalt des Knotens, sonst alles.
"""
import hashlib
import os
import xml.etree.ElementTree as ET

import xbmc
import xbmcvfs

PREFIX = 'node:'
PROFILE = 'special://profile/library/video/'
SYSTEM = 'special://xbmc/system/library/video/'
SHELVES = {'movies': 'movies', 'tvshows': 'episodes', 'seasons': 'episodes', 'episodes': 'episodes'}


def _read(path):
    try:
        return ET.parse(path).getroot()
    except (ET.ParseError, OSError):
        return None


def _label(root, fallback):
    text = (root.findtext('label') or '').strip() if root is not None else ''
    if text.isdigit():
        text = xbmc.getLocalizedString(int(text))
    return text or fallback


def _content(root, folder):
    """Inhalt eines Knotens (movies, tvshows, ...); bei Ordnern der erste Inhalt darin"""
    if root is not None and root.findtext('content'):
        return root.findtext('content').strip()
    if folder:
        for name in sorted(os.listdir(folder)):
            if name.endswith('.xml') and name != 'index.xml':
                node = _read(os.path.join(folder, name))
                if node is not None and node.findtext('content'):
                    return node.findtext('content').strip()
    return ''


def custom_nodes():
    """[(Schluessel, Name, Pfad, Inhalt)] aller eigenen Knoten, in der Reihenfolge der Ordner"""
    profile = xbmcvfs.translatePath(PROFILE)
    system = xbmcvfs.translatePath(SYSTEM)
    if not os.path.isdir(profile):
        return []
    out = []
    for folder, dirs, files in os.walk(profile):
        dirs.sort()
        rel_dir = os.path.relpath(folder, profile).replace('\\', '/')
        rel_dir = '' if rel_dir == '.' else rel_dir + '/'
        # Ordner-Knoten (mit index.xml)
        if rel_dir and 'index.xml' in files and not os.path.exists(os.path.join(system, rel_dir)):
            root = _read(os.path.join(folder, 'index.xml'))
            name = _label(root, os.path.basename(folder.rstrip('\\/')))
            out.append((PREFIX + rel_dir.rstrip('/'), name, 'library://video/' + rel_dir, _content(root, folder)))
        for name in sorted(files):
            if not name.endswith('.xml') or name == 'index.xml':
                continue
            rel = rel_dir + name
            if os.path.exists(os.path.join(system, rel)):
                continue    # Kodis Standardknoten (auch vom Editor kopiert)
            root = _read(os.path.join(folder, name))
            if root is None or root.tag != 'node':
                continue
            out.append((PREFIX + rel, _label(root, name[:-4]), 'library://video/%s/' % rel, _content(root, None)))
    return out


def node_tile(key, label, index):
    import sources
    return sources.tile(hashlib.sha1(key.encode('utf-8')).hexdigest()[:10], label, index)


def entries():
    """[(Schluessel, Name, Kachel)] fuer die Auswahl eines Dock-Platzes"""
    return [(key, label, node_tile(key, label, i)) for i, (key, label, _, _) in enumerate(custom_nodes())]


def entry(key):
    for i, (k, label, path, content) in enumerate(custom_nodes()):
        if k == key:
            return {'key': k, 'label': label, 'action': 'ActivateWindow(Videos,%s,return)' % path,
                    'tile': node_tile(k, label, i), 'shelf': SHELVES.get(content, 'tv')}
    return None
